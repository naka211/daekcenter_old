-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 26, 2015 at 11:25 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.2-1ubuntu4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `u1233f5`
--

-- --------------------------------------------------------

--
-- Table structure for table `jos_acajoom_lists`
--

CREATE TABLE IF NOT EXISTS `jos_acajoom_lists` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `list_name` varchar(101) NOT NULL DEFAULT '',
  `list_desc` text NOT NULL,
  `list_type` tinyint(2) NOT NULL DEFAULT '0',
  `sendername` varchar(64) NOT NULL DEFAULT '',
  `senderemail` varchar(64) NOT NULL DEFAULT '',
  `bounceadres` varchar(64) NOT NULL DEFAULT '',
  `layout` text NOT NULL,
  `template` int(9) NOT NULL DEFAULT '0',
  `subscribemessage` text NOT NULL,
  `unsubscribemessage` text NOT NULL,
  `unsubscribesend` tinyint(1) NOT NULL DEFAULT '1',
  `auto_add` tinyint(1) NOT NULL DEFAULT '0',
  `user_choose` tinyint(1) NOT NULL DEFAULT '0',
  `cat_id` varchar(250) NOT NULL DEFAULT '',
  `delay_min` int(2) NOT NULL DEFAULT '0',
  `delay_max` int(2) NOT NULL DEFAULT '7',
  `follow_up` int(10) NOT NULL DEFAULT '0',
  `html` tinyint(1) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `createdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `acc_level` int(2) NOT NULL DEFAULT '0',
  `acc_id` int(11) NOT NULL DEFAULT '29',
  `notification` tinyint(1) NOT NULL DEFAULT '0',
  `owner` int(11) NOT NULL DEFAULT '0',
  `footer` tinyint(1) NOT NULL DEFAULT '1',
  `notify_id` int(10) NOT NULL DEFAULT '0',
  `next_date` int(11) NOT NULL DEFAULT '0',
  `start_date` date NOT NULL,
  `params` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `list_name` (`list_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Truncate table before insert `jos_acajoom_lists`
--

TRUNCATE TABLE `jos_acajoom_lists`;
--
-- Dumping data for table `jos_acajoom_lists`
--

INSERT INTO `jos_acajoom_lists` (`id`, `list_name`, `list_desc`, `list_type`, `sendername`, `senderemail`, `bounceadres`, `layout`, `template`, `subscribemessage`, `unsubscribemessage`, `unsubscribesend`, `auto_add`, `user_choose`, `cat_id`, `delay_min`, `delay_max`, `follow_up`, `html`, `hidden`, `published`, `createdate`, `acc_level`, `acc_id`, `notification`, `owner`, `footer`, `notify_id`, `next_date`, `start_date`, `params`) VALUES
(1, 'Default', '', 1, 'Administrator', 'ngo.bieu@mwc.vn', 'ngo.bieu@mwc.vn', '<table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#f1f1f1">\r\n<tbody>\r\n<tr>\r\n<td align="center" valign="top">\r\n<table border="0" cellspacing="0" cellpadding="0" width="530" bgcolor="#f1f1f1">\r\n<tbody>\r\n<tr>\r\n<td class="hbnr" colspan="3" bgcolor="#ffffff"><img src="components/com_acajoom/templates/default/tpl0_top_header.jpg" border="0" alt="e Newsletter" width="530" height="137" /></td>\r\n</tr>\r\n<tr>\r\n<td colspan="3" bgcolor="#ffffff"><img src="components/com_acajoom/templates/default/tpl0_underban.jpg" border="0" alt="." width="530" height="22" /></td>\r\n</tr>\r\n<tr>\r\n<!-- /// gutter \\ -->\r\n<td width="15" valign="top" bgcolor="#ffffff"><img src="components/com_acajoom/templates/default/tpl0_spacer.gif" border="0" alt="1" width="15" height="1" /></td>\r\n<!-- \\ gutter /// --> <!-- /// content cell \\ -->\r\n<td width="500" valign="top" bgcolor="#ffffff"><br />\r\n<p>Â </p>\r\n<p>Your Subscription:<br /> [SUBSCRIPTIONS]</p>\r\n<p>Â </p>\r\n</td>\r\n<!-- \\ content cell /// --> <!-- /// gutter \\ -->\r\n<td width="15" valign="top" bgcolor="#ffffff"><img src="components/com_acajoom/templates/default/tpl0_spacer.gif" border="0" alt="1" width="15" height="1" /></td>\r\n<!-- \\ gutter /// -->\r\n</tr>\r\n<!-- /// footer area with contact info and opt-out link \\ --> \r\n<tr>\r\n<td colspan="3" bgcolor="#ffffff"><img src="components/com_acajoom/templates/default/tpl0_abovefooter.jpg" border="0" alt="." width="530" height="22" /></td>\r\n</tr>\r\n<tr>\r\n<td style="border-top: 1px solid #aeaeae;" colspan="3" align="center" valign="middle" bgcolor="#cacaca">\r\n<p class="footerText"><a href="http://www.ijoobi.com"><img src="components/com_acajoom/templates/default/tpl0_powered_by.gif" border="0" alt="Powered By Joobi" width="129" height="60" /></a></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<!-- \\ footer area with contact info and opt-out link /// --></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<!-- \\ Newsletter Powered by Acajoom!  /// -->\r\n<p>Â </p>', 0, '', '<p>This is a confirmation email that you have been unsubscribed from our list.  We are sorry that you decided to unsubscribe should you decide to re-subscribe you can always do so on our site.  Should you have any question please contact our webmaster.</p>', 1, 0, 0, '', 0, 0, 0, 1, 0, 1, '2010-01-06 03:01:38', 25, 29, 0, 62, 1, 0, 0, '0000-00-00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jos_acajoom_mailings`
--

CREATE TABLE IF NOT EXISTS `jos_acajoom_mailings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list_id` int(10) NOT NULL DEFAULT '0',
  `list_type` tinyint(2) NOT NULL DEFAULT '0',
  `issue_nb` int(10) NOT NULL DEFAULT '0',
  `subject` varchar(120) NOT NULL DEFAULT '',
  `fromname` varchar(64) NOT NULL DEFAULT '',
  `fromemail` varchar(64) NOT NULL DEFAULT '',
  `frombounce` varchar(64) NOT NULL DEFAULT '',
  `htmlcontent` longtext NOT NULL,
  `textonly` longtext NOT NULL,
  `attachments` text NOT NULL,
  `images` text NOT NULL,
  `send_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delay` int(10) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `html` tinyint(1) NOT NULL DEFAULT '1',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `createdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `acc_level` int(2) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_acajoom_mailings`
--

TRUNCATE TABLE `jos_acajoom_mailings`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_acajoom_queue`
--

CREATE TABLE IF NOT EXISTS `jos_acajoom_queue` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) NOT NULL DEFAULT '0',
  `subscriber_id` int(11) NOT NULL DEFAULT '0',
  `list_id` int(10) NOT NULL DEFAULT '0',
  `mailing_id` int(11) NOT NULL DEFAULT '0',
  `issue_nb` int(10) NOT NULL DEFAULT '0',
  `send_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `suspend` tinyint(1) NOT NULL DEFAULT '0',
  `delay` int(10) NOT NULL DEFAULT '0',
  `acc_level` int(2) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `params` text,
  PRIMARY KEY (`qid`),
  UNIQUE KEY `subscriber_id` (`subscriber_id`,`list_id`,`mailing_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Truncate table before insert `jos_acajoom_queue`
--

TRUNCATE TABLE `jos_acajoom_queue`;
--
-- Dumping data for table `jos_acajoom_queue`
--

INSERT INTO `jos_acajoom_queue` (`qid`, `type`, `subscriber_id`, `list_id`, `mailing_id`, `issue_nb`, `send_date`, `suspend`, `delay`, `acc_level`, `published`, `params`) VALUES
(1, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 0, 29, 0, ''),
(8, 1, 17, 1, 0, 0, '0000-00-00 00:00:00', 0, 0, 29, 0, ''),
(3, 1, 7, 1, 0, 0, '0000-00-00 00:00:00', 0, 0, 29, 0, ''),
(4, 1, 6, 1, 0, 0, '0000-00-00 00:00:00', 0, 0, 29, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_acajoom_stats_details`
--

CREATE TABLE IF NOT EXISTS `jos_acajoom_stats_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mailing_id` int(11) NOT NULL DEFAULT '0',
  `subscriber_id` int(11) NOT NULL DEFAULT '0',
  `sentdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `html` tinyint(1) NOT NULL DEFAULT '0',
  `read` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_mail` (`mailing_id`,`subscriber_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_acajoom_stats_details`
--

TRUNCATE TABLE `jos_acajoom_stats_details`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_acajoom_stats_global`
--

CREATE TABLE IF NOT EXISTS `jos_acajoom_stats_global` (
  `mailing_id` int(11) NOT NULL DEFAULT '0',
  `sentdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `html_sent` int(11) NOT NULL DEFAULT '0',
  `text_sent` int(11) NOT NULL DEFAULT '0',
  `html_read` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mailing_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_acajoom_stats_global`
--

TRUNCATE TABLE `jos_acajoom_stats_global`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_acajoom_subscribers`
--

CREATE TABLE IF NOT EXISTS `jos_acajoom_subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `receive_html` tinyint(1) NOT NULL DEFAULT '1',
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `blacklist` tinyint(1) NOT NULL DEFAULT '0',
  `timezone` time NOT NULL DEFAULT '00:00:00',
  `language_iso` varchar(10) NOT NULL DEFAULT 'eng',
  `subscribe_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `date` (`subscribe_date`),
  KEY `joomlauserid` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Truncate table before insert `jos_acajoom_subscribers`
--

TRUNCATE TABLE `jos_acajoom_subscribers`;
--
-- Dumping data for table `jos_acajoom_subscribers`
--

INSERT INTO `jos_acajoom_subscribers` (`id`, `user_id`, `name`, `email`, `receive_html`, `confirmed`, `blacklist`, `timezone`, `language_iso`, `subscribe_date`, `params`) VALUES
(1, 62, 'Administrator', 'ngo.bieu@mwc.vn', 1, 1, 0, '00:00:00', 'eng', '2009-12-30 10:32:28', NULL),
(2, 63, 'client', 'client@client.com', 1, 1, 0, '00:00:00', 'eng', '2009-12-30 03:45:24', NULL),
(17, 0, '', 'cuongld85@yahoo.com', 1, 1, 0, '00:00:00', 'eng', '2011-12-16 04:13:09', ''),
(4, 69, 'Cuong', 'nguyen.cuong@mwc.vn', 1, 1, 0, '00:00:00', 'eng', '2010-01-13 07:14:47', NULL),
(5, 70, 'test2', 'a@a.a', 1, 1, 0, '00:00:00', 'eng', '2010-01-14 03:08:20', NULL),
(6, 71, 'Kim Hau', 'tkhau@mwc.vn', 1, 1, 0, '00:00:00', 'eng', '2010-01-20 13:14:16', NULL),
(7, 0, 'Tran Duy Loc', 'duylocstudy@gmail.com', 1, 1, 0, '00:00:00', 'eng', '2010-03-25 03:48:14', ''),
(8, 72, 'DFI', 'info@dfi.dk', 1, 1, 0, '00:00:00', 'eng', '2010-04-19 03:16:26', NULL),
(9, 73, 'Tran Duy Loc', 'tran.loc@mwc.vn', 1, 1, 0, '00:00:00', 'eng', '2010-04-22 04:34:21', NULL),
(10, 74, 'Kim Tran', 'info@mwc.vn', 1, 1, 0, '00:00:00', 'eng', '2010-05-19 09:13:56', NULL),
(11, 75, 'sdf', 'sdfs@sdfsdf.com', 1, 1, 0, '00:00:00', 'eng', '2010-05-21 03:37:15', NULL),
(12, 76, 'sdf', 'a@a.com', 1, 1, 0, '00:00:00', 'eng', '2010-05-21 03:38:04', NULL),
(13, 77, 'DFI Administrator', 'jesper@dinisenkraemmer.dk', 1, 1, 0, '00:00:00', 'eng', '2010-05-25 08:02:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jos_acajoom_xonfig`
--

CREATE TABLE IF NOT EXISTS `jos_acajoom_xonfig` (
  `akey` varchar(32) NOT NULL DEFAULT '',
  `text` varchar(254) NOT NULL DEFAULT '',
  `value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`akey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_acajoom_xonfig`
--

TRUNCATE TABLE `jos_acajoom_xonfig`;
--
-- Dumping data for table `jos_acajoom_xonfig`
--

INSERT INTO `jos_acajoom_xonfig` (`akey`, `text`, `value`) VALUES
('component', 'Acajoom', 0),
('type', 'GPL', 0),
('version', '3.2.7', 0),
('level', '1', 0),
('emailmethod', 'mail', 0),
('sendmail_from', 'ngo.bieu@mwc.vn', 0),
('sendmail_name', 'CMS-System', 0),
('sendmail_path', '/usr/sbin/sendmail', 0),
('smtp_host', 'localhost', 0),
('smtp_auth_required', '0', 0),
('smtp_username', '', 0),
('smtp_password', '', 0),
('embed_images', '0', 0),
('confirm_return', 'ngo.bieu@mwc.vn', 0),
('upload_url', '/components/com_acajoom/upload', 0),
('enable_statistics', '1', 0),
('statistics_per_subscriber', '1', 0),
('send_data', '1', 0),
('allow_unregistered', '1', 0),
('require_confirmation', '0', 0),
('redirectconfirm', '', 0),
('show_login', '1', 0),
('show_logout', '1', 0),
('send_unsubcribe', '1', 0),
('confirm_fromname', 'CMS-System', 0),
('confirm_fromemail', 'ngo.bieu@mwc.vn', 0),
('confirm_html', '1', 0),
('time_zone', '0', 0),
('show_archive', '1', 0),
('pause_time', '20', 0),
('emails_between_pauses', '65', 0),
('wait_for_user', '0', 0),
('script_timeout', '0', 0),
('display_trace', '1', 0),
('send_log', '1', 0),
('send_auto_log', '0', 0),
('send_log_simple', '0', 0),
('send_log_closed', '1', 0),
('save_log', '0', 0),
('send_email', '1', 0),
('save_log_simple', '0', 0),
('save_log_file', '/administrator/components/com_acajoom/com_acajoom.log', 0),
('send_log_address', '@ijoobi.com', 0),
('option', 'com_sdonkey', 0),
('send_log_name', 'Acajoom Mailing Report', 0),
('homesite', 'http://www.ijoobi.com', 0),
('report_site', 'http://www.ijoobi.com', 0),
('integration', '0', 0),
('cb_plugin', '1', 0),
('cb_listIds', '0', 0),
('cb_intro', '', 0),
('cb_showname', '1', 0),
('cb_checkLists', '1', 0),
('cb_showHTML', '1', 0),
('cb_defaultHTML', '1', 0),
('cb_integration', '0', 0),
('cb_pluginInstalled', '0', 0),
('cron_max_freq', '10', 0),
('cron_max_emails', '60', 0),
('last_cron', '', 0),
('last_sub_update', '1331796462', 0),
('next_autonews', '', 0),
('show_footer', '1', 0),
('show_signature', '1', 0),
('update_url', 'http://www.ijoobi.com/update/', 0),
('date_update', '2009-12-30 07:21:12', 0),
('update_message', '', 0),
('show_guide', '1', 0),
('news1', '0', 0),
('news2', '0', 0),
('news3', '0', 0),
('cron_setup', '0', 0),
('queuedate', '', 0),
('update_avail', '0', 0),
('show_tips', '1', 0),
('update_notification', '1', 0),
('show_lists', '1', 0),
('use_sef', '0', 0),
('listHTMLeditor', '1', 0),
('mod_pub', '1', 0),
('firstmailing', '0', 0),
('nblist', '9', 0),
('license', '', 0),
('token', '', 0),
('maintenance', '', 0),
('admin_debug', '0', 0),
('send_error', '1', 0),
('report_error', '1', 0),
('fullcheck', '0', 0),
('frequency', '0', 0),
('nb_days', '7', 0),
('date_type', '1', 0),
('arv_cat', '', 0),
('arv_sec', '', 0),
('maintenance_clear', '24', 0),
('clean_stats', '90', 0),
('maintenance_date', '', 0),
('mail_format', '1', 0),
('showtag', '0', 0),
('show_author', '1', 0),
('addEmailRedLink', '0', 0),
('itemidAca', '999', 0),
('show_jcalpro', '0', 0),
('disabletooltip', '0', 0),
('minisendmail', '0', 0),
('word_wrap', '0', 0),
('listname0', '', 0),
('listnames0', 'All mailings', 0),
('listype0', '1', 0),
('listshow0', '1', 0),
('classes0', '', 0),
('listlogo0', 'addedit.png', 0),
('totallist0', '', 1),
('act_totallist0', '', 1),
('totalmailing0', '', 0),
('totalmailingsent0', '', 0),
('act_totalmailing0', '', 0),
('totalsubcribers0', '', 15),
('act_totalsubcribers0', '', 11),
('listname1', '_ACA_NEWSLETTER', 0),
('listnames1', '_ACA_MENU_NEWSLETTERS', 0),
('listype1', '1', 0),
('listshow1', '1', 0),
('classes1', 'newsletter', 0),
('listlogo1', 'inbox.png', 0),
('totallist1', '', 1),
('act_totallist1', '', 1),
('totalmailing1', '', 0),
('totalmailingsent1', '', 0),
('act_totalmailing1', '', 0),
('totalsubcribers1', '', 0),
('act_totalsubcribers1', '', 0),
('listname2', '', 0),
('listnames2', '', 0),
('listype2', '', 0),
('listshow2', '', 0),
('classes2', 'autoresponder', 0),
('listlogo2', '', 0),
('totallist2', '', 0),
('act_totallist2', '', 0),
('totalmailing2', '', 0),
('totalmailingsent2', '', 0),
('act_totalmailing2', '', 0),
('totalsubcribers2', '', 0),
('act_totalsubcribers2', '', 0),
('listname3', '', 0),
('listnames3', '', 0),
('listype3', '', 0),
('listshow3', '', 0),
('classes3', '', 0),
('listlogo3', '', 0),
('totallist3', '', 0),
('act_totallist3', '', 0),
('totalmailing3', '', 0),
('totalmailingsent3', '', 0),
('act_totalmailing3', '', 0),
('totalsubcribers3', '', 0),
('act_totalsubcribers3', '', 0),
('listname4', '', 0),
('listnames4', '', 0),
('listype4', '', 0),
('listshow4', '', 0),
('classes4', '', 0),
('listlogo4', '', 0),
('totallist4', '', 0),
('act_totallist4', '', 0),
('totalmailing4', '', 0),
('totalmailingsent4', '', 0),
('act_totalmailing4', '', 0),
('totalsubcribers4', '', 0),
('act_totalsubcribers4', '', 0),
('listname5', '', 0),
('listnames5', '', 0),
('listype5', '', 0),
('listshow5', '', 0),
('classes5', '', 0),
('listlogo5', '', 0),
('totallist5', '', 0),
('act_totallist5', '', 0),
('totalmailing5', '', 0),
('totalmailingsent5', '', 0),
('act_totalmailing5', '', 0),
('totalsubcribers5', '', 0),
('act_totalsubcribers5', '', 0),
('listname6', '', 0),
('listnames6', '', 0),
('listype6', '', 0),
('listshow6', '', 0),
('classes6', '', 0),
('listlogo6', '', 0),
('totallist6', '', 0),
('act_totallist6', '', 0),
('totalmailing6', '', 0),
('totalmailingsent6', '', 0),
('act_totalmailing6', '', 0),
('totalsubcribers6', '', 0),
('act_totalsubcribers6', '', 0),
('listname7', '', 0),
('listnames7', '', 0),
('listype7', '', 0),
('listshow7', '', 0),
('classes7', 'autonews', 0),
('listlogo7', '', 0),
('totallist7', '', 0),
('act_totallist7', '', 0),
('totalmailing7', '', 0),
('totalmailingsent7', '', 0),
('act_totalmailing7', '', 0),
('totalsubcribers7', '', 0),
('act_totalsubcribers7', '', 0),
('listname8', '', 0),
('listnames8', '', 0),
('listype8', '', 0),
('listshow8', '', 0),
('classes8', '', 0),
('listlogo8', '', 0),
('totallist8', '', 0),
('act_totallist8', '', 0),
('totalmailing8', '', 0),
('totalmailingsent8', '', 0),
('act_totalmailing8', '', 0),
('totalsubcribers8', '', 0),
('act_totalsubcribers8', '', 0),
('activelist', '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_appeducation`
--

CREATE TABLE IF NOT EXISTS `jos_appeducation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_app` int(11) DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `education` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `appfrom` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `appto` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Truncate table before insert `jos_appeducation`
--

TRUNCATE TABLE `jos_appeducation`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_appformer`
--

CREATE TABLE IF NOT EXISTS `jos_appformer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_app` int(11) DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `job` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `appfrom` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `appto` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Truncate table before insert `jos_appformer`
--

TRUNCATE TABLE `jos_appformer`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_application`
--

CREATE TABLE IF NOT EXISTS `jos_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `cpr` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `marriage` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `children` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `numberchildren` int(11) DEFAULT NULL,
  `contact` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `works` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `former` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `license` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `attached` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `comments` text CHARACTER SET utf8,
  `received` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `dato` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Truncate table before insert `jos_application`
--

TRUNCATE TABLE `jos_application`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_banner`
--

CREATE TABLE IF NOT EXISTS `jos_banner` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL DEFAULT 'banner',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `imageurl` varchar(100) NOT NULL DEFAULT '',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `showBanner` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `custombannercode` text,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tags` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`bid`),
  KEY `viewbanner` (`showBanner`),
  KEY `idx_banner_catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_banner`
--

TRUNCATE TABLE `jos_banner`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_bannerclient`
--

CREATE TABLE IF NOT EXISTS `jos_bannerclient` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` time DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_bannerclient`
--

TRUNCATE TABLE `jos_bannerclient`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_bannertrack`
--

CREATE TABLE IF NOT EXISTS `jos_bannertrack` (
  `track_date` date NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_bannertrack`
--

TRUNCATE TABLE `jos_bannertrack`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_categories`
--

CREATE TABLE IF NOT EXISTS `jos_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `section` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(30) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Truncate table before insert `jos_categories`
--

TRUNCATE TABLE `jos_categories`;
--
-- Dumping data for table `jos_categories`
--

INSERT INTO `jos_categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES
(1, 0, 'DÆKCENTER JYLLAND', '', 'daekcenter-jylland', '', 'com_dfi_catalog', 'left', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(11, 0, 'Nyheder', '', 'nyheder', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(8, 0, 'DÆKCENTER FYN', '', 'daekcenter-fyn', '', 'com_dfi_catalog', 'left', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 62, '2015-03-27 10:54:03', NULL, 2, 0, 0, ''),
(9, 0, 'DÆKCENTER SJÆLLAND', '', 'daekcenter-sjaelland', '', 'com_dfi_catalog', 'left', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, ''),
(10, 0, 'DÆKCENTER LOLLAND - FALSTER', '', 'daekcenter-lolland-falster', '', 'com_dfi_catalog', 'left', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_components`
--

CREATE TABLE IF NOT EXISTS `jos_components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) unsigned NOT NULL DEFAULT '0',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_menu_link` varchar(255) NOT NULL DEFAULT '',
  `admin_menu_alt` varchar(255) NOT NULL DEFAULT '',
  `option` varchar(50) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `admin_menu_img` varchar(255) NOT NULL DEFAULT '',
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `parent_option` (`parent`,`option`(32))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=117 ;

--
-- Truncate table before insert `jos_components`
--

TRUNCATE TABLE `jos_components`;
--
-- Dumping data for table `jos_components`
--

INSERT INTO `jos_components` (`id`, `name`, `link`, `menuid`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `iscore`, `params`, `enabled`) VALUES
(1, 'Banners', '', 0, 0, '', 'Banner Management', 'com_banners', 36, 'js/ThemeOffice/component.png', 0, 'track_impressions=0\ntrack_clicks=0\ntag_prefix=\n\n', 1),
(2, 'Banners', '', 0, 1, 'option=com_banners', 'Active Banners', 'com_banners', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(3, 'Clients', '', 0, 1, 'option=com_banners&c=client', 'Manage Clients', 'com_banners', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(45, 'Newsletters', '', 0, 42, 'option=com_acajoom&act=mailing&listype=1', 'Newsletters', 'com_acajoom', 2, '../includes/js/ThemeOffice/messaging_inbox.png', 0, '', 1),
(46, 'Statistics', '', 0, 42, 'option=com_acajoom&act=statistics', 'Statistics', 'com_acajoom', 3, '../includes/js/ThemeOffice/query.png', 0, '', 1),
(47, 'Configuration', '', 0, 42, 'option=com_acajoom&act=configuration', 'Configuration', 'com_acajoom', 4, '../includes/js/ThemeOffice/menus.png', 0, '', 1),
(7, 'Contacts', 'option=com_contact', 0, 0, '', 'Edit contact details', 'com_contact', 32, 'js/ThemeOffice/component.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(8, 'Contacts', '', 0, 7, 'option=com_contact', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/edit.png', 1, '', 1),
(9, 'Categories', '', 0, 7, 'option=com_categories&section=com_contact_details', 'Manage contact categories', '', 2, 'js/ThemeOffice/categories.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(44, 'Subscribers', '', 0, 42, 'option=com_acajoom&act=subscribers', 'Subscribers', 'com_acajoom', 1, '../includes/js/ThemeOffice/users_add.png', 0, '', 1),
(40, 'RokQuickCart', '', 0, 0, '', 'RokQuickCart', 'com_rokquickcart', 27, '', 0, '', 1),
(41, 'Translation Manager', 'option=com_translationsmanager', 0, 0, 'option=com_translationsmanager', 'Translation Manager', 'com_translationsmanager', 51, 'class:language', 0, '', 1),
(42, 'Acajoom', 'option=com_acajoom', 0, 0, 'option=com_acajoom', 'Acajoom', 'com_acajoom', 37, '../administrator/components/com_acajoom/images/acajoom_icon.png', 0, '', 0),
(43, 'Lists', '', 0, 42, 'option=com_acajoom&act=list', 'Lists', 'com_acajoom', 0, '../includes/js/ThemeOffice/edit.png', 0, '', 1),
(14, 'User', 'option=com_user', 0, 0, '', '', 'com_user', 21, '', 1, '', 1),
(15, 'Search', 'option=com_search', 0, 0, 'option=com_search', 'Search Statistics', 'com_search', 24, 'js/ThemeOffice/component.png', 1, 'enabled=0\n\n', 1),
(16, 'Categories', '', 0, 1, 'option=com_categories&section=com_banner', 'Categories', '', 3, '', 1, '', 1),
(17, 'Wrapper', 'option=com_wrapper', 0, 0, '', 'Wrapper', 'com_wrapper', 4, '', 1, '', 1),
(18, 'Mail To', '', 0, 0, '', '', 'com_mailto', 13, '', 1, '', 1),
(19, 'Media Manager', '', 0, 0, 'option=com_media', 'Media Manager', 'com_media', 11, '', 1, 'upload_extensions=bmp,csv,doc,epg,gif,ico,jpg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,EPG,GIF,ICO,JPG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\nupload_maxsize=10000000\nfile_path=images\nimage_path=images/stories\nrestrict_uploads=1\nallowed_media_usergroup=3\ncheck_mime=1\nimage_extensions=bmp,gif,jpg,png\nignore_extensions=\nupload_mime=image/jpeg,image/gif,image/png,image/bmp,application/x-shockwave-flash,application/msword,application/excel,application/pdf,application/powerpoint,text/plain,application/x-zip\nupload_mime_illegal=text/html\nenable_flash=0\n\n', 1),
(20, 'Articles', 'option=com_content', 0, 0, '', '', 'com_content', 31, '', 1, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=0\n\n', 1),
(21, 'Configuration Manager', '', 0, 0, '', 'Configuration', 'com_config', 33, '', 1, '', 1),
(22, 'Installation Manager', '', 0, 0, '', 'Installer', 'com_installer', 40, '', 1, '', 1),
(23, 'Language Manager', '', 0, 0, '', 'Languages', 'com_languages', 28, '', 1, 'site=da-DK\n\n', 1),
(24, 'Mass mail', '', 0, 0, '', 'Mass Mail', 'com_massmail', 12, '', 1, 'mailSubjectPrefix=\nmailBodySuffix=\n\n', 1),
(25, 'Menu Editor', '', 0, 0, '', 'Menu Editor', 'com_menus', 10, '', 1, '', 1),
(27, 'Messaging', '', 0, 0, '', 'Messages', 'com_messages', 9, '', 1, '', 1),
(28, 'Modules Manager', '', 0, 0, '', 'Modules', 'com_modules', 8, '', 1, '', 1),
(29, 'Plugin Manager', '', 0, 0, '', 'Plugins', 'com_plugins', 16, '', 1, '', 1),
(30, 'Template Manager', '', 0, 0, '', 'Templates', 'com_templates', 22, '', 1, '', 1),
(31, 'User Manager', '', 0, 0, '', 'Users', 'com_users', 20, '', 1, 'allowUserRegistration=1\nnew_usertype=Registered\nuseractivation=0\nfrontend_userparams=1\n\n', 1),
(32, 'Cache Manager', '', 0, 0, '', 'Cache', 'com_cache', 35, '', 1, '', 1),
(33, 'Control Panel', '', 0, 0, '', 'Control Panel', 'com_cpanel', 30, '', 1, '', 1),
(48, 'Import', '', 0, 42, 'option=com_acajoom&act=update', 'Import', 'com_acajoom', 5, '../includes/js/ThemeOffice/restore.png', 0, '', 1),
(49, 'About', '', 0, 42, 'option=com_acajoom&act=about', 'About', 'com_acajoom', 6, '../includes/js/ThemeOffice/credits.png', 0, '', 1),
(50, 'System', 'option=com_component', 0, 0, 'option=com_component', 'System', 'com_component', 54, '../images/rokquickcart/menu/icon-16-component.png', 0, 'com_component=component_config.xml\ncom_contact=config.xml\ncom_content=config.xml\ncom_media=config.xml\ncom_users=config.xml\ncom_weblinks=config.xml\ncom_newsfeeds=config.xml\ncom_banners=config.xml\n\n', 0),
(51, 'Control Panel', '', 0, 50, 'option=com_component&view=cpanel', 'DFI Control Panel', 'com_component', 1, '../includes/js/ThemeOffice/component.png', 0, 'com_component=component_config.xml\ncom_contact=config.xml\ncom_content=config.xml\ncom_media=config.xml\ncom_users=config.xml\ncom_weblinks=config.xml\ncom_newsfeeds=config.xml\ncom_banners=config.xml\n\n', 1),
(52, 'Resize_thumbnail', '', 0, 0, '', 'Resize_thumbnail', 'com_resize_thumbnail', 17, '', 0, '', 1),
(53, 'Dfi_shop', '', 0, 0, '', 'Dfi_shop', 'com_dfi_shop', 44, '', 0, '', 1),
(54, 'Shop', '', 0, 97, 'option=com_dfi_shop', 'Shop', 'com_dfi_shop', 2, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(55, 'Dfi_member', '', 0, 0, '', 'Dfi_member', 'com_dfi_member', 50, '', 0, '', 0),
(57, 'Dfi_supplier', '', 0, 0, '', 'Dfi_supplier', 'com_dfi_supplier', 43, '', 0, '', 0),
(58, 'Leverandør', '', 0, 97, 'option=com_dfi_supplier', 'Leverandør', 'com_dfi_supplier', 8, '../includes/js/ThemeOffice/component.png', 0, '', 0),
(59, 'Dfi_product', '', 0, 0, '', 'Dfi_product', 'com_dfi_product', 46, '', 0, '', 1),
(60, 'Produkt', '', 0, 97, 'option=com_dfi_product', 'Produkt', 'com_dfi_product', 9, '../includes/js/ThemeOffice/component.png', 0, '', 0),
(62, 'Kampagne', '', 0, 97, 'option=com_dfi_campaign', 'Kampagne', 'com_dfi_campaign', 10, '../includes/js/ThemeOffice/component.png', 0, '', 0),
(64, 'Dfi_order_status', '', 0, 0, '', 'Dfi_order_status', 'com_dfi_order_status', 47, '', 0, '', 0),
(65, 'Status', '', 0, 97, 'option=com_dfi_order_status', 'Status', 'com_dfi_order_status', 11, '../includes/js/ThemeOffice/component.png', 0, '', 0),
(66, 'Dfi_catalog', '', 0, 0, '', 'Dfi_catalog', 'com_dfi_catalog', 38, '', 0, '', 1),
(67, 'Catalog', '', 0, 102, 'option=com_dfi_catalog', 'Catalog', 'com_dfi_catalog', 12, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(68, 'Category', '', 0, 102, 'option=com_categories&section=com_dfi_catalog', 'Category', 'com_categories', 13, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(69, 'Dfi_map', '', 0, 0, '', 'Dfi_map', 'com_dfi_map', 39, '', 0, '', 1),
(70, 'Shop Map', '', 0, 102, 'option=com_dfi_map', 'Shop Map', 'com_dfi_map', 14, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(71, 'Dfi_order', '', 0, 0, '', 'Dfi_order', 'com_dfi_order', 49, '', 0, '', 0),
(72, 'Ordre', '', 0, 97, 'option=com_dfi_order', 'Ordre', 'com_dfi_order', 15, '../includes/js/ThemeOffice/component.png', 0, '', 0),
(73, 'Dfi_order_product', '', 0, 0, '', 'Dfi_order_product', 'com_dfi_order_product', 48, '', 0, '', 0),
(74, 'Dfi_report', '', 0, 0, '', 'Dfi_report', 'com_dfi_report', 45, '', 0, '', 0),
(75, 'DFI Report Manager', '', 0, 97, 'option=com_dfi_report', 'DFI Report Manager', 'com_dfi_report', 16, '../includes/js/ThemeOffice/component.png', 0, '', 0),
(76, 'Home', 'option=com_home', 0, 0, '', 'Home', 'com_home', 41, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(77, 'Omos', 'option=com_omos', 0, 0, '', 'Omos', 'com_omos', 5, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(78, 'Nyheder', 'option=com_nyheder', 0, 0, '', 'Nyheder', 'com_nyheder', 6, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(79, 'Kontakt', 'option=com_kontakt', 0, 0, '', 'Kontakt', 'com_kontakt', 29, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(80, 'Search_result', '', 0, 0, '', 'Search_result', 'com_search_result', 23, '', 0, '', 1),
(96, 'Catalog', '', 0, 0, '', 'Catalog', 'com_catalog', 34, '', 0, '', 1),
(84, 'Varedatabase', 'option=com_varedatabase', 0, 0, '', 'Varedatabase', 'com_varedatabase', 19, '../includes/js/ThemeOffice/component.png', 0, '', 0),
(86, 'Salgsrapportering', 'option=com_salgsrapportering', 0, 0, '', 'Salgsrapportering', 'com_salgsrapportering', 26, '../includes/js/ThemeOffice/component.png', 0, '', 0),
(97, 'DI Store', '', 0, 0, '', '', '', 53, '../images/rokquickcart/module___icon.png', 0, '', 1),
(90, 'Lever', 'option=com_lever', 0, 0, '', 'Lever', 'com_lever', 14, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(91, 'Myshop', 'option=com_myshop', 0, 0, '', 'Myshop', 'com_myshop', 7, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(92, 'Order', '', 0, 0, '', 'Order', 'com_order', 15, '', 0, '', 1),
(93, 'Workers', 'option=com_workers', 0, 0, '', 'Workers', 'com_workers', 18, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(95, 'Salgsrapportering2', '', 0, 0, '', 'Salgsrapportering2', 'com_salgsrapportering2', 25, '', 0, '', 1),
(99, 'Dfi_kobreak', '', 0, 0, '', 'Dfi_kobreak', 'com_dfi_kobreak', 2, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(100, 'Dfi_kobreak_product', '', 0, 0, '', 'Dfi_kobreak_product', 'com_dfi_kobreak_product', 1, '', 0, '', 1),
(101, 'Dfi_folder', '', 0, 0, '', 'Dfi_folder', 'com_dfi_folder', 3, '', 0, '', 1),
(102, 'DI Content', '', 0, 0, '', '', '', 52, '../images/rokquickcart/module___icon.png', 0, '', 1),
(103, 'Købeark', '', 0, 97, 'option=com_dfi_kobreak', 'Købeark', 'com_dfi_kobreak', 17, '../images/rokquickcart/module___icon.png', 0, '', 0),
(104, 'Dfi_distribution_rate', '', 0, 0, '', 'Dfi_distribution_rate', 'com_dfi_distribution_rate', 0, '', 0, '', 1),
(106, 'Dfi_campaign_to_product', '', 0, 0, '', 'Dfi_campaign_to_product', 'com_dfi_campaign_to_product', 0, '../includes/js/ThemeOffice/component.png', 0, '', 1),
(108, 'Dfi_review_product', '', 0, 0, '', 'Dfi_review_product', 'com_dfi_review_product', 0, '', 0, '', 1),
(109, 'Ajourmaster', '', 0, 97, 'option=com_dfi_order&view=active_checkbox', 'Ajourmaster', 'com_dfi_kobreak', 17, '../images/rokquickcart/module___icon.png', 0, '', 0),
(110, 'Omsætning', '', 0, 97, 'option=com_dfi_monthly', 'Omsætning', 'com_dfi_monthly', 17, '../images/rokquickcart/module___icon.png', 0, '', 0),
(111, 'Application', 'option=com_date', 0, 0, 'option=com_date', 'Application', 'com_date', 0, 'js/ThemeOffice/component.png', 0, '', 0),
(112, 'JCE', 'option=com_jce', 0, 0, 'option=com_jce', 'JCE', 'com_jce', 0, 'components/com_jce/media/img/menu/logo.png', 0, '{"editor":{"verify_html":"0","entity_encoding":"raw","cleanup_pluginmode":"0","forced_root_block":"0","newlines":"1","content_style_reset":"0","content_css":"1","content_css_custom":"","compress_javascript":"0","compress_css":"0","compress_gzip":"0","use_cookies":"1","custom_config":"","callback_file":""}}', 1),
(113, 'WF_MENU_CPANEL', '', 0, 112, 'option=com_jce', 'WF_MENU_CPANEL', 'com_jce', 0, 'components/com_jce/media/img/menu/jce-cpanel.png', 0, '', 1),
(114, 'WF_MENU_CONFIG', '', 0, 112, 'option=com_jce&view=config', 'WF_MENU_CONFIG', 'com_jce', 1, 'components/com_jce/media/img/menu/jce-config.png', 0, '', 1),
(115, 'WF_MENU_PROFILES', '', 0, 112, 'option=com_jce&view=profiles', 'WF_MENU_PROFILES', 'com_jce', 2, 'components/com_jce/media/img/menu/jce-profiles.png', 0, '', 1),
(116, 'WF_MENU_INSTALL', '', 0, 112, 'option=com_jce&view=installer', 'WF_MENU_INSTALL', 'com_jce', 3, 'components/com_jce/media/img/menu/jce-install.png', 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_contact_details`
--

CREATE TABLE IF NOT EXISTS `jos_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `imagepos` varchar(20) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Truncate table before insert `jos_contact_details`
--

TRUNCATE TABLE `jos_contact_details`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_content`
--

CREATE TABLE IF NOT EXISTS `jos_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `title_alias` varchar(255) NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `sectionid` int(11) unsigned NOT NULL DEFAULT '0',
  `mask` int(11) unsigned NOT NULL DEFAULT '0',
  `catid` int(11) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` text NOT NULL,
  `version` int(11) unsigned NOT NULL DEFAULT '1',
  `parentid` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(11) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `article_image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_section` (`sectionid`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=46 ;

--
-- Truncate table before insert `jos_content`
--

TRUNCATE TABLE `jos_content`;
--
-- Dumping data for table `jos_content`
--

INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `article_image`) VALUES
(25, 'Bliv forhandler', 'bliv-forhandler', '', '<div class="fb-like" data-font="arial" data-href="http://daekcenter.nu/index.php?option=com_content&amp;view=article&amp;id=25&amp;Itemid=28" data-send="true" data-width="450" data-show-faces="false">&nbsp;</div>\r\n<h1>VI HAR ET PAR SPØRGSMÅL DER KAN ÆNDRE DIN BUTIK...</h1>\r\n<ul>\r\n<li>Sælger du dæk, men kunne du tænke dig at sælge mange dæk ?</li>\r\n<li>Og kunne du tænke dig et system, som gør det nemt, enkelt og ensartet hver gang ?</li>\r\n<li>Vil du have adgang til en af Danmarks største dæk leverandører med mere end 40 dækmærker ? se alle mærker <a href="index.php?option=com_content&amp;view=category&amp;layout=daek-faelge&amp;id=11&amp;Itemid=27">HER</a></li>\r\n<li>Og samtidig blive synlig for dine kunder ?</li>\r\n<li>Intet gebyr, ingen binding, ingen risiko.</li>\r\n<li>Kick Back på dit års køb</li>\r\n</ul>\r\n<h2>Noget af det vi tit hører i dækbranchen er:</h2>\r\n<ul>\r\n<li>Vi skal altid regne tilbud ud til kunder... – DET TAGER TID!!!!</li>\r\n<li>Vores kunder kan ikke se hvilke dæk mærker vi har på lager...</li>\r\n<li>For at få en god rabat, skal vi købe et stort dæk lager hjem... Kapital binding!!!!</li>\r\n<li>Vi har ikke plads til et dæk lager...</li>\r\n<li>Vi har ikke tid til at lave en lagerstyring, og vedligeholde den...</li>\r\n<li>Vi er ikke synlige som dækcenter...</li>\r\n<li>Er vi med i en dækkæde, skal andre bestemme vores pris...</li>\r\n</ul>\r\n<p>Kunne du tænke dig at blive DÆKCENTER, med de fordele vi kan tilbyde, og helt selv kunne bestemme over dit ”DÆKCENTER” ?</p>\r\n<p>Vel og mærke uden at skulle bruge penge på opstart, køb af system, bruge tid på vedligeholdelse – blot bruge kræfterne på at sælge dæk, og derved få nye og flere kunder i butikken ?</p>\r\n<p>Hvis du siger ja til dette, så er DÆKCENTER noget for dig! Kontakt os på <a href="mailto:info@daekcenter.nu">info@daekcenter.nu</a></p>', '', 1, 1, 0, 11, '2012-05-24 08:41:23', 62, '', '2014-03-04 13:34:49', 62, 62, '2014-12-04 12:17:12', '2012-05-24 08:41:23', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 8, 0, 13, '', '', 0, 7090, 'robots=\nauthor=', ''),
(26, 'Dækmærker', 'daekmaerker', '', '<h1 style="text-transform: uppercase;">Dækmærker som der forhandles igennem www.dækcenter.nu kæden</h1>\r\n<p>Vi forhandler alle Dækmærker fra de&nbsp;største Dækleverandøre fra hele verden - læs mere om dækmærkerne her.</p>\r\n<div class="fb-like" data-href="http://daekcenter.nu/index.php?option=com_content&amp;view=category&amp;layout=daek-faelge&amp;id=11&amp;Itemid=27" data-send="true" data-width="450" data-show-faces="false" data-font="arial"></div>', '', 1, 1, 0, 11, '2012-06-05 10:06:46', 62, '', '2013-05-27 09:44:46', 62, 0, '0000-00-00 00:00:00', '2012-06-05 10:06:46', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 8, 0, 12, '', '', 0, 79, 'robots=\nauthor=', ''),
(27, 'sdfdf', 'sdfdf', '', '<p>fdfdsfdsfsdfsdfdfsf</p>', '', -2, 0, 0, 0, '2012-06-10 06:11:05', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2012-06-10 06:11:05', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 0, '', '', 0, 0, 'robots=\nauthor=', ''),
(28, 'Teknisk info - Dæk FB TEST', 'daek-og-faelg-info', '', '<h1><span style="text-decoration: underline;"><span style="font-size: 18pt;"><br /></span><span style="font-size: 18pt;">TRYK</span><span style="font-size: 18pt;"> FOR INFO OM:</span><span style="font-size: 18pt;"><br /><br /></span></span> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=37&amp;Itemid=35" target="_self"><img width="229" height="38" alt="DÆK" src="images/DÆK.png" /></a> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=31&amp;Itemid=35" target="_self"><img width="248" height="38" alt="FÆLGE" src="images/FÆLGE.png" /></a> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=32&amp;Itemid=35" target="_self"><img width="231" height="38" alt="HJUL" src="images/HJUL.png" /></a><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=34&amp;Itemid=35" target="_self"><img width="275" height="38" alt="EU" src="images/EU.png" /></a> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=33&amp;Itemid=35" target="_self"><img width="357" height="38" alt="VEDLIGEHOLDELSE" src="images/VEDLIGEHOLDELSE.png" /></a><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=35&amp;Itemid=35" target="_self"><img width="259" height="38" alt="UDSKIFTNING" src="images/UDSKIFTNING.png" /></a> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=30&amp;Itemid=35" target="_self"><img width="242" height="38" alt="VINTERDÆK" src="images/VINTERDÆK.png" /></a><br /><img width="722" height="226" style="width: 722px; height: 255px;" alt="DK-CENTER LOGO" src="images/DK-CENTER_LOGO.jpg" /></h1>\r\n<h1>&nbsp;</h1>', '', 1, 1, 0, 11, '2012-06-11 03:48:33', 62, '', '2013-12-30 09:31:44', 62, 62, '2014-01-10 14:08:38', '2012-06-11 03:48:33', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 48, 0, 11, '', '', 0, 10311, 'robots=\nauthor=', ''),
(29, 'Dækikoner', 'daekikoner', '', '<p>Test1</p>', '', -2, 0, 0, 0, '2012-06-19 17:27:30', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2012-06-19 17:27:30', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 0, '', '', 0, 0, 'robots=\nauthor=', ''),
(30, 'Vinterdæk regler I EU', 'vinterdaek-regler', '', '<h1>Europæiske vinterdækregler</h1>\r\n<p><img width="211" height="139" alt="vinter" src="images/vinter.png" /><br /><br />Når vinteren og skiferien kommer tættere på, er det tid til at få styr på reglerne for vinterdæk og vinterudstyr i de lande, man skal besøge i løbeet af vinteren.&nbsp;Dækcenter.nu har derfor lavet en oversigt, hvor du kan se reglerne for de mest populære vinterferiedestinationer: Sverige, Norge, Tyskland, Østrig, Schweiz, Frankrig og Italien.</p>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><img width="164" height="101" style="margin-right: 20px;" alt="sverige" src="images/sverige.gif" /></td>\r\n<td>\r\n<h2><strong>Sverige - Vinterdæk regler Sverige</strong></h2>\r\n<p>&nbsp;</p>\r\n<h3>Vinterdæk</h3>\r\n<p>For køretøjer med en tilladt totalvægt på under 3500 kg er vinterdæk obligatorisk mellem 1. december og 31. marts i tilfælde af vintervej. Dvs. sne eller is på vejen eller en våd vejoverflade kombineret med temperaturer omkring eller under 0ºC. Dette gælder også for anhængere. Dækkene skal have en mønsterdybde på minimum 3 mm.</p>\r\n<p>Politiet tager den endelig beslutning om, hvornår der er tale om vintervejr på specifikke veje. Er der ikke tale om vintervejr på vejene, må man principielt gerne køre med sommerdæk i perioden mellem mellem 1. december og 31. marts, selvom dette dog ikke anbefales.</p>\r\n<p>Bøden for ikke at køre med vinterdæk i vintervejr er 1200 SEK.</p>\r\n<p>Reglerne for vinterdæk gælder ikke køretøjer med en totalvægt over 3500 kg. Sådanne køretøjer må selv i vintervejr køre med sommerdæk. I så fald skal dækkene være mindst 5 mm dybe.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Pigdæk er tilladt mellem 1. oktober og 15. april. Hvis vejr- og vejforholdene kræver det, er de også tilladt uden for denne periode. Dette vil oftest være tilfældet i den nordlige del af landet. Benyttes pigdæk, skal de monteres på alle 4 hjul. For biler med pigdæk, der trækker en anhænger, er det kun nødvendigt at montere pigdæk på anhængeren, såfremt man kører på sne- eller isdækkede veje. Bemærk, at der kan være enkelte lokale restriktioner for kørsel med pigdæk. F.eks. er pigdæk ikke tilladt på Hornsgatan i Stockholm.</p>\r\n<h3>Snekæder</h3>\r\n<p>Det er tilladt at benytte snekæder på alle typer biler i Sverige, hvis vejr- og vejforhold kræver det. Der er ingen særlige fartgrænser for køretøjer med snekæder. Det er ikke muligt at leje snekæder i Sverige, men de kan købes.</p>\r\n<h3>Andet udstyr</h3>\r\n<p>Det er nødvendigt, at bilen har sprinklervæske med antifrost, ligesom man skal medbringe en skovl til at fjerne sne. Det anbefales også at medbringe et reb, startkabler og sikkerhedsvest.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td style="text-align: justify;"><img width="165" height="120" style="margin-right: 20px;" alt="norge" src="images/norge.gif" /></td>\r\n<td>\r\n<h2><strong>Norge - Vinterdæk regler Norge</strong></h2>\r\n<p>&nbsp;</p>\r\n<h3>Vinterdæk</h3>\r\n<p>I den norske færdselslov står der: "Når føret gør det nødvendigt, må et motorkøretøj ikke bruges, uden at hjulene er sikret tilstrækkeligt vejgreb ved hjælp af pigge, snekæder eller lignende". Det betyder i praksis, at man om vinteren skal køre med vinterdæk eller pigdæk. Vinterdæk skal monteres på alle 4 hjul og have en minimumdybde på 3 mm.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Det er tilladt at køre med pigdæk fra 1. nov. til første søndag i den følgende påske. I de nordlige provinser (Nordland, Troms og Finnmark) er det dog tilladt at køre med pigdæk fra 15. okt. til 1. april. Pigdæk skal monteres på alle fire hjul, når de benyttes. Nogle byer har indført afgift for at køre med pigdæk.</p>\r\n<h3>Snekæder</h3>\r\n<p>Man skal medbringe snekæder ved kørsel i Norge, da man kan komme i situationer, hvor vinterdæk ikke er nok, og da vil lovgivningen kræve, at man benytter snekæder.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><img width="165" height="99" style="margin-right: 20px;" alt="Tyskland" src="images/Tyskland.gif" /></td>\r\n<td>\r\n<h2><strong>Tyskland - Vinterdæk regler Tyskland</strong>&nbsp;</h2>\r\n<p>&nbsp;</p>\r\n<h3>Vinterdæk</h3>\r\n<p>Ifølge loven skal biler i Tyskland være udstyret med vinterdæk, når der er sne, snesjap, frost eller is på vejene. Dækkene skal være vinterdæk mærket med M+S og et snefnugssymbol eller være helårsdæk mærket M+S. Derudover skal man sørge for, at sprinklervæsken er med antifrost. Er bilen ikke udstyret med dæk, der passer til vejrforholdene, kan man få en bøde på 40 euro. Hindrer bilen trafikken, fordi den ikke er udstyret med de rigtige dæk, kan bøden være 80 euro. Der er ikke særskilt krav om vinterdæk på anhængere, men det anbefales.</p>\r\n<p>&nbsp;</p>\r\n<h3>Pigdæk</h3>\r\n<p>Det er ikke tilladt at køre med pigdæk i Tyskland.</p>\r\n<h3>Snekæder</h3>\r\n<p>Det er tilladt at benytte snekæder. I så fald er der en fartgrænse på 50 km/t. I bjergområder vil der i vintervejr være skilte, hvis snekæder er påkrævet.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td><img width="166" height="111" style="margin-right: 20px;" alt="oestrig" src="images/oestrig.gif" /></td>\r\n<td>\r\n<h2><strong>Østrig - Vinterdæk regler Østrig</strong></h2>\r\n<p>&nbsp;</p>\r\n<h3>Vinterdæk</h3>\r\n<p>Fra den 1. november til den 15. april skal der være vinterdæk på bilen, når det er vinterføre. Det vil sige, når vejene er dækket af sne, slud eller is. Vinterdækkene skal monteres på alle 4 hjul, og de skal være mærket med M+S og have en dybde på minimum 4 mm. Kørsel med sommerdæk kan dog accepteres, såfremt man har monteret snekæder på de trækkende hjul. I så fald er den anbefalede makshastighed 50 km/t. Det er i øvrigt førerens ansvar, at bilen er udstyret med det nødvendige vinterudstyr. Hvis man lejer en bil, skal man derfor selv huske at tjekke, om det påkrævede vinterudstyr forefindes.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Pigdæk er tilladt fra 1. oktober til 31. maj, dog kun på køretøjer op til 3.500 kg. Der skal i så fald være pigdæk på alle 4 hjul samt på en evt. anhænger. Maks. hastighed med pigdæk er på motorvej 100 km/t og på landevej 80 km/t.<br />Når man kører med pigdæk, skal der desuden i bagruden påsættes en "pigdæksmærkat". Denne kan købes hos FDMs søsterklub <a class="  " href="http://www.oeamtc.at/" target="_blank">ÖAMTC</a>, på tankstationer mv.</p>\r\n<h3>Snekæder</h3>\r\n<p>Snekæder er tilladt i Østrig. Kører man med snekæder, er den anbefalede maksimumhastighed 50 km/t. Kæder skal have godkendelsen ÖNORM V 5117 for mindre køretøjer og ÖNORM V 5119 for større køretøjer.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p>Man kan købe eller låne snekæder på <a class="  " href="http://www.oeamtc.at/" target="_blank">ÖAMTCs</a> kontorer, eller man man leje dem ved alle større grænseovergange.</p>\r\n<p>&nbsp;</p>\r\n<h3>Specielt for tunge køretøjer</h3>\r\n<p>Fra 15. november til 15. marts skal alle køretøjer over 3500 kg køre med vinterdæk på mindst en af køreakslerne og medbringe snekæder - uanset om der er sne på vejen eller ej. Vinterdækkene skal være mærket M+S, og radialdæk skal være mindst 5 mm dybe, mens diagonaldæk skal være mindst 6 mm dybe. Det er obligatorisk at køre med snekæder, når skiltningen indikerer det.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><img width="165" height="165" style="margin-right: 20px;" alt="schweiz" src="images/schweiz.gif" /></td>\r\n<td>\r\n<h2><strong>Schweiz - Vinterdæk regler Schweiz</strong></h2>\r\n<p>&nbsp;</p>\r\n<h3>Vinterdæk</h3>\r\n<p>Vinterdæk er ikke påbudt, men køretøjer, der ikke er udrustet til at køre i vintervejr, kan idømmes bøder. I praksis betyder det, at man skal køre med vinterdæk og medbringe snekæder.</p>\r\n<p>&nbsp;</p>\r\n<h3>Pigdæk</h3>\r\n<p>Pigdæk er tilladt i perioden fra 1. november til 30. april på køretøjer under 7500 kg samt på evt. anhængere. Piggene på maks være 1,5 mm. Det er dog forbudt at køre med pigdæk på motor- og motortrafikveje med undtagelse af San Bernardino- og St. Gotthard-vejtunnelerne, hvor pigdæk er tilladt. Køretøjer med pigdæk må maks køre 80 km/t, hvilket skal angives på bilen i form af et fartklistermærke.</p>\r\n<h3>Snekæder</h3>\r\n<p>Snekæder er obligatoriske i områder, hvor der er skiltet med det. Snekæder monteres som minimum på de trækkende hjul.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td><img width="165" height="110" style="margin-right: 20px;" alt="frankrig" src="images/frankrig.gif" /></td>\r\n<td>\r\n<h2><strong>Frankrig - Vinterdæk regler Frankrig</strong></h2>\r\n<p>&nbsp;</p>\r\n<h3>Vinterdæk</h3>\r\n<p>Det er ikke obligatorisk at køre med vinterdæk i Frankrig, men det anbefales, når der er sne eller is på vejene. Dækmønsteret skal minimum være 3,5 mm.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Brugen af pigdæk er tilladt fra lørdagen før 1. november til den sidste søndag i marts på biler under 3500 kg samt kommercielle passagerkøretøjer. Max hastighed ved kørsel med pigdæk er 90 km/t. Hvis vejrforholdene kræver det, kan myndighederne udvide perioden for brug af pigdæk.</p>\r\n<h3>Snekæder</h3>\r\n<p>Snekæder skal benyttes, når skiltningen indikerer det. Der kan udstedes bøde, hvis man ikke overholder dette. Køretøjer med snekæder må ikke køre hurtigere end 50 km/t.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><img width="164" height="110" style="margin-right: 20px;" alt="italie" src="images/italie.gif" /></td>\r\n<td>\r\n<h2><strong>Italien - Vinterdæk regler Italien</strong></h2>\r\n<p>&nbsp;</p>\r\n<h3>Vinterdæk</h3>\r\n<p>I Aostadalen skal bilen være udstyret med vinterdæk, eller man skal medbringe snekæder i perioden 15/10 til 15/4.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Pigdæk er tilladt fra 15/11 til 15/3 for køretøjer under 3500 kg. Makshastighed på motorvej er 120 km/t, på landevej 90 km/t. Kører man med pigdæk skal alle køretøjets hjul være udstyret med pigdæk - også en evt. anhænger. Desuden anbefales stænklapper.</p>\r\n<h3>Snekæder</h3>\r\n<p>Ved skiltning omkring snekæder accepteres både kørsel med snekæder og med vinterdæk. Biler udstyret med snekæder må maks køre 50 km/t.</p>\r\n<h3>&nbsp;</h3>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', '', 1, 1, 0, 11, '2012-06-20 04:03:09', 62, '', '2013-09-02 07:09:25', 62, 0, '0000-00-00 00:00:00', '2012-06-20 04:03:09', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 9, 0, 10, '', '', 0, 5555, 'robots=\nauthor=', ''),
(31, 'Teknisk info - Fælge', 'teknisk-info1', '', '<h1>Teknisk info - Fælge</h1>\r\n<p>Der er to hovedtyper af fælge, stålfælge og letmetalsfælge (såkaldte alufælge). Ståfælgen er den mest almindelige og er monteret som standard på de fleste køretøjer. Letmetalsfælge er blevet meget almindelig idag, og er monteret som orginal på mange køretøjer. Ofte anvendes de til at opnå ærlige egenskaber, fordi de er lidt lettere og mere bæredygtige. Den mest almindelig årsag til at skifte til letmetalsfælge er imidlertid, det rent æstetiske. Du kan nemt bytte din stålfælg ud med en letmetalsfælg hvis du tager højde for fælgens ET og boltcirkel.</p>\r\n<h2>Fælgens indpresningsdybde, ET-mål</h2>\r\n<p>Fælgens indpresningsdybde, eller ET-mål, viser, hvor langt inde eller ude fælgen sidder i forhold til fælgens midtpunkt.</p>\r\n<p>Det er vigtigt at have den rigtige indpresningsdybde, da forkert indpresningsdybde kan få hjulet til at røre ved skærmens yderkant eller fjedre/støddæmpere. Hvilken indpræsningsdybde, du skal have, afhænger af hvor brede dine fælge er og hvor tore dækkene er, og naturligvis hvilken bil du har. Normalt står indpresningsdybden stemplet på fælgen. Jo højere mål, desto dybere sidder fælgen.</p>\r\n<h2>Boltcirkel</h2>\r\n<p>Boltcirklen handler om hvor mange bolthul fælgen har og dens diameter. Boltcirklen angives som fx 4x110, hvilket betyder 4 bolte med 110 mm cirkeldiameter. Cirkeldiameter er et mål mellem to bolte målt henover centerhullet (fremhævet med rødt). På en 4-bolt fælg måler du fra dit bolthuls yderkant til bolthullets inderste kant på tvær af centerhullet. Forskellige biler har forskellige boltcirkler, hviklet betyder at en fælg ikke passer til alle biler.</p>\r\n<p>På en 5-boltsfælg måler man boltcirklen ved følgende:</p>\r\n<ul>\r\n<li>Mål hele bolthullets diameter (A)</li>\r\n<li>Mål fra bolthullets kant til navhullets kant (B)</li>\r\n<li>Mål navhullets diameter (C)</li>\r\n</ul>\r\n<p>Boltcirklens diameter = A + Bx2 + C</p>\r\n<h2>Fælgdimensioner</h2>\r\n<p>Fælge findes i mange forskellige størrelser og varianter. Når man måler fælge gøre det i tommer. Her er et eksempel på hvordan det kan se ud:</p>\r\n<p>8Jx17</p>\r\n<ul>\r\n<li>8 står for fælgens bredde</li>\r\n<li>J er typen af fælghorn</li>\r\n<li>17 er fælgdiameter målt i tommer.</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p><span style="margin: 0px; padding: 0px; font-size: x-small;"></span>Når man vælger alufælge, skal man tage stilling til flere forskellige ting. Et af de første er, om fælgene skal være større end de originale. Ved montering af fælge med større diameter, monterer man samtidig dæk med en lavere profil. Det vil sige, at når diameteren på fælgen bliver større, mindsker man højden på dæksiden tilsvarende. Derved bevarer man samme omkreds på hjulet.</p>\r\n<p>Generelt kan man sige, at jo større fælgene er, jo bedre ser det ud på bilen. Desværre er det også sådan, at prisen stiger sammen med fælgstørrelsen. Til en bestemt størrelse fælge, er det tit muligt at montere dæk med forskellig bredde. I valget af dækbredde indgår der flere overvejelser. F.eks. plads i hjulkassen, fælgbredde samt pris.</p>\r\n<p>Når man monterer alufælge på sin bil, skal man være opmærksom på, at der både er fordele og ulemper i forhold til almindelige stålfælge</p>\r\n<p><strong style="margin: 0px; padding: 0px;">Fordele ved alufælge</strong>:</p>\r\n<p>• Det ser godt ud. Langt de fleste køber alufælge for at give bilen et flottere udseende</p>\r\n<p>• Der er mulighed for at montere bredere dæk på bilen</p>\r\n<p>• Der er mulighed for at montere større fælge og dermed lavere dæk</p>\r\n<p><strong style="margin: 0px; padding: 0px;">Fordele ved stålfælge:</strong></p>\r\n<p>• Stålfælge kræver lidt mindre rengøring end alufælge</p>\r\n<p>• Med lavprofildæk kan der være fordele med stålfælge, idet alufælge kan betyde en større risiko for at skrabe fælgkanterne med kantsten</p>\r\n<p>Ved montering af alufælge, skal man huske at efterspænde dem efter 50 - 100 km. og igen efter 400 - 500 km. Dette er især vigtigt ved helt nye fælge, da det nye aluminium godt kan "arbejde" lidt. Hjulboltene skal spændes krydsvis med et moment på 100 nm. (gælder for de fleste biler). Har du købt alufælge hos os, kan du naturligvis bare komme forbi, så efterspænder vi hjulene.</p>\r\n<p>Når man monterer andre fælge på en bil, er der nogle krav, som skal være opfyldt, for at det er lovligt</p>\r\n<p>Sporvidde I Danmark er det lovligt, uden nogen form for dokumentation, at forøge en bil''s sporvidde med 20 mm (10 mm. pr. side). Man skal dog være opmærksom på, at man regner ud fra den mindste sporvidde, som er anført på bilens standardtypegodkendelsesattest. Dvs. at bilen kan være godkendt med flere forskellige fælge, som hver især giver bilen forskellige sporvidder. Her benytter man så fælgen med den mindste sporvidde som udgangspunkt. Hvis en given fælg giver en endnu større sporviddeforøgelse, eller hvis sporvidden formindskes, kan fælgen stadig godt være lovlig, hvis der foreligger en TÜV-attest som dokumentation.</p>\r\n<p>Udover sporvidden, skal de nye hjul også overholde skærmreglementet for at være lovlige. Det betyder, at hele hjulet skal være indenfor skærmen inkl. dæksidens runding. Hvis dette ikke er opfyldt, vil hjulet ikke være lovligt, uanset om de er lovlige med hensyn til sporvidde. Vores ekspedienter vil kunne vejlede dig omkring reglerne i forhold til netop din bil.</p>', '', 1, 1, 0, 11, '2012-06-20 04:04:58', 62, '', '2013-05-05 18:01:40', 62, 0, '0000-00-00 00:00:00', '2012-06-20 04:04:58', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 5, 0, 9, '', '', 0, 19968, 'robots=\nauthor=', ''),
(32, 'Teknisk info - Hjul', 'tekniskinfohjul', '', '<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<h1>Teknisk info - Hjul</h1>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Dækket og fælgen bliver til hjul - en samlet enhed. Den rigtige fælg og det rigtige dæk er vigtigt for at give bilen de rigtige egenkaber.</p>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Dæk og fælgdimension kan erstattes hvis hjulet ikke rager ud over kærmen efter ændringen eller hvis den ikke rammer nogle chassisdel ved fuld uspension eller i noget drejningmoment. Ændringer, der gør væsentlige ændringer ved kørelsdynamikken gør ændringen ulovlig. Holder man sig til fælg og dæk dimensioner i nærheden af det der orginalt var monteret på køretøjet, bør ændringen ikke give nogle problemer.</p>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<h2>Hjulet diameter</h2>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Sørg for at hjuldiameter ikke ændrer sig, når du skifter dæk/fælg. Med større hjul kan du ramme skærmkanter eller støddæmpere, fjerdre el.</p>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Hjulets højde er fælgens størrelse plus det dobbelte af dækprofilen.</p>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Fx: Dækstørrelse 225/45-17</p>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<ul>\r\n<li>225 er dækket bredde i mm</li>\r\n<li>45 er højden på dækkets profil i % af bredden</li>\r\n<li>17 er dækkets størrelse (inderdiameter) i tommer</li>\r\n</ul>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Formularen for eksemplet herover bliver (17*25,4)+(2*0,45)), hvilket giver en diameter på 634 mm.</p>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<h2>Rulningsomkreds</h2>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Rulningsomkredsen på dækket er lig med den strækning hjulet ruller på én rotation.Vi anbefaler ikke dæk eller fælg når rulningomkredsen forandres mere end ±5% sammenlignet med rulningsomkredsen på hjulet som bilen er godkendt til.</p>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Fx:</p>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<ul>\r\n<li>Dækstørrelse 225/45-17</li>\r\n<li>Diameteren i eksemplet er 634 mm</li>\r\n<li>Rlningsomkredsen er 634 mm multipliceret med pi (3,141592) og får 1992 mm.</li>\r\n</ul>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Hvis 224/45-17 er den oprindelige størrelse, betyder dette at du kan skifte til andre dæk så længe rulningsomkredsen er indenfor ±5%, hvilket vil sige mindst 1892 mm og højst 2092.</p>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<h2>Forøgelse af størrelse</h2>\r\n<p align="left"><span style="font-family: Arial; font-size: 10pt;"></span></p>\r\n<p>Når der skiftes til større fælg end bilens orginale er det vigtigt at hjulets rulningsomkreds ikke øges. Dette kompenserer man ved at have en lavere profil på dækket.<span style="font-family: Arial; font-size: 10pt;"><br /></span><span style="font-family: Arial; font-size: 10pt;"><br /></span><span style="font-family: Arial; font-size: 10pt;"></span></p>', '', 1, 1, 0, 11, '2012-06-20 05:10:13', 62, '', '2012-06-20 06:04:31', 62, 0, '0000-00-00 00:00:00', '2012-06-20 05:10:13', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 5, 0, 8, '', '', 0, 3410, 'robots=\nauthor=', ''),
(33, 'Vedligeholdelsesguide dæk', 'vedligeholdelsesguidedaek', '', '<h1>Vedligeholdelsesguide Dæk</h1>\r\n<p>Du kan forlænge levetiden på dæk, hvis du sørger for en passende vedligeholdelse. Der er mange faktorer, der påvirker holdbarheden af dæk og i nedenstående gennemgår vi følgende faktorer:</p>\r\n<ol>\r\n<li>Opbevaring af dæk</li>\r\n<li>Kontrol af dæktryk</li>\r\n<li>Dækslitage</li>\r\n<li>Monteringsregler</li>\r\n</ol>\r\n<h2>1. Opbevaring af dæk</h2>\r\n<p>Hvis dine dæk skal bevare deres egenskaber, skal de opbevares rigtigt.</p>\r\n<p>Før du skifter dine dæk, bør du markere retningen på dækket med et stykke kridt samt markere hvor dækkene har været monteret (f.eks. vf =venstre forhjul, hb =højre baghjul. Gør derefter dækkene rene, og fjern grus og lignende. Når du rengører din bil eller fælge skal du være opmærksom på, at dækkene ikke kan tåle "skrappe" rengøringsmidler eller silikone. Vask dine dæk med vand og almindelig bilshampoo.</p>\r\n<p>Når gummi ældes, bliver det hårdt og revner, hvis det ikke opbevares rigtigt. For at holde dækkene i god stand mellem to sæsoner, skal visse regler følges.</p>\r\n<h3>Temperatur</h3>\r\n<p>Temperaturen i det lokale dækkene opbevares , bør ikke overstige +25°. Lokalte skal helst være mørkt, og temperaturen skal helst ligge rundt de 15°. Hvis temperaturen er over +25° eller under 0°kan gummiets egenskaber egenskaber forandres, og dette kan forkorte dækkets levetid.</p>\r\n<h3>Fugtighed</h3>\r\n<p>Dæk bør ikke opbevares på alt for fugtige steder. Fugtigheden bør ikke være så høj, at dækkene ser fugtige ud. Dæk bør heller ikke ligge ude i regn.</p>\r\n<h3>Lys</h3>\r\n<p>Dæk bør beskyttes mod lys, specielt mod direkte sollys og mod stærkt lampelys med høj UV-faktor.</p>\r\n<h3>Kemikalier</h3>\r\n<p>Sørg for at dæk ikke kommer i nærheden af kemikalier, opløsningsmidler eller kulbrinter, som kan forringe dækkets egenskaber. I det rum, hvor dækkene opbevares, må der ikke opbevares apparater som genererer ozon, fx fluor- eller kviksølvdampe, højspændte elektriske apparate, el-motorer eller andre former for el-apparater som kan afgive gnister eller strømudladning. Dæk må specielt beskyttes mod kontakt med løsemidler, olie og fedt. Selv kortvarig kontakt med sådanne stoffer, kan give skade.</p>\r\n<h3>Formforandring</h3>\r\n<p>Om muligt bør dæk opbeares på en sådan måde, at de ikke ligger under pres, spænding eller vridning. Kraftige formforandringer under opbevaring kan medføre defekt, når man øger lufttrykket i dækket.</p>\r\n<h3>Dækhåndtering</h3>\r\n<p>Du må aldrig slippe dæk ned fra større højder en 1,5 meter, da dette kan skade dækket i bead-området. En typisk konsekvens kan være bøjet bead. Et dæk med bøjet bead, må ikke monteres på en fælg.</p>\r\n<p>Dæk på fælge skal aldrig opbevares stående på gulvet - de skal hænges op eller stakkes liggende (ideelt på en træpalle). Dæk uden fælge skal derimod opbevares stående. For at udgå at dækmærker opstår, bør de drejes lidt hver fjerde uge. De må ikke hænges op eller stakkes.</p>\r\n<p><img alt="dækop" src="images/dækop.png" width="336" height="293" /></p>\r\n<p>Før du sætter dækkene på igen, skal du altid kontrollere dem for beskadigelse samt slitage, og kontrollere resterende dækmønsterdybde og eventuel ubalance.</p>\r\n<h2>2. Dæktryk</h2>\r\n<p>Det er luften i dækkene som bærer bilen, og det er meget vigtigt at dækkene har det korrekte lufttryk for at opnå optimale styre- og bremseevner samt den bedste brændstoføkonomi.</p>\r\n<h3>Anbefalet dæktryk</h3>\r\n<p>Det&nbsp; anbefalede dæktryk fremgår af bilens instruktionsbog og/elleren mærkat, der som regel er fatklæbet i venstre fordørsåbning, benzindækslet eller i handskerummet. Overhold dette tryk! Det er fremkommet efter en lang række tests udført af dækfabrikanten og bilproducenten. Bemærk at der kan være forskel mellem for- og bagdæk samt særlige krav til dæktryk ved kørsel med tungt læs, høj hastighed eller campingvogn.</p>\r\n<h3>Regelmæssigt tjek</h3>\r\n<p>Husk regelmæssigt at tjekke dæktrykket. Mindst hver én gang om måneden og altid inden længere rejser, især hvis du skal køre på motorvej. Trykket skal måles med kolde dæk (ikke lige efter kørsel med høj hastighed eller lang distance). Hvis du ikke kan vente, til de er kolde, lægges 0,3 bar til det anbefalede tryk. Luk aldrig luft ud af varme dæk.</p>\r\n<p>Lufttemperaturen påvirker trykket i dækkene. Jo lavere temperatur, jo lavere er det målte tryk. Derfor anbefales det at lægge 0,2 bar til referencetrykket om vinteren.</p>\r\n<p>På de fleste tankstationer findes dæktrykmålere, men en god ide er at investere i en dæktryksmåler og evt. kompressor, så man kan tjekke trykket derhjemme.</p>\r\n<p>Mister du en ventilhætte, eksempelvis når du tjekker dæktrykket, er det vigtigt at du snarest kører forbi et værksted og køber en ny. Hvis man kører uden ventilhætte, vil der sætte sig skidt fra vejen i ventilen som derved kan blive utæt når der næste gang tjekkes tryk i dækket.</p>\r\n<h3>Konsekvenser af forkert dæktryk</h3>\r\n<p>Udover dårlig vejkontakt og brændstoføkonomi vil forkert dæktryk også forårsage unormalt slid på dækket og vil medføre forkortet levetid. Ved kørsel med 1 bar for lavt tryk øges brændstofforbruget med helt op til 15 %. Desuden kan for lavt dæktryk halvere dækkets levetid!</p>\r\n<p><img alt="dæktryk" src="images/dæktryk.png" width="300" height="237" /></p>\r\n<h4>For højt tryk (+0,5 bar)</h4>\r\n<p>Hvis dækkene er pumpet for højt op, slides de hurtigere midt på, hvilket forkorter dækkets levetid. Desuden betyder en mindre kontaktflade med vejen et forringet vejgreb, som kan være farligt i sving eller under bremsning.</p>\r\n<h4>For lavt tryk (-0,5 til -1,5 bar)</h4>\r\n<p>Hvis dækkene er pumpet utilstrækkeligt op (-0,5 bar), slides hurtigere ved skuldrene, hvilket også forkorter dækkets levetid. Desuden øger det fladtrykkede dæk brændstofforbruget, og vandet ledes mindre effektivt væk. Hvis dækkene er pumpet helt utilstrækkeligt op (-1,5 bar), kan du køre galt. Dækkene bliver overophedet og risikerer at springe.</p>\r\n<h2>3. Dækslitage</h2>\r\n<p>Sørg for regelmæssigt at tjekke mønsterdybden på dine dæk og udskift dem, når de er slidte. Det garanterer maksimalt greb og forhindrer ubehagelige overraskelser. Udskift dien dæk, før mønsterdybden er slidt ned til den lovlige grænse. Den lovlige slidgrænse er fastsat til 1,6 mm mønsterdybde, men dækkets ydelse formindskes efterhånden som slidbanen slides. Du må derfor måle dækkenes slitage efter et vist antal kilometer. I almidelighed skal et dæk af god kvalitet skiftes for hver 40.000-50.000 km og af en mindre god kvalitet for hver 10.000 km. Du kan kontrollere dækkenes slitage ved at undersøge dine dæks slidindikator.</p>\r\n<p>Slidindikatoren er en lille 1,6 mm tyk gummiklods, som sidder i bunden af dækmønsteret eller - rillerne. Når slidbanen kommer ned i plan med indikatoren, er dækkene slidt til den lovlige grænse og skal skiftes. Hvis grænserne overskrides, er dækkene ulovlige.</p>\r\n<p>Der kan være mange forskellige årsager til, at dæk slides uens. Herunder kan man se en vejledning til, hvorfor dæk slides som de gør.</p>\r\n<p><img alt="slid" src="images/slid.png" width="527" height="711" /></p>\r\n<h3>Byt rundt på dækkene, så slides de mindre</h3>\r\n<p>Ved med jævne mellemrum at bytte rundt på dækkene, kan du opnå mange fordele, du kanbl.a. forsinke dækslitage og opnå forbedringer i hjulenes ydeevne. Vi anbefaler, at dækkene byttes om mellem hver kørte 10.000 til 15.000 km. Du kan med fordel bytte rundt på hjulene, når bilen er inde til service eller olieskift og alligevel er hejst op. Dette kan også være et godt tidspunkt til at afbalancere dine hjul.</p>\r\n<p>Selv om en bil er udstyret med 4 hjul, udfører for- og baghjul vidt forskellige opgaver. Der vil være forskellig grad og af slitage og forksellige slitage typer, alt efter hvilken af de fire positioner, hjulet sidder på. Du kan derfor forlænge hjulenes levetid, ved at bytte rundt på dækkene.</p>\r\n<p>Der er tre rotationsmønstre, som dækker de fleste kæretøjer, som er udstyret med ikke-retningsbestemte dæk og hjul af samme størrelse og offset. Det første (figur A) er "Bagudrettet kryds", det andet (figur B) er&nbsp; "Forudrettet kryds" og det tredje (figur C) er "X-mønster". X-mønsteret kan bruges som et alternativ til A og C.</p>\r\n<p>Dagens performance dæk og hjultrends har betydet et behov for to ekstra rotationsmønstre. "For-til-bag" (figur D) mønster kan bruges til køretøjer som er udstyret med samme størrelse retningsbestemte dæk. Et "Side-til-side" (figur E) mønster kan bruges af køretøjer, som er udstyret med ikke-retningsbestemte dæk af forskellig størrelse på henholdvis for- og bagaksel.</p>\r\n<p>Hvis de to sidste rotation mønstre ikke giver jævn slitage vil afmontering, montering og rebalancering være nødvendigt for at rotere dækkene.</p>\r\n<p>Køretøjer, der bruger forskellige størrelser retningsbestemte hjul og dæk, og / eller hjul med forskellig offset foran og bag og retningsbestemte dæk vil kræver afmontering, montering og afbalancering i forbindelse med rotation af hjulene.</p>\r\n<h2>4. Monteringsregler</h2>\r\n<p>Der findes nogle grundlæggende regler, som du bør kende, hvis du skal montere et ny dæk på din bil.</p>\r\n<p>Generelt skal du sikre at bilproducentens anbefaling overholdes i forhold til opbygning, dækstørrelse (bredde, højde, diameter), hastigheds- og belastningsindeks. Derudover skal du sikre, at dækkene efterses indvendig og udvendig for eventuelle fejl. Endvidere skal fremgangsmåden for måntering overholdes - dvs. afmontering, afbalancering og oppumpning af dækket, udskiftning af ventil, overholdelse af monteringsanvisningerne på dækket (omløbsretning eller monteringsretning).</p>\r\n<p>Bland aldrig radialdæk og ikke-radialdæk på et køretøj. Hvis det er uundgåeligt at blande dæk, så bland aldrig radialdæk og ikke-radialdæk på samme aksel. Hvis to radialdæk og to ikke-radialdæk monteres på et køretøj, skal de to radialdæk monteres på bagakselen på bagakselen og de to ikke-radialdæk på forakselen.</p>\r\n<h3>Hvis du kun skifter et dæk</h3>\r\n<p>Hvis du kun skifter et dæk, skal du sikre, at dette dæk har samme slidbanemønster (fx retningsbestemt, asymmetrisk), samme mål og samme belastnings- og hastighedsindeks som, det dæk der udskiftes. Derudover skal du sikre dig, at forskellen i slitage i forhold til dækket på samme aksel er under 5 mm.</p>\r\n<h3>Hvis du skifter to dæk</h3>\r\n<p>Hvis du skifter to dæk, skal disse monteres på bagakselen. For selv om fordækkene slides hurtigere end bagdækkene, viser adskillelige test, at det er lettere at kontrollere forakselen end bagakselen. Hvis de nye dæk monteres på bagakselen, opnår du bedre køreegenskaber i kurver på vådt underlag og øget sikkerhed.</p>\r\n<p>&nbsp;</p>\r\n<p>Det er nemt at glemme, at dækkene er den eneste kontaktflade mellem køretøjet og vejbanen. Det er derfor, det er utrolig vigtigt at bevare dine dæks gode kvaliteter og egenskaber for at garantere både din sikkerhed og din mobilitet. For at gøre dette anbefaler vi, at du overholder følgende sikkerhedsanbefalinger.</p>\r\n<p class="section-heading first-child">1. Kontaktflade</p>\r\n<p><strong>ET STORT JOB FOR EN LILLE OVERFLADE<br /></strong>Den del af dit dæk, som rent faktisk er i kontakt med vejbanen, er ikke større end din hånd. Din sikkerhed, komfort og brændstoføkonomi afhænger også af denne meget lille overflade. Derfor skal du sikre dig, at du ikke bare vælger det rigtige dæk, men også regelmæssigt vedligeholde dem korrekt. Det er vigtigt, eftersom dine dæk:</p>\r\n<p>\r\n<ul>\r\n<li class="first-child">Er den eneste forbindelse mellem dit køretøj og vejbanen</li>\r\n<li>Bærer hele bilens vægt, en belastning op til 50 gange dets egen vægt</li>\r\n<li>Reagerer på førerens krav såsom styring, acceleration og opbremsning</li>\r\n<li class="last-child">Absorberer hver eneste forhindring på vejen</li>\r\n</ul>\r\n</p>\r\n<p>&nbsp;</p>\r\n<p class="section-heading">2. Mønsterdybde og slitage</p>\r\n<p><strong>EN HURTIG OG ENKEL SIKKERHEDSFORANSTALTNING</strong><br />Sørg for regelmæssigt at tjekke mønsterdybden på dine dæk og udskifte dem, når de er slidte. Det garanterer maksimalt greb og forhindrer ubehagelige overraskelser. Udskift dine dæk, før mønsterdybden er slidt ned til 1,6 mm. Michelins dæk har slidindikatorer, som sidder nede i bunden af dækmønsteret i en højde af cirka 1,6 mm. Din sikkerhed og mobilitet afhænger af en lovlig mønsterdybde eftersom:</p>\r\n<p>\r\n<ul>\r\n<li class="first-child">Mønstersporene dræner vandet under dækkene væk, så du kan bevare kontrollen</li>\r\n<li>Jo mere mønsterdybde, der er tilbage på dine dæk, jo mere vand kan du dræne væk og dermed reducere risikoen for akvaplaning</li>\r\n<li>Korrekt lufttryk såvel som regelmæssig vedligeholdelse af køretøjet sikrer, at dine dæks præstationer er optimale i længst mulig tid</li>\r\n<li class="last-child">Dækmønsteret griber fat i vejen og har betydning for din bremselængde</li>\r\n</ul>\r\n</p>\r\n<p>&nbsp;</p>\r\n<p class="section-heading">3. Lufttryk</p>\r\n<p><strong>KONTROLLÉR LUFTTRYKKET EN GANG OM MÅNEDEN</strong></p>\r\n<p>Korrekt lufttryk reducerer risikoen for at miste kontrollen over køretøjet. Det beskytter også dine dæk mod for tidlig slitage og uoprettelig indvendig skade. Lufttrykket kan falde på grund af små perforeringer, naturligt udslip af luft gennem dækkets bestanddele eller fra skiftende temperaturer. Kontrollér lufttrykket i dine dæk, inklusive reservehjulet, en gang om måneden og helst på kolde dæk (som ikke har kørt i mindst 2 timer, eller som kun har kørt meget en meget kort strækning ved lav hastighed). Hvis dækkene kontrolleres, når de er varme, skal der lægges 0,2 bar til det anbefalede lufttryk. Det er vigtigt at kontrollere lufttrykket en gang om måneden fordi:</p>\r\n<ul>\r\n<li class="last-child first-child">\r\n<p>Lavt lufttryk øger risikoen for skader på dækket</p>\r\n</li>\r\n<li class="first-child">\r\n<p>Et 20 % for højt lufttryk reducerer dækkets levetid med omkring 10.000 km.</p>\r\n</li>\r\n<li>\r\n<p>Korrekt lufttryk sparer brændstof</p>\r\n</li>\r\n<li>\r\n<p>Det anbefalede lufttryk er IKKE findes på dækket. Det lufttryk, som er angivet på dæksiden, er kun det maksimale lufttryk, dækket kan tåle. Det anbefalede lufttryk kan findes:</p>\r\n</li>\r\n<li>\r\n<p>I dit køretøjs instruktionsbog</p>\r\n</li>\r\n<li>\r\n<p>På mærkaterne på indersiden af fordøren i førerens side</p>\r\n</li>\r\n<li>\r\n<p>I opbevaringsrummet tæt ved førersædet</p>\r\n</li>\r\n<li class="last-child">\r\n<p>På indersiden af tankklappen</p>\r\n</li>\r\n</ul>', '', 1, 1, 0, 11, '2012-06-20 05:13:36', 62, '', '2012-06-20 06:13:25', 62, 0, '0000-00-00 00:00:00', '2012-06-20 05:13:36', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 7, '', '', 0, 8851, 'robots=\nauthor=', '');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `article_image`) VALUES
(34, 'EU-mærkning af dæk', 'eumaerkning', '', '<h1>EU-mærkning af dæk</h1>\r\n<p>Der vil blive indført en ny dækmærkning i EU i 2012. Næsten alle dæk, der produceres efter juni 2012 og sælges fra november 2012 inden for EU skal bære et mærkat eller ledsages af et mærke i henhold til forordningen EC 1222/2009. Denne forordning vil, sammen med andre faktorer der normalt tages i betragtning, når man beslutter sig for et køb, give slutbrugeren mulighed for at fortage et bedre valg, når de køber nye dæk.</p>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top">\r\n<p><img width="280" height="411" style="margin-right: 20px; float: left;" alt="eu mærke" src="images/eu_mærke.png" /></p>\r\n</td>\r\n<td>\r\n<p>Et eksempel på det nye EU-mærkat kan ses til venstre. Dette mærkat svarer til den almindeligt brugte mærkning af husholdningsartikler, såsom vaskemaskiner og opvaskemaskiner.</p>\r\n<p>Målet med mærkningen er at gøre vejtransporten sikrere og øge dens økonomiske og miljømæssige effektivitet ved at fremme sikre og brandstofbesparende dæk med lave støjniveauer. Mærkningen opstiller også rammerne for formidling af harmoniserede oplysninger om nogle dækparametre i hele branchen.</p>\r\n<p>Mærkningen er obligatorisk for:</p>\r\n<ul>\r\n<li>Dæk til biler og SUV''er</li>\r\n<li>Dæk til lette erhvervskøretøjer</li>\r\n<li>Lastvognsdæk</li>\r\n</ul>\r\n<p>Mærkningen gælder dog ikke for:</p>\r\n<ul>\r\n<li>Regummiering</li>\r\n<li>Professionelle offroad dæk</li>\r\n<li>Dæk, der ikke er tilladte på offentlige veje, såsom racerdæk</li>\r\n<li>Type T reservedæk til midlertidig brug</li>\r\n<li>Dæk til veteranbiler</li>\r\n<li>Dæk, hvis hastighedskode er under 80 km/t</li>\r\n<li>Dæk med en nominel fælgdiameter på højst 254 mm eller på mindst 635 mm</li>\r\n<li>Dæk med funktioner, der forbedrer vejgrebet (såsom pigdæk)</li>\r\n</ul>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h2>Dækleverandørernes (producenter og importører) ansvar</h2>\r\n<p>Når dæk leveres til en kunde, skal de ledsages af et mærkat for hver dækstørrelse og type i leverancen svarende til det mærkat, der vises til venstre. Dette krav kan også opfyldes ved at sætte et mærkat på hvert dæk.</p>\r\n<p>Alt reklamemateriale og teknisk og teknisk materiale skal vise mærkatværdierne for hvert dæk på en forståelig måde. Producentens og forhandlerens hjemmesider skal ligeledes vise mærkatoplysninger for de dæk, der tilbydes.</p>\r\n<h2>Dækforhandlernes ansvar (dem der sælger dæk til slutbrugere)</h2>\r\n<p>De skal for dæk til personvogne og lette erhvervskøretøjer sikre, at hvert dæk bærer et mærkat på et klart synligt sted eller inden dækket sælges, forevise mærkatets oplsyninger for slutbrugeren, og et mærkat skal være klart synligt i umiddelbar nærhed af dækket.</p>\r\n<p>Mærkatets oplysninger skal ligeledes gives, når dæk, der udbydes til salg, ikke er synlig for kunden.</p>\r\n<p>Distributørerne skal for samtlige dæk (personbiler, lette erhvervskøretøjer, lastbiler og busser) sikre, at mærkatets værdier for samtlige købte dæk ligeledes er anført på kundens regning eller udleveres sammen med denne.</p>\r\n<h2>Hvordan aflæses mærkatet?</h2>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td><img width="250" height="208" alt="eu mærke 1" src="images/eu_mærke_1.png" /></td>\r\n<td>Effektiv udnyttelse af brændstoffet er vigtigt både for at reducere CO² udledningen og kørselsomkostningerne. Kategorierne er indelt fra A (grøn) til G(rød). Kategori D benyttes ikke her. Forskellen mellem hver kategori indikerer en besparelse eller øgning af brændstofforbruget på mellem 0,10 og 0,15 liter per 100 km for en bil der kører ca. 15 km/liter. Forskellen mellem klasse G og klasse A for et komplet dæksæt kan, afhængig af køretøj og kørselsforhold, reducere brændstofforbruget med op til 7,5%.</td>\r\n</tr>\r\n<tr>\r\n<td><img width="250" height="208" alt="eu mærke 2" src="images/eu_mærke_2.png" /></td>\r\n<td>\r\n<p>Vejgreb på våd vej er en afgørende faktor for sikkerheden, og indikerer dækkenes evne til at standse bilen hurtigt på våde veje, og kan forklares ved hjælp af bræmselængder. Kategorierne er A til G, hvor D og G ikke benyttes. Effekten kan variere afhængigt af køretøjet og kørselsforholdende, men forskellen mellem hver kategori svarer til en bremselængde på mellem en og to billængder (eller mellem 3 og 6 meter) når der bremses ved en hastighed på 80 km/t. Forskellen mellem klasse F og A for et sæt bestående af fire identiske dæk afkorte bremselængden med 30% (fx kan dette reducere bremselængden med 18 meter for en almindelig bil der kører 80 km/t.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td><img width="250" height="208" alt="eu mærke 3" src="images/eu_mærke_3.png" /></td>\r\n<td>\r\n<p>Her er der tale om støjniveauet fra dækkene udenfor kabinen. Det eksterne støjniveau inddeles i tre kategorier og måles i decibel (dB) sammenlignet med de nye europæiske niveauer for støj afgivet til omgivelserne, som skal introduceres frem til 2016.&nbsp; Jo flere rammer, der er udfyldt med sort på mærkaten, jo mere støjer dækkene.</p>\r\n<ul>\r\n<li><b>1 sort lydbølge</b>: dæk med lav udvendig støj. 3 dB mindre end den kommende strammere europæiske grænse</li>\r\n<li><b>2 sorte lydbølger</b>: dæk med gennemsnitlig udvendig støj. Dækket opfylder allerede den kommende europæiske grænse.</li>\r\n<li><b>3 sorte lydbølger</b>: dæk med høj udvendig støj. Dækket opfylder den aktuelle europæiske grænse, med er højere end den kommende grænse.</li>\r\n</ul>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', '', 1, 1, 0, 11, '2012-06-20 05:15:25', 62, '', '2013-11-20 20:44:21', 62, 0, '0000-00-00 00:00:00', '2012-06-20 05:15:25', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 5, 0, 6, 'eu mærkning af dæk', 'eu mærknig af dæk, eu mærke, dæk mærke', 0, 2944, 'robots=\nauthor=', ''),
(35, 'Udskiftning af dæk', 'udskiftning', '', '<h1>Udskiftning af dæk</h1>\r\n<p>Det er ikke muligt at bestemme et dæks levetid, eftersom der er mange faktorer, som spiller ind, fx kørestil, vejr og opbevaring.</p>\r\n<p>Vi har herunder opstillet en liste over 6 grunde til at udskifte dine dæk.</p>\r\n<h2>1. Hvis du punkterer</h2>\r\n<p>Moderne dæk er meget robuste og kan klare de fleste ting. Punkteringer kan dog stadig ske. En specialist bør altid tjekke dine dæk efter en punktering for at opdage skjulte skader, som kan betyde, at dækket ikke kan repareres.</p>\r\n<h2>2. Hvis dækkene er slidt</h2>\r\n<p>Det er altid klogt at kontrollere dine dæks slitage regelmæssigt. Hvis dine dæk er slidt ned til lovens minimumskrav på 1,6 millimeter, skal dækkene skiftes. De fleste dæk har indstøbte slidindikatorer i bunden af dækkets dækmønster. Hvis mønsteret er slidt ned til det niveau, så du kan se et gummimærke på tværs af slidbanen, er det på tide at få skiftet dine dæk.</p>\r\n<h2>3. Hvis dine dæk viser tegn på ældning</h2>\r\n<p>Dæk har ikke en forudsigelig holdbarhed. Det betyder ikke noget, hvornår dækkene blev produceret. Dæk ældes, selv når de ikke bruges, eller hvis de kun bruges lejlighedsvis. Der er mange faktorer, som vil påvirke dækkets liv, herunder temperatur, vedligeholdelse, forhhold under opbevaring og brug, belastning, hastighed, lufttryk såvel som kørestil. Disse faktorer har stor indvirkning på længden af den brugstid, du kan forvente af dine dæk.</p>\r\n<p>Det er derfor vigtigt at du holder øje med dækkenes udvendige udseende for at opdage tydelige tegn på ældning eller trærhed. Det kan være krakeleringer i gummiet på mønsteret udvendigt, skulder og kant samt deformation mm. Udsædvanlig kraftig ældning af dæk kan føre til tab af greb.</p>\r\n<h2>4. Hvis dit dæk er beskadiget</h2>\r\n<p>Dit dæk kan blive alvorligt beskadiget, hvis det støder sammen med en solid genstand på vejen, fx en kantesten, et hul i vejen eller en skarp genstand. Alle synlige perforeringer, snit eller deformationer skal kontrolleres grundigt af en dækspecialist. Kun en fagmand kan sige, om dækket skal repareres, eller om det skal udskiftes. Husk alrdig at bruge beskadigede dælk, eller sæk som har kørt uden luft.</p>\r\n<h2>5. Hvis du identificerer unormal slitage</h2>\r\n<p>Unørmal, ujævn dækslitage, indikerer ofte et mekanisk problem såsom forkert hjulsporing eller et problem med afbalancering, hjulophæng eller gear. Det kan også skyldes at du kører med forkert dæktryk. Hvis du observerer unormal slitage, skal du kontakte en fagmand.</p>\r\n<p>For at undgå ujævn slitage skal du have hjulene sporet og afbalanceret hvert halve år. Det vil også forlænge slidbanens levetid og give dig en mere jævn kørsel. En anden måde at holde slidbanen jævn er ved regelmæssigt at rotere hjulene.</p>\r\n<h2>6. Hvis dækkene ikke egner sig til dit køretøj</h2>\r\n<p>For at opnå de bedste præstationer samlet sæt, bør du altid bruge de samme dæk på alle hjul. Dæk med forskellige dimensioner, opbygning og slidgrad kan påvirke køretøjets manøvrering og stabilitet.</p>\r\n<p>Du må heller ikke blande radial og ikke-radial dæk på et køretøj.</p>\r\n<p>&nbsp;</p>', '', 1, 1, 0, 11, '2012-06-20 05:16:28', 62, '', '2012-06-20 06:15:06', 62, 0, '0000-00-00 00:00:00', '2012-06-20 05:16:28', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 5, '', '', 0, 6994, 'robots=\nauthor=', ''),
(36, 'Dæk og fælge info2', 'daek-og-faelge-info2', '', '<a href="index.php?option=com_content&amp;view=article&amp;id=28&amp;Itemid=33" target="_self"><img style="width: 225px; height: 257px;" alt="XXX1" src="images/XXX1.jpg" width="330" height="404" /></a><a href="index.php?option=com_content&amp;view=article&amp;id=31&amp;Itemid=34" target="_self"><img style="width: 220px; height: 266px;" alt="XXX2" src="images/XXX2.png" width="205" height="253" /></a><br /><br />', '', 1, 1, 0, 11, '2013-05-02 09:49:09', 62, '', '2013-05-02 11:06:41', 62, 62, '2014-01-10 14:09:20', '2013-05-02 09:49:09', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 8, 0, 4, '', '', 0, 426, 'robots=\nauthor=', ''),
(37, 'Teknisk info - Dæk web', 'daek-og-faelg-info', '', '<h1>TEKNISK INFO - DÆK</h1>\r\n<p><img alt="daekinfo" src="images/banners/daekinfo.jpg" width="300" height="297" /><br />Dæksidemærkning:<br /><br />Dækside mærkning på et dæk indeholder oplysninger om dækkets design og produktion.</p>\r\n<h3>1. Producent/mærke</h3>\r\n<p>Her står producentens navn, fx Michelin, Goodyear, Vredestein, Apollo, Nokian m.fl.</p>\r\n<h3>2. Dækmodel/mønster</h3>\r\n<p>Navn på model eller mønster. Fx. Sport, Pilot, Eagle m.fl.</p>\r\n<h3>3. Dækstørrelse</h3>\r\n<p>Dækstørrelsen er den vigtigste information som findes på dækket. Størrelsen er angivet som en serie tal og bogstaver, som fx. 205/55R16,</p>\r\n<p><b>205</b> = dækkets bredde i mm.<br /> <b>55</b> = dækkets højde i procent af bredden som her er 55% af 205mm,<br /> <b>R</b> = radialdæk, som er det mest almindelige dæk til almindelige biler i dag. <br /> <b>16"</b> = størrelsen på de fælge (i tommer) som passer til dækket</p>\r\n<h3>4. Belastningsindeks</h3>\r\n<p>Belastningsindekset er et indeks som angiver den maksimale vægt som dækket kan bære ved den hastighed, der svarer til hastighedsindekset. I dette eksempel 91, som svarer til 615 kg. pr dæk. Bemærk at den maksimale belastning er ved korrekt dæktryk.</p>\r\n<p><img alt="" src="images/stories/10.png" /></p>\r\n<h3>4. Hastighedindeks</h3>\r\n<p>Hastigehdsindekset angiver den maksimale hastigehd, ved hvilken dækket kan bære en vis belastning (svarende til belastningsindekset). Tjek og følg altid bilens manual for at finde ud af hvilken hastighedskode der bedst passer til bilsen. Det er generelt en god idé at alle dæk har samme hastigehdskode. Det kan også være klogt at have dæk med samme hastighedskode som de dæk der oprindelig var monteret på bilen. Skal du have skiftet bare et enkelt dæk på bilen, er det vigtigt at købe dæk med mindst den samme tophastighed eller højere.</p>\r\n<p>Med hensyn til vinterdæk er det acceptabelt at sætte dæk med lavere hastighedskode på. Men det er dog på bekostning af din fart også bliver sat ned.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;<img alt="" src="images/stories/11.png" /></p>\r\n<p>Vinterdæk har som regel lavere hastighedsindeks end hvad et sommerdæk har, og det er tildels fordi vinterdæk har et grovere mønser og er lavet af en blødere gummi, med det resultat at dækket bliver ustabilt ved høje hastigheder.</p>\r\n<h3>5. E-mærkning</h3>\r\n<p>Dækket skal også have en E-mærkning. ECE Regulativ 30, som indikerer at dækket lever op til de gældende Europæiske krav.</p>\r\n<h3>6. Godkendelses nummer for støjegenskaber</h3>\r\n<p>Det betyder, at dækket lever op til de Europæiske krav om begrænsning af støj fra dæk.</p>\r\n<h3>7. DOT nummer</h3>\r\n<p>DOT nummer for det amerikanske marked. Det har ingen betydning for Europa.</p>\r\n<h3>8. Produktionsdato</h3>\r\n<p>Produktionsdatoen kan let findes ved at undersøge serienummeret på dækkets sidevæg (8).&nbsp;Serienummeret er en alfanummerisk kode bestående af 11 tegn, der sædvanligvis, men ikke altid, følger efter akronymet "DOT" (se herover). De sidste fire cifre i dette nummer refererer til produktionsdatoen.</p>\r\n<p>De første&nbsp;to cifre angiver produktionsugen (inden for området 01 til 52), mens de sidste to cifre angiver produktionsåret&nbsp;fx. 4500 = uge 45 i 2000.</p>\r\n<p>For dæk produceret inden år 2000 angives produktionsåret med 1 tal i stedet for 2 (dvs. 189 angiver uge 18 i år 1999). I tiåret 1990-2000 blev nogle dæk mærket med en trekant, der pegede på de sidste cifre i serienummeret for at adskille dem fra dæk&nbsp;produceret i tidligere tiår.</p>\r\n<p>Produktionsdatoen er vigtig, fordi et dæk er sammensat af forskellige typer materiale og gummibalndinger med forskellige egenskaber, som forandres med tiden. For enkelte dæk afhænger denne forandring af mange elementer som fx vejret, opbevaringsforhold og anvendelsesbetingelser, som dækket udsættes for igennem sin levetid. Denne brugsrelaterede forandring varierer betydeligt, således at en nøjagtig prognose for levetiden på et bestemt dæk ikke er muligt på forhånd.</p>\r\n<p>Generelt gælder dog, at jo ældre et dæk er, jo større er risikoen imidlertid for, at der er behov for at få det udskiftet som følge af brugsrelateret forandring. Et dæk der har været i brug i 5 år eller mere bør inspiceres mindst en gang om året. De fleste dæk vil af naturlige årsager skulle udskiftes, inden de bliver 10 år gamle, og det anbefales, at alle dæk, som stadig er i brug mere end 10 år efter produktionsdatoen, herunder også dæk på reservehjul, udskiftes med nye dæk, som en simpel forebyggelse. Dæk må helst ikke være mere 6 år gamle.</p>\r\n<h3><br /> 9.&nbsp;&nbsp;Amerikansk egenskabsmærkning</h3>\r\n<p>En særlig&nbsp;amerikansk mærkning om dækkets egenskaber. Det har ingen betydning for Europa.</p>\r\n<h3>10. Amerikansk belastningsmærkning</h3>\r\n<p>En særlig&nbsp;amerikansk mærkning om belastning. Det har ingen betydning for Europa. (For Europa se under pkt.4)</p>\r\n<h3>11. Max dæktryk</h3>\r\n<p>Fabrikantens max anbefalede dæktryk, har bla. betydning for køretøjer over ca. 2ton. Det er dette dæktryk som en camper skal have i dækkerne.&nbsp;</p>\r\n<h3>12. Slangeløst dæk</h3>\r\n<p>Et mærke der angiver at dækket er slangeløst.</p>\r\n<h3>13. Amerikansk dæktryk mærkning</h3>\r\n<p>&nbsp;En særlig&nbsp;amerikansk mærkning, der advarer om forkert dæktryk, og de følger det kan medføre. Det har ingen betydning for Europa.</p>\r\n<h3>14. Rotationsretning</h3>\r\n<p>Pilen angiver dækkets rotations retning.</p>\r\n<h3>15. Assymetriske dæk</h3>\r\n<p>Asymmetriske dæk har en mærkning, der angiver hvilken side der skal vende udad.</p>\r\n<h3>16. Forstærket</h3>\r\n<p>Angivelse der viser, at dækket kan tåle ekstra belastning (reinforced).</p>\r\n<h3>17.&nbsp;Slidbaneindikator</h3>\r\n<p>TWI er angivet 6 steder rundt på dækket og viser hvor slidindikatorerne findes i bunden af mønsteret.</p>\r\n<h3>18. Mud and snow</h3>\r\n<p>På dæksiden kan der yderligere være påført "M+S", hvilket står for "Mud and snow" eller på dansk "Mudder og sne". Dette indikerer at dækket er et vinterdæk eller et helårsdæk.</p>', '', 1, 1, 0, 11, '2012-06-11 03:48:33', 62, '', '2013-05-06 17:29:15', 62, 62, '2014-01-10 14:07:15', '2012-06-11 03:48:33', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 3, '', '', 0, 13315, 'robots=\nauthor=', ''),
(38, 'Teknisk info - Dæk FB test', 'daek-og-faelg-info', '', '<h1><span style="text-decoration: underline;"><span style="font-size: 18pt;"><br />TRYK FOR INFO OM:</span></span><br /><br /><a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=37&amp;Itemid=35" target="_self"><img alt="DÆK" src="images/DÆK.png" width="229" height="38" /></a>&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=31&amp;Itemid=35" target="_self"><img alt="FÆLGE" src="images/FÆLGE.png" width="248" height="38" /></a>&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=32&amp;Itemid=35" target="_self"><img alt="HJUL" src="images/HJUL.png" width="231" height="38" /></a><br /><br /><a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=34&amp;Itemid=35" target="_self"><img alt="EU" src="images/EU.png" width="275" height="38" /></a>&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=33&amp;Itemid=35" target="_self"><img alt="VEDLIGEHOLDELSE" src="images/VEDLIGEHOLDELSE.png" width="357" height="38" /></a><br /><br /><a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=35&amp;Itemid=35" target="_self"><img alt="UDSKIFTNING" src="images/UDSKIFTNING.png" width="259" height="38" /></a>&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=30&amp;Itemid=35" target="_self"><img alt="VINTERDÆK" src="images/VINTERDÆK.png" width="242" height="38" /></a></h1>\r\n<h1>---------------------------------------------------------------------------------------------------------------<br />TEKNISK INFO - DÆK</h1>\r\n<p><img alt="daekinfo" src="images/banners/daekinfo.jpg" width="300" height="297" /><br />Dæksidemærkning:<br /><br />Dækside mærkning på et dæk indeholder oplysninger om dækkets design og produktion.</p>\r\n<h3>1. Producent/mærke</h3>\r\n<p>Her står producentens navn, fx Michelin, Goodyear, Vredestein, Apollo, Nokian m.fl.</p>\r\n<h3>2. Dækmodel/mønster</h3>\r\n<p>Navn på model eller mønster. Fx. Sport, Pilot, Eagle m.fl.</p>\r\n<h3>3. Dækstørrelse</h3>\r\n<p>Dækstørrelsen er den vigtigste information som findes på dækket. Størrelsen er angivet som en serie tal og bogstaver, som fx. 205/55R16,</p>\r\n<p><b>205</b> = dækkets bredde i mm.<br /> <b>55</b> = dækkets højde i procent af bredden som her er 55% af 205mm,<br /> <b>R</b> = radialdæk, som er det mest almindelige dæk til almindelige biler i dag. <br /> <b>16"</b> = størrelsen på de fælge (i tommer) som passer til dækket</p>\r\n<h3>4. Belastningsindeks</h3>\r\n<p>Belastningsindekset er et indeks som angiver den maksimale vægt som dækket kan bære ved den hastighed, der svarer til hastighedsindekset. I dette eksempel 91, som svarer til 615 kg. pr dæk. Bemærk at den maksimale belastning er ved korrekt dæktryk.</p>\r\n<p><img alt="" src="images/stories/10.png" /></p>\r\n<h3>4. Hastighedindeks</h3>\r\n<p>Hastigehdsindekset angiver den maksimale hastigehd, ved hvilken dækket kan bære en vis belastning (svarende til belastningsindekset). Tjek og følg altid bilens manual for at finde ud af hvilken hastighedskode der bedst passer til bilsen. Det er generelt en god idé at alle dæk har samme hastigehdskode. Det kan også være klogt at have dæk med samme hastighedskode som de dæk der oprindelig var monteret på bilen. Skal du have skiftet bare et enkelt dæk på bilen, er det vigtigt at købe dæk med mindst den samme tophastighed eller højere.</p>\r\n<p>Med hensyn til vinterdæk er det acceptabelt at sætte dæk med lavere hastighedskode på. Men det er dog på bekostning af din fart også bliver sat ned.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;<img alt="" src="images/stories/11.png" /></p>\r\n<p>Vinterdæk har som regel lavere hastighedsindeks end hvad et sommerdæk har, og det er tildels fordi vinterdæk har et grovere mønser og er lavet af en blødere gummi, med det resultat at dækket bliver ustabilt ved høje hastigheder.</p>\r\n<h3>5. E-mærkning</h3>\r\n<p>Dækket skal også have en E-mærkning. ECE Regulativ 30, som indikerer at dækket lever op til de gældende Europæiske krav.</p>\r\n<h3>6. Godkendelses nummer for støjegenskaber</h3>\r\n<p>Det betyder, at dækket lever op til de Europæiske krav om begrænsning af støj fra dæk.</p>\r\n<h3>7. DOT nummer</h3>\r\n<p>DOT nummer for det amerikanske marked. Det har ingen betydning for Europa.</p>\r\n<h3>8. Produktionsdato</h3>\r\n<p>Produktionsdatoen kan let findes ved at undersøge serienummeret på dækkets sidevæg (8).&nbsp;Serienummeret er en alfanummerisk kode bestående af 11 tegn, der sædvanligvis, men ikke altid, følger efter akronymet "DOT" (se herover). De sidste fire cifre i dette nummer refererer til produktionsdatoen.</p>\r\n<p>De første&nbsp;to cifre angiver produktionsugen (inden for området 01 til 52), mens de sidste to cifre angiver produktionsåret&nbsp;fx. 4500 = uge 45 i 2000.</p>\r\n<p>For dæk produceret inden år 2000 angives produktionsåret med 1 tal i stedet for 2 (dvs. 189 angiver uge 18 i år 1999). I tiåret 1990-2000 blev nogle dæk mærket med en trekant, der pegede på de sidste cifre i serienummeret for at adskille dem fra dæk&nbsp;produceret i tidligere tiår.</p>\r\n<p>Produktionsdatoen er vigtig, fordi et dæk er sammensat af forskellige typer materiale og gummibalndinger med forskellige egenskaber, som forandres med tiden. For enkelte dæk afhænger denne forandring af mange elementer som fx vejret, opbevaringsforhold og anvendelsesbetingelser, som dækket udsættes for igennem sin levetid. Denne brugsrelaterede forandring varierer betydeligt, således at en nøjagtig prognose for levetiden på et bestemt dæk ikke er muligt på forhånd.</p>\r\n<p>Generelt gælder dog, at jo ældre et dæk er, jo større er risikoen imidlertid for, at der er behov for at få det udskiftet som følge af brugsrelateret forandring. Et dæk der har været i brug i 5 år eller mere bør inspiceres mindst en gang om året. De fleste dæk vil af naturlige årsager skulle udskiftes, inden de bliver 10 år gamle, og det anbefales, at alle dæk, som stadig er i brug mere end 10 år efter produktionsdatoen, herunder også dæk på reservehjul, udskiftes med nye dæk, som en simpel forebyggelse. Dæk må helst ikke være mere 6 år gamle.</p>\r\n<h3><br /> 9.&nbsp;&nbsp;Amerikansk egenskabsmærkning</h3>\r\n<p>En særlig&nbsp;amerikansk mærkning om dækkets egenskaber. Det har ingen betydning for Europa.</p>\r\n<h3>10. Amerikansk belastningsmærkning</h3>\r\n<p>En særlig&nbsp;amerikansk mærkning om belastning. Det har ingen betydning for Europa. (For Europa se under pkt.4)</p>\r\n<h3>11. Max dæktryk</h3>\r\n<p>Fabrikantens max anbefalede dæktryk, har bla. betydning for køretøjer over ca. 2ton. Det er dette dæktryk som en camper skal have i dækkerne.&nbsp;</p>\r\n<h3>12. Slangeløst dæk</h3>\r\n<p>Et mærke der angiver at dækket er slangeløst.</p>\r\n<h3>13. Amerikansk dæktryk mærkning</h3>\r\n<p>&nbsp;En særlig&nbsp;amerikansk mærkning, der advarer om forkert dæktryk, og de følger det kan medføre. Det har ingen betydning for Europa.</p>\r\n<h3>14. Rotationsretning</h3>\r\n<p>Pilen angiver dækkets rotations retning.</p>\r\n<h3>15. Assymetriske dæk</h3>\r\n<p>Asymmetriske dæk har en mærkning, der angiver hvilken side der skal vende udad.</p>\r\n<h3>16. Forstærket</h3>\r\n<p>Angivelse der viser, at dækket kan tåle ekstra belastning (reinforced).</p>\r\n<h3>17.&nbsp;Slidbaneindikator</h3>\r\n<p>TWI er angivet 6 steder rundt på dækket og viser hvor slidindikatorerne findes i bunden af mønsteret.</p>\r\n<h3>18. Mud and snow</h3>\r\n<p>På dæksiden kan der yderligere være påført "M+S", hvilket står for "Mud and snow" eller på dansk "Mudder og sne". Dette indikerer at dækket er et vinterdæk eller et helårsdæk.</p>', '', -2, 1, 0, 11, '2012-06-11 03:48:33', 62, '', '2013-05-06 17:36:58', 62, 0, '0000-00-00 00:00:00', '2012-06-11 03:48:33', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 0, '', '', 0, 0, 'robots=\nauthor=', ''),
(39, 'Teknisk info - Dæk FB test', 'daek-og-faelg-info', '', '<h1><span style="text-decoration: underline;"><span style="font-size: 18pt;"><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TRYK FOR INFO OM&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></span></span><br /><a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=37&amp;Itemid=35" target="_self"><img alt="DÆK" src="images/DÆK.png" width="229" height="38" /></a>&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=31&amp;Itemid=35" target="_self"><img alt="FÆLGE" src="images/FÆLGE.png" width="248" height="38" /></a>&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=32&amp;Itemid=35" target="_self"><img alt="HJUL" src="images/HJUL.png" width="231" height="38" /></a><br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=34&amp;Itemid=35" target="_self"><img alt="EU" src="images/EU.png" width="275" height="38" /></a>&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=33&amp;Itemid=35" target="_self"><img alt="VEDLIGEHOLDELSE" src="images/VEDLIGEHOLDELSE.png" width="357" height="38" /></a><br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=35&amp;Itemid=35" target="_self"><img alt="UDSKIFTNING" src="images/UDSKIFTNING.png" width="259" height="38" /></a>&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=30&amp;Itemid=35" target="_self"><img alt="VINTERDÆK" src="images/VINTERDÆK.png" width="242" height="38" /></a></h1>\r\n<h1><span style="text-decoration: underline;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><br />---------------------------------------------------------------------------------------------------------------<br />TEKNISK INFO - DÆK</h1>\r\n<p><img alt="daekinfo" src="images/banners/daekinfo.jpg" width="300" height="297" /><br />Dæksidemærkning:<br /><br />Dækside mærkning på et dæk indeholder oplysninger om dækkets design og produktion.</p>\r\n<h3>1. Producent/mærke</h3>\r\n<p>Her står producentens navn, fx Michelin, Goodyear, Vredestein, Apollo, Nokian m.fl.</p>\r\n<h3>2. Dækmodel/mønster</h3>\r\n<p>Navn på model eller mønster. Fx. Sport, Pilot, Eagle m.fl.</p>\r\n<h3>3. Dækstørrelse</h3>\r\n<p>Dækstørrelsen er den vigtigste information som findes på dækket. Størrelsen er angivet som en serie tal og bogstaver, som fx. 205/55R16,</p>\r\n<p><b>205</b> = dækkets bredde i mm.<br /> <b>55</b> = dækkets højde i procent af bredden som her er 55% af 205mm,<br /> <b>R</b> = radialdæk, som er det mest almindelige dæk til almindelige biler i dag. <br /> <b>16"</b> = størrelsen på de fælge (i tommer) som passer til dækket</p>\r\n<h3>4. Belastningsindeks</h3>\r\n<p>Belastningsindekset er et indeks som angiver den maksimale vægt som dækket kan bære ved den hastighed, der svarer til hastighedsindekset. I dette eksempel 91, som svarer til 615 kg. pr dæk. Bemærk at den maksimale belastning er ved korrekt dæktryk.</p>\r\n<p><img alt="" src="images/stories/10.png" /></p>\r\n<h3>4. Hastighedindeks</h3>\r\n<p>Hastigehdsindekset angiver den maksimale hastigehd, ved hvilken dækket kan bære en vis belastning (svarende til belastningsindekset). Tjek og følg altid bilens manual for at finde ud af hvilken hastighedskode der bedst passer til bilsen. Det er generelt en god idé at alle dæk har samme hastigehdskode. Det kan også være klogt at have dæk med samme hastighedskode som de dæk der oprindelig var monteret på bilen. Skal du have skiftet bare et enkelt dæk på bilen, er det vigtigt at købe dæk med mindst den samme tophastighed eller højere.</p>\r\n<p>Med hensyn til vinterdæk er det acceptabelt at sætte dæk med lavere hastighedskode på. Men det er dog på bekostning af din fart også bliver sat ned.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;<img alt="" src="images/stories/11.png" /></p>\r\n<p>Vinterdæk har som regel lavere hastighedsindeks end hvad et sommerdæk har, og det er tildels fordi vinterdæk har et grovere mønser og er lavet af en blødere gummi, med det resultat at dækket bliver ustabilt ved høje hastigheder.</p>\r\n<h3>5. E-mærkning</h3>\r\n<p>Dækket skal også have en E-mærkning. ECE Regulativ 30, som indikerer at dækket lever op til de gældende Europæiske krav.</p>\r\n<h3>6. Godkendelses nummer for støjegenskaber</h3>\r\n<p>Det betyder, at dækket lever op til de Europæiske krav om begrænsning af støj fra dæk.</p>\r\n<h3>7. DOT nummer</h3>\r\n<p>DOT nummer for det amerikanske marked. Det har ingen betydning for Europa.</p>\r\n<h3>8. Produktionsdato</h3>\r\n<p>Produktionsdatoen kan let findes ved at undersøge serienummeret på dækkets sidevæg (8).&nbsp;Serienummeret er en alfanummerisk kode bestående af 11 tegn, der sædvanligvis, men ikke altid, følger efter akronymet "DOT" (se herover). De sidste fire cifre i dette nummer refererer til produktionsdatoen.</p>\r\n<p>De første&nbsp;to cifre angiver produktionsugen (inden for området 01 til 52), mens de sidste to cifre angiver produktionsåret&nbsp;fx. 4500 = uge 45 i 2000.</p>\r\n<p>For dæk produceret inden år 2000 angives produktionsåret med 1 tal i stedet for 2 (dvs. 189 angiver uge 18 i år 1999). I tiåret 1990-2000 blev nogle dæk mærket med en trekant, der pegede på de sidste cifre i serienummeret for at adskille dem fra dæk&nbsp;produceret i tidligere tiår.</p>\r\n<p>Produktionsdatoen er vigtig, fordi et dæk er sammensat af forskellige typer materiale og gummibalndinger med forskellige egenskaber, som forandres med tiden. For enkelte dæk afhænger denne forandring af mange elementer som fx vejret, opbevaringsforhold og anvendelsesbetingelser, som dækket udsættes for igennem sin levetid. Denne brugsrelaterede forandring varierer betydeligt, således at en nøjagtig prognose for levetiden på et bestemt dæk ikke er muligt på forhånd.</p>\r\n<p>Generelt gælder dog, at jo ældre et dæk er, jo større er risikoen imidlertid for, at der er behov for at få det udskiftet som følge af brugsrelateret forandring. Et dæk der har været i brug i 5 år eller mere bør inspiceres mindst en gang om året. De fleste dæk vil af naturlige årsager skulle udskiftes, inden de bliver 10 år gamle, og det anbefales, at alle dæk, som stadig er i brug mere end 10 år efter produktionsdatoen, herunder også dæk på reservehjul, udskiftes med nye dæk, som en simpel forebyggelse. Dæk må helst ikke være mere 6 år gamle.</p>\r\n<h3><br /> 9.&nbsp;&nbsp;Amerikansk egenskabsmærkning</h3>\r\n<p>En særlig&nbsp;amerikansk mærkning om dækkets egenskaber. Det har ingen betydning for Europa.</p>\r\n<h3>10. Amerikansk belastningsmærkning</h3>\r\n<p>En særlig&nbsp;amerikansk mærkning om belastning. Det har ingen betydning for Europa. (For Europa se under pkt.4)</p>\r\n<h3>11. Max dæktryk</h3>\r\n<p>Fabrikantens max anbefalede dæktryk, har bla. betydning for køretøjer over ca. 2ton. Det er dette dæktryk som en camper skal have i dækkerne.&nbsp;</p>\r\n<h3>12. Slangeløst dæk</h3>\r\n<p>Et mærke der angiver at dækket er slangeløst.</p>\r\n<h3>13. Amerikansk dæktryk mærkning</h3>\r\n<p>&nbsp;En særlig&nbsp;amerikansk mærkning, der advarer om forkert dæktryk, og de følger det kan medføre. Det har ingen betydning for Europa.</p>\r\n<h3>14. Rotationsretning</h3>\r\n<p>Pilen angiver dækkets rotations retning.</p>\r\n<h3>15. Assymetriske dæk</h3>\r\n<p>Asymmetriske dæk har en mærkning, der angiver hvilken side der skal vende udad.</p>\r\n<h3>16. Forstærket</h3>\r\n<p>Angivelse der viser, at dækket kan tåle ekstra belastning (reinforced).</p>\r\n<h3>17.&nbsp;Slidbaneindikator</h3>\r\n<p>TWI er angivet 6 steder rundt på dækket og viser hvor slidindikatorerne findes i bunden af mønsteret.</p>\r\n<h3>18. Mud and snow</h3>\r\n<p>På dæksiden kan der yderligere være påført "M+S", hvilket står for "Mud and snow" eller på dansk "Mudder og sne". Dette indikerer at dækket er et vinterdæk eller et helårsdæk.</p>', '', -2, 1, 0, 11, '2012-06-11 03:48:33', 62, '', '2013-05-06 17:45:33', 62, 0, '0000-00-00 00:00:00', '2012-06-11 03:48:33', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 0, '', '', 0, 0, 'robots=\nauthor=', ''),
(40, 'Teknisk info - Dæk FB', 'daek-og-faelg-info', '', '<div class="fb-like" data-show-faces="false" data-width="450" data-send="true" data-href="http://daekcenter.nu/index.php?option=com_content&amp;view=article&amp;id=40&amp;Itemid=28" data-font="arial">&nbsp;</div>\r\n<h1><span style="text-decoration: underline;"><span style="font-size: 18pt;"><br /></span><span style="font-size: 18pt;">TRYK</span><span style="font-size: 18pt;"> FOR INFO OM:</span><span style="font-size: 18pt;"><br /><br /></span></span> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=37&amp;Itemid=35" target="_self"><img width="229" height="38" alt="DÆK" src="images/DÆK.png" /></a> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=31&amp;Itemid=35" target="_self"><img width="248" height="38" alt="FÆLGE" src="images/FÆLGE.png" /></a> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=32&amp;Itemid=35" target="_self"><img width="231" height="38" alt="HJUL" src="images/HJUL.png" /></a><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=34&amp;Itemid=35" target="_self"><img width="275" height="38" alt="EU" src="images/EU.png" /></a> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=33&amp;Itemid=35" target="_self"><img width="357" height="38" alt="VEDLIGEHOLDELSE" src="images/VEDLIGEHOLDELSE.png" /></a><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=35&amp;Itemid=35" target="_self"><img width="259" height="38" alt="UDSKIFTNING" src="images/UDSKIFTNING.png" /></a> <a href="index.php?option=com_content&amp;view=article&amp;layout=defaultfbapp&amp;id=30&amp;Itemid=35" target="_self"><img width="242" height="38" alt="VINTERDÆK" src="images/VINTERDÆK.png" /></a><br /><img width="722" height="226" style="width: 722px; height: 255px;" alt="DK-CENTER LOGO" src="images/DK-CENTER_LOGO.jpg" /></h1>\r\n<h1>&nbsp;</h1>', '', 1, 1, 0, 11, '2012-06-11 03:48:33', 62, '', '2013-05-27 09:31:19', 62, 62, '2014-01-10 14:09:26', '2012-06-11 03:48:33', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 11, 0, 2, '', '', 0, 228, 'robots=\nauthor=', ''),
(41, 'Post DK logo bestilling', 'post-dk-logo', '', '<form name="htmlform" action="mailto:martin@ccnf.dk" method="post">\r\n<table style="width: 450px;">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><label for="first_name">First Name *</label></td>\r\n<td valign="top"><input name="first_name" type="text" size="30" maxlength="50" /></td>\r\n</tr>\r\n<tr>\r\n<td valign="top"><label for="last_name">Last Name *</label></td>\r\n<td valign="top"><input name="last_name" type="text" size="30" maxlength="50" /></td>\r\n</tr>\r\n<tr>\r\n<td valign="top"><label for="email">Email Address *</label></td>\r\n<td valign="top"><input name="email" type="text" size="30" maxlength="80" /></td>\r\n</tr>\r\n<tr>\r\n<td valign="top"><label for="telephone">Telephone Number</label></td>\r\n<td valign="top"><input name="telephone" type="text" size="30" maxlength="30" /></td>\r\n</tr>\r\n<tr>\r\n<td valign="top"><label for="comments">Comments *</label></td>\r\n<td valign="top"><textarea name="comments" maxlength="1000" rows="6" cols="25"></textarea></td>\r\n</tr>\r\n<tr>\r\n<td style="text-align: center;" colspan="2"><input type="submit" value="Submit" /></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</form>', '', -2, 1, 0, 11, '2012-06-11 03:48:33', 62, '', '2013-09-27 11:02:43', 62, 0, '0000-00-00 00:00:00', '2012-06-11 03:48:33', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 0, '', '', 0, 11, 'robots=\nauthor=', '');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `article_image`) VALUES
(42, 'Dækcenter kort', 'daekcenter-kort', '', '<b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;">RENTEFRI KREDIt MED ET DÆKCENTER KORT<br /><br /><img width="441" height="287" alt="Dækcenter kort" src="images/Dækcenter_kort.jpg" /><br />Med et dækcenter Kort har du altid løbende måned +30 dages omkostningsfri kredit og mulighed for OP TIL 12 måneders rentefri kredit</span></b><span style="font-size: 24pt;"><strong>&nbsp;<br /><br /></strong></span>\r\n<h1><span style="text-decoration: underline;"><em><span style="color: #ff0000; background-color: #ffffff;"><strong>TILBUD FRA 7/4 - 31/5 - KØB NU OG BETAL 1. SEPTEMBER 2015 - SEND PENGEPUNGEN PÅ FERIE OG VENT MED AT BETALE DIN REGNING - SØG ONLINE</strong></span></em></span></h1>\r\n<br /><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">Dækcenter </span><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">tilbyder - i samarbejde med Resurs Bank - muligheden for et DÆKCENTER<span style="text-transform: uppercase;"> Kort - som kan bruges til alt - Dæk-fælge-service-reparation mm </span></span><br /><br /><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">DÆKCENTER Kort </span><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">er et fleksibelt alternativ til dig, som selv ønsker at bestemme, hvordan du vil betale. Med DÆKCENTER<span style="text-transform: uppercase;"> Kort</span></span><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"> </span><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">har du altid løbende måned + 30 dages kredit på dine køb, og først derefter beslutter du dig for, hvorvidt du ønsker at indbetale hele saldoen eller om du vil dele betalingen yderligere op. Med valg af løbetid op til 12 måneder tilskrives der ingen renter. Dine muligheder for betaling oplyses sammen med det første indbetalingskort, som du modtager måneden efter dit køb. Vælger du at indbetale hele beløbet, tillægges der ingen renter eller gebyrer.</span><br /><br /><span style="line-height: 115%; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;"><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><a href="https://apponline.resurs.com/form/dk29500" target="_blank"><img width="261" height="40" alt="SØG KREDIT" src="images/SØG_KREDIT.png" /></a>&nbsp;&nbsp;<a href="https://secure.resurs.se/priceinfo/prisskyltning.html?countryCode=DK&amp;representativeId=29500&amp;authorizedBankproductId=DC155069&amp;creditAmount=10000" target="_blank"><img width="311" height="38" alt="BEREGN" src="images/BEREGN.png" /></a></span></span><br /><br /><span style="line-height: 115%; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">I tabellen herunder kan du se eksempler på, hvad de månedlige omkostninger bliver med forskellige betalingsperioder. Den månedlige mindstebetaling skal dog minimum altid udgøre kr. 150,00<span style="color: black;"> </span></span><br /><br />\r\n<div align="center">\r\n<table style="border: currentColor; border-image: none; width: 643px; border-collapse: collapse;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 15pt;">\r\n<td width="99" nowrap="nowrap" style="padding: 0cm 3.5pt; border: 1.5pt solid windowtext; width: 74pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Omkostninger</span><br /><br /></td>\r\n<td width="101" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 75.6pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Løbende md. </span><br /><br /><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">+ 1 md.</span><br /><br /></td>\r\n<td width="85" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 63.8pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">6 mdr.</span><br /><br /></td>\r\n<td width="94" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 70.85pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">12 mdr.</span><br /><br /></td>\r\n<td width="85" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 63.8pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">24 mdr.</span><br /><br /></td>\r\n<td width="95" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 70.9pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">36 mdr.</span><br /><br /></td>\r\n<td width="66" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 49.6pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">48 mdr.</span><br /><br /></td>\r\n</tr>\r\n<tr style="height: 15pt;">\r\n<td width="99" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt; border-style: none solid solid; border-color: currentColor windowtext windowtext; padding: 0cm 3.5pt; width: 74pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Debitorrente</span><br /><br /></td>\r\n<td width="101" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 75.6pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">0 %</span><br /><br /></td>\r\n<td width="85" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 63.8pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">0 %</span><br /><br /></td>\r\n<td width="94" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 70.85pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">0 %</span><br /><br /></td>\r\n<td width="85" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 63.8pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">9,96 %</span><br /><br /></td>\r\n<td width="95" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 70.9pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">12,96 %</span><br /><br /></td>\r\n<td width="66" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 49.6pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">16,96 %</span><br /><br /></td>\r\n</tr>\r\n<tr style="height: 15pt;">\r\n<td width="99" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt; border-style: none solid solid; border-color: currentColor windowtext windowtext; padding: 0cm 3.5pt; width: 74pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Adm. afgift/md</span><br /><br /></td>\r\n<td width="101" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 75.6pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 0,00</span><br /><br /></td>\r\n<td width="85" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 63.8pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 35,00</span><br /><br /></td>\r\n<td width="94" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 70.85pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 35,00</span><br /><br /></td>\r\n<td width="85" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 63.8pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 35,00</span><br /><br /></td>\r\n<td width="95" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 70.9pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 35,00</span><br /><br /></td>\r\n<td width="66" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 49.6pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 35,00</span><br /><br /></td>\r\n</tr>\r\n<tr style="height: 15pt;">\r\n<td width="99" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt; border-style: none solid solid; border-color: currentColor windowtext windowtext; padding: 0cm 3.5pt; width: 74pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Oprettelse</span><br /><br /></td>\r\n<td width="101" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 75.6pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 0,00</span><br /><br /></td>\r\n<td width="85" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 63.8pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 195,00</span><br /><br /></td>\r\n<td width="94" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 70.85pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 395,00</span><br /><br /></td>\r\n<td width="85" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 63.8pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 395,00</span><br /><br /></td>\r\n<td width="95" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 70.9pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 395,00</span><br /><br /></td>\r\n<td width="66" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 49.6pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 395,00</span><br /><br /></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n<span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8.5pt;">Kreditramme kr. 1.000 - kr. 40.000<br />Evt. oprettelsesgebyr tilskrives saldoen i måned 2 efter valg af betalingsperiode.</span><br /><br /><b><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">Repræsentativt eksempel</span></b><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;"><br /></span><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8.5pt;">Kreditbeløb: kr. 15 000,-<br />Kredittid og afdragsperiode: 24 mdr.</span><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;"></span><br /><br />\r\n<div align="center">\r\n<table style="border: currentColor; border-image: none; width: 576px; border-collapse: collapse;" border="1" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr style="height: 15pt;">\r\n<td width="100" nowrap="nowrap" style="padding: 0cm 3.5pt; border: 1.5pt solid windowtext; width: 75.1pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Debitorrente</span><br /><br /></td>\r\n<td width="102" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 76.65pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Samlet kreditbeløb</span><br /><br /></td>\r\n<td width="86" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 64.7pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">ÅOP</span><br /><br /></td>\r\n<td width="105" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 78.6pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kreditomkostninger</span><br /><br /></td>\r\n<td width="86" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 64.7pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Månedlig ydelse</span><br /><br /></td>\r\n<td width="96" nowrap="nowrap" style="border-width: 1.5pt 1.5pt 1.5pt medium; border-style: solid solid solid none; border-color: windowtext windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 72.15pt; height: 15pt;"><span style="color: black; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Totalbeløb.</span><br /><br /></td>\r\n</tr>\r\n<tr style="height: 15pt;">\r\n<td width="100" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt; border-style: none solid solid; border-color: currentColor windowtext windowtext; padding: 0cm 3.5pt; width: 75.1pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">9,96 %</span><br /><br /></td>\r\n<td width="102" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 76.65pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 15.000</span><br /><br /></td>\r\n<td width="86" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 64.7pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">17,2 %</span><br /><br /></td>\r\n<td width="105" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 78.6pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 2.724</span><br /><br /></td>\r\n<td width="86" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 64.7pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 745</span><br /><br /></td>\r\n<td width="96" nowrap="nowrap" style="border-width: medium 1.5pt 1.5pt medium; border-style: none solid solid none; border-color: currentColor windowtext windowtext currentColor; padding: 0cm 3.5pt; width: 72.15pt; height: 15pt;"><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 8pt;">Kr. 17.724</span><br /><br /></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n<b><span style="color: black; line-height: 115%; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">&nbsp;</span></b><br /><br /><b><span style="color: black; line-height: 115%; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">Spørgsmål vedr. finansiering?<br /></span></b><span style="color: black; line-height: 115%; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">Kontakt Resurs Banks kundeservice på telefon 33 32 43 60 eller <a href="mailto:kundservice@resurs.dk">kundservice@resurs.dk</a> <br />Standardiserede europæiske forbrugerkreditoplysning (SEF), tryk </span><a href="https://documenthandler.resurs.com/Dokument.pdf?kedja=29500&amp;land=DK&amp;language=da&amp;bankprodukt=DC155069"><span style="line-height: 115%; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">her</span></a><b><span style="color: red; text-transform: uppercase; line-height: 115%; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;"><br /></span></b><span style="line-height: 115%; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">Almindelige kontobetingelser<span style="color: black;">, tryk </span></span><a href="https://secure.resurs.se/documenthandler/Dokument.pdf?customerType=natural&amp;docType=commonTerms&amp;land=DK&amp;language=da"><span style="line-height: 115%; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 10.5pt;">her</span></a><span style="font-family: ''Avenir LT Std 35 Light'',''sans-serif'';"></span>', '', 1, 1, 0, 11, '2012-05-24 08:41:23', 62, '', '2015-03-31 08:10:28', 62, 0, '0000-00-00 00:00:00', '2012-05-24 08:41:23', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 35, 0, 1, '', '', 0, 6269, 'robots=\nauthor=', ''),
(43, 'Dækcenter.nu juleleg - deltag og vind', 'daekcenter-jul', '', '<div style="text-align: justify;"><b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><span style="background-color: #ff0000;"><span style="color: #ffffff;"><br /><br /></span><span style="font-size: 18pt;"><span style="color: #ffffff;">juleleg: FIND NISSEN PÅ</span><span style="color: #000000; font-size: 14pt;"> <a href="http://www.dækcenter.nu/"><span style="color: #000000; background-color: #ff0000;">WWW.DÆKCENTER.NU</span></a></span></span></span><br /><br /></span></b><b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><span style="font-size: 12pt;">i HELE DECEMBER 2013 LAVER DÆKCENTER.NU EN "JULEleg" find nissen hver dag på <a href="http://www.dækcenter.nu">www.dækcenter.nu</a></span> </span></b><br /><b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><span style="font-size: 10pt;"><br /><img width="820" height="704" alt="dækcenter 1 december" src="images/dækcenter_1_december.png" /><br /><br />(på en af vores afdeligers pris side - tryk ind på en af de <span style="color: #ff0000;">røde</span> pletter&nbsp;på landkortet, og find nissen) -&nbsp;nissen er gemt i en ny afdeling hverdag - sammen med et nyt bogstav hverdag - fra den 1. til den 24. december - når alle 24 bogstaver er samlet, så skal der dannes en sætning med alle 24 bogstaver. <br />men nissen er en rigtig drille nisse, så bogstaverne kommer ikke i den rigtige rækkefølge,&nbsp;&nbsp;...<br /><br />alle der giver det rigtige svar på <a href="http://www.facebook.com/Daekcenter">http://www.facebook.com/Daekcenter</a>&nbsp;inden den 24. december kl. 23.59 - deltager i lodtrækningen om 10 gavekort på 500 kr. til ???<br /><br />Vi vil gerne have jeres gæt, undervejs på <a href="http://www.facebook.com/Daekcenter"><a href="http://www.facebook.com/Daekcenter">http://www.facebook.com/Daekcenter</a>, og når vi 1.000 likes&nbsp;på facebook inden den 24. december deltager alle samtidig&nbsp;i lodtrækningen om et gave kort til <a href="http://www.dækcenter.nu">www.dækcenter.nu</a> på 1.000 kr. :-) - når vi 2.000 likes, udlodder vi 2 gavekort til a 2.000 kr.. - så like og del :-)<br /><br />en lille hjælp er at det er 3 ord og bogstaverne fordeles så ledes: _ _ _ _ _ _ _ _ - _ _ _ _ _ _ _ - _ _ _ _ _ _ _ _ _ <br /><br /></a></span></span></b></div>', '', -2, 1, 0, 11, '2012-05-24 08:41:23', 62, '', '2013-11-19 15:55:36', 62, 0, '0000-00-00 00:00:00', '2012-05-24 08:41:23', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 22, 0, 0, '', '', 0, 34, 'robots=\nauthor=', ''),
(44, 'Dækcenter.nu juleleg - deltag og vind', 'daekcenter-jul', '', '<div style="text-align: justify;"><b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><span style="background-color: #ff0000;"><span style="color: #ffffff;"><br /><br /></span><span style="font-size: 18pt;"><span style="color: #ffffff;">juleleg: FIND NISSEN PÅ</span><span style="color: #000000; font-size: 14pt;"> <a href="http://www.dækcenter.nu/"><span style="color: #000000; background-color: #ff0000;">WWW.DÆKCENTER.NU</span></a></span></span></span><br /><br /></span></b><b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><span style="font-size: 12pt;">i HELE DECEMBER LAVER DÆKCENTER.NU EN "JULEleg" <br /><br />Find nissen hver dag på <a href="http://www.dækcenter.nu">www.dækcenter.nu</a></span> <br /></span></b><br /><b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><span style="font-size: 10pt;"><img width="323" height="315" alt="dæk nisse 1 DEC" src="images/dæk_nisse_1_DEC.jpg" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img width="388" height="314" alt="dækcenter 1 december" src="images/dækcenter_1_december.png" /><br /><br /><br />(på en af vores afdeligers prisside - tryk ind på en af de <span style="color: #ff0000;">røde</span> pletter&nbsp;på landkortet, og find nissen) -&nbsp;nissen er gemt i en ny afdeling hverdag - sammen med et nyt bogstav hverdag - fra den 1. til den 24. december - når alle 24 bogstaver er samlet, så skal der dannes en sætning med alle 24 bogstaver.<br /><br />alle der giver det rigtige svar på <a href="http://www.facebook.com/Daekcenter">http://www.facebook.com/Daekcenter</a>&nbsp;inden den 31. december kl. 23.59 - deltager i lodtrækningen om 10 gavekort på 500 kr. til ???<br /><br />Vi vil gerne have jeres gæt, undervejs på <a href="http://www.facebook.com/Daekcenter"><a href="http://www.facebook.com/Daekcenter">http://www.facebook.com/Daekcenter</a>, og når vi 1.000 likes&nbsp;på facebook inden den 24. december deltager alle samtidig&nbsp;i lodtrækningen om et gave kort til <a href="http://www.dækcenter.nu">www.dækcenter.nu</a> på 1.000 kr. :-) - når vi 2.000 likes, udlodder vi 2 gavekort til a 2.000 kr.. - så like og del :-)<br /><br />en lille hjælp er at det er 3 ord og bogstaverne fordeles så ledes: _ _ _ _ _ _ _ _ - _ _ _ _ _ _ _ - _ _ _ _ _ _ _ _ _ <br /><br /></a></span></span></b></div>', '', -2, 1, 0, 11, '2012-05-24 08:41:23', 62, '', '2013-11-20 20:41:51', 62, 0, '0000-00-00 00:00:00', '2012-05-24 08:41:23', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 0, '', '', 0, 16, 'robots=\nauthor=', ''),
(45, 'Dækcenter.nu julekalender', 'daekcenter-julekalender', '', '<div id="fb-root"></div>\r\n<script>(function(d, s, id) {\r\n  var js, fjs = d.getElementsByTagName(s)[0];\r\n  if (d.getElementById(id)) return;\r\n  js = d.createElement(s); js.id = id;\r\n  js.src = "//connect.facebook.net/da_DK/all.js#xfbml=1";\r\n  fjs.parentNode.insertBefore(js, fjs);\r\n}(document, ''script'', ''facebook-jssdk''));</script>\r\n<div style="text-align: justify;"><b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><span style="background-color: #ff0000;"><span style="color: #ffffff;"><br /><br /></span><span style="font-size: 18pt;"><span style="color: #000000; font-size: 14pt;"><a href="http://www.dækcenter.nu/"><span style="color: #000000; background-color: #ff0000;">WWW.DÆKCENTER.NU</span></a>&nbsp;<span style="color: #ffffff;">julekalender 2013 vind præmier for&nbsp;5.000 kr.</span></span></span></span><br /></span></b><b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><span style="font-size: 12pt;"><br /><br /></span><span style="font-size: 10pt;" size="3">følg med på vores facebook side, hver dag er der en ny låge der kan åbnes og bag ved den kommer et spørgsmål, <br />Svar på dagens spørgsmål og deltag i&nbsp;præmer&nbsp;for en værdi af&nbsp;5.000 kr.<br /><br />Når du har givet dit svar, for du et bogstav, saml alle 24 bogstaver - og<br /></span><span style="font-size: small;" size="2">skriv alle 24 bogstaver&nbsp;på spørgsmålet den 24. december.<br /></span></span></b><br /><b><span style="text-transform: uppercase; font-family: ''Avenir LT Std 35 Light'',''sans-serif''; font-size: 16.5pt;"><span style="font-size: 10pt;"><img width="278" height="235" style="float: left;" alt="dæk nisse 1 DEC" src="images/dæk_nisse_1_DEC.jpg" />alle der giver det rigtige svar&nbsp;inden den 31. december kl. 23.59 <br />deltager i lodtrækningen om præminer for en værdi af&nbsp;5.000 kr.<br /><br />bla. gavekort til:<br /><br />jensens bøfhus....<br />gavekurv...<br />køretur i en ferrari...<br /><br /><br />Del og like dækcenter.nu på facebook...<br /><br />når vi 1.000 likes&nbsp;på facebook inden den 24. december deltager alle - <br />samtidig&nbsp;i lodtrækningen om et gave kort til <a href="http://www.dækcenter.nu">www.dækcenter.nu</a> på 1.000 kr. :-) - <br /><br />når vi 2.500 likes, udlodder vi 2 gavekort til <a href="http://www.dækcenter.nu">www.dækcenter.nu</a> på&nbsp;2.000 kr.. - <br /><br />så like og del :-)\r\n<div class="fb-like" data-layout="button" data-action="like" data-share="true" data-href="http://www.facebook.com/Daekcenter" data-show-faces="true">&nbsp;</div>\r\n<br />god jul til alle fra <br /><br /><a href="http://www.dækcenter.nu">www.dækcenter.nu</a> !!!</span></span></b></div>', '', -2, 1, 0, 11, '2012-05-24 08:41:23', 62, '', '2013-11-22 10:50:50', 62, 0, '0000-00-00 00:00:00', '2012-05-24 08:41:23', '0000-00-00 00:00:00', '', '', 'banner_icon=\ntitle_icon=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 40, 0, 0, '', '', 0, 70, 'robots=\nauthor=', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_content_frontpage`
--

CREATE TABLE IF NOT EXISTS `jos_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_content_frontpage`
--

TRUNCATE TABLE `jos_content_frontpage`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_content_rating`
--

CREATE TABLE IF NOT EXISTS `jos_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(11) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_content_rating`
--

TRUNCATE TABLE `jos_content_rating`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_value` varchar(240) NOT NULL DEFAULT '0',
  `value` varchar(240) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jos_section_value_value_aro` (`section_value`(100),`value`(100)),
  KEY `jos_gacl_hidden_aro` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Truncate table before insert `jos_core_acl_aro`
--

TRUNCATE TABLE `jos_core_acl_aro`;
--
-- Dumping data for table `jos_core_acl_aro`
--

INSERT INTO `jos_core_acl_aro` (`id`, `section_value`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', '62', 0, 'Administrator', 0),
(11, 'users', '63', 0, 'client', 0),
(17, 'users', '69', 0, 'Cuong', 0),
(18, 'users', '70', 0, 'test2', 0),
(19, 'users', '71', 0, 'Kim Hau', 0),
(20, 'users', '72', 0, 'DFI', 0),
(21, 'users', '73', 0, 'Tran Duy Loc', 0),
(22, 'users', '74', 0, 'Kim Tran', 0),
(23, 'users', '75', 0, 'sdf', 0),
(24, 'users', '76', 0, 'sdf', 0),
(25, 'users', '77', 0, 'DFI Administrator', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_groups`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `jos_gacl_parent_id_aro_groups` (`parent_id`),
  KEY `jos_gacl_lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Truncate table before insert `jos_core_acl_aro_groups`
--

TRUNCATE TABLE `jos_core_acl_aro_groups`;
--
-- Dumping data for table `jos_core_acl_aro_groups`
--

INSERT INTO `jos_core_acl_aro_groups` (`id`, `parent_id`, `name`, `lft`, `rgt`, `value`) VALUES
(17, 0, 'ROOT', 1, 22, 'ROOT'),
(28, 17, 'USERS', 2, 21, 'USERS'),
(29, 28, 'Public Frontend', 3, 12, 'Public Frontend'),
(18, 29, 'Registered', 4, 11, 'Registered'),
(19, 18, 'Author', 5, 10, 'Author'),
(20, 19, 'Editor', 6, 9, 'Editor'),
(21, 20, 'Publisher', 7, 8, 'Publisher'),
(30, 28, 'Public Backend', 13, 20, 'Public Backend'),
(23, 30, 'Manager', 14, 19, 'Manager'),
(24, 23, 'Administrator', 15, 18, 'Administrator'),
(25, 24, 'Super Administrator', 16, 17, 'Super Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_map`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_map` (
  `acl_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(230) NOT NULL DEFAULT '0',
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_core_acl_aro_map`
--

TRUNCATE TABLE `jos_core_acl_aro_map`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_sections`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(230) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(230) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jos_gacl_value_aro_sections` (`value`),
  KEY `jos_gacl_hidden_aro_sections` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Truncate table before insert `jos_core_acl_aro_sections`
--

TRUNCATE TABLE `jos_core_acl_aro_sections`;
--
-- Dumping data for table `jos_core_acl_aro_sections`
--

INSERT INTO `jos_core_acl_aro_sections` (`id`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', 1, 'Users', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_groups_aro_map`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_groups_aro_map` (
  `group_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(240) NOT NULL DEFAULT '',
  `aro_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `group_id_aro_id_groups_aro_map` (`group_id`,`section_value`,`aro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_core_acl_groups_aro_map`
--

TRUNCATE TABLE `jos_core_acl_groups_aro_map`;
--
-- Dumping data for table `jos_core_acl_groups_aro_map`
--

INSERT INTO `jos_core_acl_groups_aro_map` (`group_id`, `section_value`, `aro_id`) VALUES
(18, '', 11),
(18, '', 18),
(18, '', 19),
(18, '', 21),
(18, '', 22),
(18, '', 23),
(18, '', 24),
(23, '', 25),
(25, '', 10),
(25, '', 17),
(25, '', 20);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_items`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_items` (
  `time_stamp` date NOT NULL DEFAULT '0000-00-00',
  `item_table` varchar(50) NOT NULL DEFAULT '',
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_core_log_items`
--

TRUNCATE TABLE `jos_core_log_items`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_searches`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_core_log_searches`
--

TRUNCATE TABLE `jos_core_log_searches`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_campaigns`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_campaigns` (
  `dfi_campaign_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `published` tinyint(1) DEFAULT '1',
  `ordering` int(11) DEFAULT NULL,
  `description` text,
  `published_date` date DEFAULT NULL,
  `unpublished_date` date DEFAULT NULL,
  PRIMARY KEY (`dfi_campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_dfi_campaigns`
--

TRUNCATE TABLE `jos_dfi_campaigns`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_campaign_products`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_campaign_products` (
  `dfi_campaign_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_product_id` int(11) DEFAULT NULL,
  `dfi_campaign_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`dfi_campaign_product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Truncate table before insert `jos_dfi_campaign_products`
--

TRUNCATE TABLE `jos_dfi_campaign_products`;
--
-- Dumping data for table `jos_dfi_campaign_products`
--

INSERT INTO `jos_dfi_campaign_products` (`dfi_campaign_product_id`, `dfi_product_id`, `dfi_campaign_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_campaign_to_products`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_campaign_to_products` (
  `dfi_campaign_to_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_product_id` int(11) DEFAULT NULL,
  `dfi_campaign_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`dfi_campaign_to_product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=283 ;

--
-- Truncate table before insert `jos_dfi_campaign_to_products`
--

TRUNCATE TABLE `jos_dfi_campaign_to_products`;
--
-- Dumping data for table `jos_dfi_campaign_to_products`
--

INSERT INTO `jos_dfi_campaign_to_products` (`dfi_campaign_to_product_id`, `dfi_product_id`, `dfi_campaign_id`) VALUES
(186, 28, 15),
(122, 10, 2),
(121, 11, 2),
(127, 16, 1),
(119, 19, 2),
(117, 30, 1),
(115, 29, 9),
(164, 29, 13),
(277, 26, 19),
(274, 25, 22),
(272, 24, 22),
(270, 23, 22),
(268, 22, 22),
(160, 35, 13),
(112, 20, 7),
(17, 3, 2),
(18, 3, 1),
(19, 3, 3),
(20, 3, 4),
(21, 4, 4),
(22, 5, 4),
(23, 7, 5),
(92, 11, 6),
(90, 8, 6),
(89, 8, 5),
(83, 19, 5),
(80, 18, 4),
(88, 8, 4),
(167, 9, 12),
(58, 10, 5),
(91, 11, 5),
(60, 12, 5),
(188, 37, 11),
(126, 16, 2),
(87, 8, 3),
(79, 17, 6),
(77, 17, 4),
(184, 36, 15),
(78, 17, 5),
(252, 35, 17),
(181, 15, 15),
(183, 14, 15),
(212, 38, 12),
(128, 16, 6),
(165, 31, 8),
(180, 15, 16),
(196, 39, 12),
(265, 21, 20),
(227, 34, 11),
(176, 32, 15),
(276, 26, 22),
(161, 33, 13),
(179, 13, 15),
(182, 14, 16),
(175, 32, 16),
(185, 28, 16),
(221, 49, 18),
(197, 40, 12),
(192, 41, 11),
(193, 42, 11),
(194, 43, 11),
(195, 44, 11),
(198, 40, 11),
(199, 39, 11),
(204, 45, 12),
(205, 46, 12),
(206, 47, 12),
(207, 48, 12),
(208, 48, 11),
(209, 47, 11),
(210, 46, 11),
(211, 45, 11),
(213, 38, 11),
(226, 34, 10),
(233, 50, 19),
(222, 49, 19),
(224, 27, 17),
(228, 34, 12),
(229, 29, 15),
(231, 51, 17),
(232, 51, 19),
(234, 50, 17),
(236, 52, 19),
(237, 52, 17),
(238, 53, 17),
(239, 53, 19),
(240, 54, 17),
(241, 54, 19),
(247, 55, 19),
(246, 55, 17),
(248, 56, 17),
(249, 56, 19),
(250, 57, 17),
(251, 57, 19),
(253, 34, 17),
(254, 33, 17),
(256, 58, 22),
(257, 58, 21),
(275, 26, 20),
(273, 25, 20),
(271, 24, 20),
(269, 23, 20),
(267, 22, 20),
(264, 21, 19),
(266, 21, 22),
(278, 25, 19),
(279, 24, 19),
(280, 23, 19),
(281, 22, 19),
(282, 28, 19);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_catalogs`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_catalogs` (
  `dfi_catalog_id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `description` text,
  `published` tinyint(1) DEFAULT '1',
  `ordering` int(11) DEFAULT NULL,
  PRIMARY KEY (`dfi_catalog_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=109 ;

--
-- Truncate table before insert `jos_dfi_catalogs`
--

TRUNCATE TABLE `jos_dfi_catalogs`;
--
-- Dumping data for table `jos_dfi_catalogs`
--

INSERT INTO `jos_dfi_catalogs` (`dfi_catalog_id`, `catid`, `title`, `filename`, `description`, `published`, `ordering`) VALUES
(12, 8, 'Odense', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 1),
(11, 8, 'Brenderup', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 5),
(98, 1, 'Øsby', '', '', 1, 42),
(8, 1, 'Kolding', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 1),
(7, 1, 'Randers', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 3),
(13, 1, 'Aalestrup', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 6),
(14, 1, 'Ringkøbing', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 2),
(15, 9, 'Næstved', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 5),
(16, 10, 'Nykøbing', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 1),
(17, 1, 'Trige', '', '', 1, 4),
(18, 1, 'Fredericia', '', '', 1, 3),
(19, 10, 'Bogø', '', '', 1, 2),
(55, 9, 'Birkerød', '', '', 1, 21),
(21, 9, 'Stensved', '', '', 1, 7),
(22, 9, 'Herlufmagle', '', '', 1, 2),
(23, 9, 'Fuglebjerg', '', '', 1, 3),
(24, 9, 'Næstved Nord', '', '', 1, 6),
(25, 9, 'Svinninge', '', '', 1, 4),
(26, 9, 'Helsingør', '', '', 1, 1),
(27, 9, 'Rude', '', '', 1, 8),
(28, 9, 'Svebølle', '', '', 1, 9),
(30, 1, 'Tim', '', '', 1, 7),
(31, 9, 'Nykøbing S.', '', '', 1, 10),
(32, 9, 'Brøndby', '', '', 1, 11),
(33, 9, 'Kalundborg', '', '', 1, 12),
(34, 9, 'Holbæk', '', '', 1, 13),
(35, 9, 'Boeslunde', '', '', 1, 14),
(36, 1, 'Skive', '', '', 1, 8),
(37, 1, 'Pandrup', '', '', 1, 9),
(39, 9, 'Korsør', '', '', 1, 16),
(40, 1, 'Agerskov', '', '', 1, 10),
(41, 9, 'Vordingborg', '', '', 1, 17),
(42, 9, 'Præstø', '', '', 1, 18),
(43, 1, 'Them', '', '', 1, 11),
(44, 1, 'Vojens', '', '', 1, 12),
(45, 1, 'Haderslev', '', '', 1, 13),
(46, 9, 'Haslev', '', '', 1, 19),
(95, 1, 'Finderup', '', '', 1, 40),
(96, 9, 'Stevns', '', '', 1, 34),
(97, 1, 'Hjørring', '', '', 1, 41),
(108, 9, 'Køge', '', '', 1, 38),
(48, 10, 'Sakskøbing', '', '', 1, 4),
(49, 1, 'Esbjerg', '', '', 1, 14),
(50, 1, 'Brønderslev', '', '', 1, 15),
(51, 1, 'Nørre Snede', '', '', 1, 16),
(52, 1, 'Lem', '', '', 1, 17),
(53, 8, 'Bogense', '', '', 1, 6),
(54, 9, 'Holmegaard', '', '', 1, 20),
(56, 1, 'Herning', '', '', 1, 18),
(57, 1, 'Farsø', '', '', 1, 19),
(58, 1, 'Svenstrup', '', '', 1, 20),
(59, 1, 'Sindal', '', '', 1, 21),
(60, 1, 'Thisted', '', '', 1, 22),
(61, 9, 'Sæby, Høng', '', '', 1, 22),
(62, 9, 'Tjæreby, Korsør', '', '', 1, 23),
(63, 1, 'Tønder', '', '', 1, 23),
(66, 9, 'Mørkøv', '', '', 1, 25),
(65, 9, 'Ringsted', '', '', 1, 24),
(67, 1, 'Viby J', '', '', 1, 24),
(68, 1, 'Thorup', '', '', 1, 25),
(69, 1, 'Nykøbing Mors', '', '', 1, 26),
(70, 1, 'Viborg', '', '', 1, 27),
(71, 9, 'Gislinge', '', '', 1, 26),
(72, 1, 'Sønderborg', '', '', 1, 28),
(73, 1, 'Sydals', '', '', 1, 29),
(74, 8, 'V. Skerninge', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 7),
(75, 9, 'Lundby', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 8),
(76, 9, 'Græsted', '', 'Sommerdæk - vinterdæk - helårsdæk - Fælge', 1, 27),
(77, 1, 'Lunderskov', '', '', 1, 30),
(78, 1, 'Gråsten', '', '', 1, 31),
(79, 1, 'Bolderslev', '', '', 1, 32),
(80, 1, 'Broager', '', '', 1, 33),
(81, 9, 'Lyngby', '', '', 1, 28),
(82, 10, 'Stege', '', '', 1, 5),
(83, 8, 'Marslev', '', '', 1, 8),
(84, 9, 'Solrød Strand', '', '', 1, 29),
(85, 9, 'Søborg', '', '', 1, 30),
(86, 1, 'Aabenraa', '', '', 1, 34),
(87, 9, 'Hørsholm', '', '', 1, 31),
(88, 9, 'Taastrup', '', '', 1, 32),
(89, 1, 'Aalborg', '', '', 1, 35),
(90, 1, 'Skjern', '', '', 1, 36),
(91, 1, 'Ikast', '', '', 1, 37),
(92, 9, 'Rønne', '', '', 1, 33),
(93, 1, 'Videbæk', '', '', 1, 38),
(94, 1, 'Suldrup', '', '', 1, 39),
(99, 9, 'Havdrup', '', '', 1, 35),
(100, 9, 'Birkerød', '', '', 1, 36),
(101, 9, 'Faxe', '', '', 1, 37),
(102, 1, 'Glejbjerg', '', '', 1, 43),
(104, 8, 'Svendborg', '', '', 1, 9),
(105, 10, 'Nakskov', '', '', 1, 6),
(106, 1, 'Roslev', '', '', 1, 45),
(107, 8, 'Nyborg', '', '', 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_client_pris`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_client_pris` (
  `id` int(11) NOT NULL DEFAULT '0',
  `shop_id` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `jan` float DEFAULT NULL,
  `feb` float DEFAULT NULL,
  `mar` float DEFAULT NULL,
  `apr` float DEFAULT NULL,
  `may` float DEFAULT NULL,
  `jun` float DEFAULT NULL,
  `july` float DEFAULT NULL,
  `aug` float DEFAULT NULL,
  `sep` float DEFAULT NULL,
  `otc` float DEFAULT NULL,
  `nov` float DEFAULT NULL,
  `dece` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_dfi_client_pris`
--

TRUNCATE TABLE `jos_dfi_client_pris`;
--
-- Dumping data for table `jos_dfi_client_pris`
--

INSERT INTO `jos_dfi_client_pris` (`id`, `shop_id`, `year`, `jan`, `feb`, `mar`, `apr`, `may`, `jun`, `july`, `aug`, `sep`, `otc`, `nov`, `dece`) VALUES
(1, 44, 2011, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_client_products`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_client_products` (
  `dfi_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_shop_id` int(11) DEFAULT NULL,
  `ean_kode` varchar(255) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `hvidpris` float DEFAULT '0',
  `rodpris` float DEFAULT '0',
  `nettopris` float DEFAULT '0',
  `wee` float DEFAULT NULL,
  `kolli` text,
  `nupris` float DEFAULT '0',
  PRIMARY KEY (`dfi_product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Truncate table before insert `jos_dfi_client_products`
--

TRUNCATE TABLE `jos_dfi_client_products`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_distribution_rates`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_distribution_rates` (
  `dfi_distribution_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_kobeark_product_id` int(11) DEFAULT NULL,
  `dfi_shop_id` int(11) DEFAULT NULL,
  `rate` float DEFAULT NULL,
  PRIMARY KEY (`dfi_distribution_rate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_dfi_distribution_rates`
--

TRUNCATE TABLE `jos_dfi_distribution_rates`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_kobreaks`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_kobreaks` (
  `dfi_kobreak_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_supplier_id` int(11) DEFAULT NULL,
  `lev_uge` varchar(255) DEFAULT NULL,
  `val_uge` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `lev_betingelse` varchar(255) DEFAULT NULL,
  `ann_tilskud` varchar(255) DEFAULT NULL,
  `franko` varchar(255) DEFAULT NULL,
  `description` text,
  `published` tinyint(1) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `svarfrist` datetime DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `dfi_campaign_id` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `check_ok` int(1) NOT NULL,
  PRIMARY KEY (`dfi_kobreak_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Truncate table before insert `jos_dfi_kobreaks`
--

TRUNCATE TABLE `jos_dfi_kobreaks`;
--
-- Dumping data for table `jos_dfi_kobreaks`
--

INSERT INTO `jos_dfi_kobreaks` (`dfi_kobreak_id`, `dfi_supplier_id`, `lev_uge`, `val_uge`, `created`, `lev_betingelse`, `ann_tilskud`, `franko`, `description`, `published`, `name`, `modified`, `svarfrist`, `ordering`, `dfi_campaign_id`, `status`, `check_ok`) VALUES
(17, 2, '', '', '2011-07-01 10:49:10', NULL, '', '', '', 0, 'Avis 9 2011', '2011-07-01 10:49:10', '0000-00-00 00:00:00', 1, 7, 0, 0),
(18, 2, '38', '50', '2011-07-01 10:55:34', NULL, '', '', '', 0, 'Tilbud 10,5 - 2011', '2011-07-01 10:55:34', '0000-00-00 00:00:00', 1, 9, 0, 0),
(19, 2, '', '', '2011-07-01 10:56:53', NULL, '', '', '', 0, 'Tilbud 10,5 - 2011', '2011-07-01 10:56:53', '0000-00-00 00:00:00', 2, 9, 0, 0),
(20, 2, '38', '52', '2011-07-01 11:00:24', NULL, '', '', '', 1, 'Tilbud 10', '2011-07-01 11:00:24', '0000-00-00 00:00:00', 3, 9, 0, 0),
(21, 2, '38', '52', '2011-07-01 11:01:58', NULL, '', '', '', 1, 'Tilbud 10,5', '2011-07-01 11:01:58', '0000-00-00 00:00:00', 4, 9, 0, 0),
(22, 32, '38', '52', '2011-07-01 11:06:48', NULL, '', '', '', 1, 'Tilbud 10,5', '2011-07-01 11:06:48', '0000-00-00 00:00:00', 1, 9, 0, 0),
(54, 2147483647, '', '', '2012-04-23 08:07:40', NULL, '', '', '', 0, 'Henrik', '2012-04-23 08:08:30', '1999-11-30 00:00:00', 1, 2147483647, 1, 0),
(53, 32, '12', '26', '2012-04-12 08:37:48', NULL, '', '', '', 1, 'Test avis 12042012', '2012-04-12 08:46:12', '1999-11-30 00:00:00', 2, 19, 1, 0),
(51, 32, '47', '', '2012-03-29 09:33:58', NULL, '', '', '', 0, 'Henriks Avis', '2012-03-29 09:33:58', '0000-00-00 00:00:00', 2, 17, 1, 0),
(52, 32, '27', '', '2012-04-11 19:53:49', NULL, '', '', '', 1, 'CondorVarerA8+10+12-2012', '2012-04-11 20:07:49', '1999-11-30 00:00:00', 1, 19, 3, 0),
(47, 9, 'test', 'test', '2012-03-15 07:22:17', NULL, 'test', '', 'Test test', 0, 'Test', '2012-03-15 07:23:23', '1999-11-30 00:00:00', 1, 23, 1, 0),
(48, 32, '19', '', '2012-03-16 06:11:27', NULL, '', '', '', 0, 'CondorElkedelA6+8-2012', '2012-03-20 05:11:45', '1999-11-30 00:00:00', 1, 17, 1, 0),
(49, 2, '19', '', '2012-03-20 05:11:35', NULL, '', '', '', 0, 'OBHNordicaElkedelA6+8-2012', '2012-03-20 05:11:35', '2012-03-23 06:11:26', 1, 17, 1, 0),
(50, 4, '41', '', '2012-03-29 05:22:33', NULL, '', '', '', 1, 'F&HKalendernisseA11-2012', '2012-03-29 05:35:52', '2012-03-31 12:00:00', 1, 21, 1, 1),
(46, 33, '19', '23', '2012-03-15 03:53:26', NULL, '', '', '', 1, 'SEBJamieOliverCastAluA6+8-2012', '2012-03-16 06:21:07', '2012-03-16 18:00:00', 1, 17, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_kobreak_products`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_kobreak_products` (
  `dfi_kobreak_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_product_id` int(11) DEFAULT NULL,
  `dfi_kobreak_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT '0',
  `hvidpris` float DEFAULT '0',
  `nettopris` float DEFAULT '0',
  `rodpris` float DEFAULT '0',
  `nupris` float DEFAULT '0',
  PRIMARY KEY (`dfi_kobreak_product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=136 ;

--
-- Truncate table before insert `jos_dfi_kobreak_products`
--

TRUNCATE TABLE `jos_dfi_kobreak_products`;
--
-- Dumping data for table `jos_dfi_kobreak_products`
--

INSERT INTO `jos_dfi_kobreak_products` (`dfi_kobreak_product_id`, `dfi_product_id`, `dfi_kobreak_id`, `quantity`, `hvidpris`, `nettopris`, `rodpris`, `nupris`) VALUES
(1, 1, 1, 3000, 349.95, 119, 299.95, 299.95),
(2, 1, 2, 3000, 349.95, 12, 299.95, 199.95),
(3, 1, 3, 3000, 349.95, 12, 299.95, 299.95),
(4, 3, 3, 12, 133, 123, 2323, 2323),
(5, 7, 5, 0, 999, 250, 499, 399),
(6, 7, 7, 0, 999, 0.5, 499, 499),
(7, 8, 11, 0, 849.95, 0, 849.95, 849.95),
(8, 9, 11, 0, 399.95, 132, 399.95, 399.95),
(9, 10, 11, 0, 499.95, 0, 499.95, 299.95),
(10, 11, 11, 0, 599.95, 0, 599.95, 599.95),
(11, 12, 11, 0, 549.95, 0, 549.95, 549.95),
(12, 13, 11, 0, 599.95, 0, 599.95, 599.95),
(13, 14, 11, 0, 699.95, 0, 699.95, 699.95),
(14, 15, 11, 0, 799.95, 0, 799.95, 799.95),
(15, 16, 12, 0, 99.95, 25, 79.95, 79.95),
(16, 28, 23, 0, 24.95, 12, 29.95, 29.95),
(17, 29, 23, 0, 49.95, 10, 39, 39),
(18, 19, 3, 0, 620, 0, 580, 11),
(19, 16, 3, 0, 99.95, 0, 79.95, 10),
(20, 11, 3, 0, 599.95, 0, 599.95, 599.95),
(21, 10, 3, 0, 499.95, 0, 499.95, 499.95),
(22, 14, 3, 0, 699.95, 0, 699.95, 699.95),
(23, 15, 3, 0, 799.95, 0, 799.95, 799.95),
(24, 13, 3, 0, 599.95, 0, 599.95, 599.95),
(25, 29, 25, 0, 49.95, 10, 39.95, 29.95),
(26, 27, 25, 0, 39.95, 12.95, 34.95, 29.95),
(34, 34, 27, 0, 199.95, 59, 149.95, 99.95),
(33, 35, 27, 0, 199.95, 59, 149.95, 99.95),
(32, 30, 27, 0, 39.95, 0, 34.95, 34.95),
(31, 16, 27, 0, 99.95, 0, 79.95, 79.95),
(35, 33, 27, 0, 199.95, 59, 149.95, 99.95),
(36, 32, 27, 0, 199.95, 52, 149.95, 99.95),
(37, 26, 27, 1000, 149.95, 26, 99.95, 99.95),
(38, 34, 28, 0, 199.95, 59, 149.95, 99.95),
(39, 32, 28, 0, 199.95, 52, 149.95, 99.95),
(40, 27, 28, 0, 39.95, 12.95, 34.95, 29.95),
(41, 35, 29, 0, 199.95, 0, 149.95, 149.95),
(42, 34, 29, 0, 199.95, 0, 149.95, 149.95),
(43, 33, 29, 0, 199.95, 0, 149.95, 149.95),
(44, 32, 29, 0, 199.95, 0, 149.95, 149.95),
(45, 31, 29, 0, 0, 0, 0, 0),
(46, 21, 29, 1000, 149.95, 0, 99.95, 99.95),
(48, 32, 30, 0, 499.95, 0, 399.95, 12),
(49, 33, 30, 0, 199.95, 0, 149.95, 149.95),
(51, 21, 30, 1000, 399.95, 0, 249.95, 249.95),
(55, 29, 31, 0, 400, 0, 400, 400),
(54, 28, 31, 0, 24.95, 0, 29.95, 21.95),
(56, 27, 32, 10000, 45, 0, 45, 45),
(57, 28, 32, 0, 24.95, 0, 29.95, 29.95),
(63, 32, 34, 0, 199.95, 0, 149.95, 500.95),
(62, 28, 34, 0, 24.95, 0, 29.95, 29.95),
(61, 27, 34, 1000, 39.95, 0, 34.95, 34.95),
(68, 15, 35, 0, 799.95, 264, 799.95, 799.95),
(69, 14, 35, 0, 699.95, 231, 699.95, 699.95),
(66, 13, 35, 0, 599.95, 198, 599.95, 599.95),
(70, 36, 36, 0, 200, 60, 159, 159),
(71, 40, 37, 0, 149.95, 50, 149.95, 149.95),
(72, 39, 37, 0, 149.95, 50, 149.95, 149.95),
(73, 38, 37, 0, 249.95, 67.5, 199.95, 199.95),
(74, 41, 37, 0, 549.95, 149.95, 399.95, 399.95),
(75, 42, 37, 0, 549.95, 149.95, 399.95, 399.95),
(76, 43, 37, 0, 549.95, 149.95, 399.95, 399.95),
(77, 44, 37, 0, 549.95, 149.95, 399.95, 399.95),
(79, 37, 37, 0, 349.95, 135, 349.95, 349.95),
(80, 45, 38, 0, 29.95, 10.22, 29.95, 29.95),
(81, 46, 38, 0, 34.95, 12.66, 34.95, 34.95),
(82, 47, 38, 0, 39.95, 13.72, 39.95, 39.95),
(83, 48, 38, 0, 49.95, 15.13, 49.95, 49.95),
(84, 34, 40, 0, 0, 0, 0, 0),
(86, 34, 41, 1000, 100, 100, 100, 100),
(87, 27, 42, 0, 39.95, 0, 34.95, 32.5),
(88, 49, 43, 0, 149.95, 49.95, 139.95, 139.95),
(89, 34, 39, 1000, 199.95, 0, 149.95, 149.95),
(90, 37, 39, 0, 349.95, 0, 349.95, 349.95),
(91, 38, 39, 0, 249.95, 0, 199.95, 199.95),
(92, 39, 39, 0, 149.95, 0, 149.95, 149.95),
(93, 40, 39, 0, 149.95, 0, 149.95, 149.95),
(94, 41, 39, 0, 549.95, 0, 399.95, 399.95),
(95, 42, 39, 0, 549.95, 0, 399.95, 399.95),
(96, 43, 39, 0, 549.95, 0, 399.95, 399.95),
(97, 44, 39, 0, 549.95, 0, 399.95, 399.95),
(98, 45, 39, 0, 29.95, 0, 29.95, 29.95),
(100, 28, 44, 0, 24.95, 12.25, 29.95, 29.95),
(101, 51, 46, 1000, 799.95, 175, 299.95, 299.95),
(102, 50, 46, 600, 899.95, 175, 299.95, 299.95),
(103, 52, 46, 600, 599.95, 175, 299.95, 299.95),
(104, 53, 46, 300, 499.95, 175, 299.95, 299.95),
(105, 54, 46, 300, 899.95, 175, 299.95, 299.95),
(108, 56, 46, 0, 699.95, 175, 299.95, 299.95),
(109, 57, 46, 400, 899.95, 175, 299.95, 299.95),
(115, 33, 48, 0, 199.95, 59, 99.95, 99.95),
(114, 34, 48, 1000, 199.95, 59, 99.95, 99.95),
(113, 35, 48, 0, 199.95, 59, 99.95, 99.95),
(117, 58, 50, 1500, 199.95, 49.95, 149.95, 149.95),
(118, 35, 51, 0, 199.95, 59, 149.95, 99.95),
(119, 34, 51, 1000, 199.95, 59, 149.95, 99.95),
(120, 33, 51, 0, 199.95, 59, 149.95, 99.95),
(132, 26, 52, 1000, 149.95, 26, 99.95, 99.95),
(131, 25, 52, 1000, 79.95, 15, 49.95, 49.95),
(130, 24, 52, 1000, 99.95, 17, 69.95, 69.95),
(129, 23, 52, 1000, 149.95, 30, 99.95, 99.95),
(128, 22, 52, 1000, 149.95, 26, 99.95, 99.95),
(127, 21, 52, 1000, 149.95, 26, 99.95, 99.95),
(135, 28, 53, 4000, 24.95, 12.25, 29.95, 29.95);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_maps`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_maps` (
  `dfi_map_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_shop_id` int(11) DEFAULT NULL,
  `x_value` float DEFAULT NULL,
  `y_value` float DEFAULT NULL,
  PRIMARY KEY (`dfi_map_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=149 ;

--
-- Truncate table before insert `jos_dfi_maps`
--

TRUNCATE TABLE `jos_dfi_maps`;
--
-- Dumping data for table `jos_dfi_maps`
--

INSERT INTO `jos_dfi_maps` (`dfi_map_id`, `dfi_shop_id`, `x_value`, `y_value`) VALUES
(107, 120, 199, 580),
(41, 60, 232, 467),
(45, 56, 16, 322),
(132, 145, 52, 335),
(133, 147, 89, 144),
(35, 51, 276, 486),
(46, 59, 458, 619),
(47, 57, 441, 518),
(48, 58, 236, 258),
(49, 54, 248, 307),
(50, 55, 164, 203),
(51, 61, 174, 451),
(53, 63, 541, 353),
(54, 64, 186, 449),
(55, 65, 477, 563),
(78, 89, 175, 328),
(92, 105, 153, 189),
(58, 68, 443, 493),
(59, 69, 429, 506),
(60, 70, 418, 495),
(61, 72, 406, 514),
(109, 123, 508, 343),
(63, 74, 21, 305),
(65, 77, 519, 429),
(66, 76, 430, 374),
(67, 78, 360, 427),
(68, 79, 441, 422),
(69, 80, 167, 464),
(70, 81, 388, 504),
(71, 82, 112, 234),
(72, 83, 191, 99),
(73, 85, 366, 491),
(74, 84, 395, 479),
(75, 86, 119, 525),
(76, 87, 473, 536),
(77, 88, 453, 561),
(79, 90, 134, 505),
(80, 91, 159, 501),
(81, 92, 465, 485),
(82, 94, 426, 603),
(83, 93, 378, 610),
(84, 95, 43, 455),
(85, 96, 128, 511),
(86, 97, 239, 86),
(87, 98, 167, 357),
(88, 99, 28, 343),
(89, 101, 454, 513),
(90, 103, 526, 395),
(91, 104, 118, 322),
(93, 106, 216, 150),
(94, 107, 254, 52),
(95, 108, 102, 136),
(96, 109, 378, 488),
(97, 110, 384, 455),
(98, 113, 449, 462),
(99, 100, 243, 445),
(100, 111, 92, 568),
(101, 114, 246, 328),
(102, 115, 418, 426),
(103, 116, 419, 400),
(104, 117, 271, 97),
(105, 118, 95, 186),
(106, 119, 163, 264),
(108, 121, 219, 583),
(110, 122, 450, 541),
(111, 125, 0, 0),
(112, 124, 278, 537),
(113, 126, 146, 460),
(114, 127, 175, 572),
(115, 128, 133, 557),
(116, 129, 184, 589),
(117, 132, 536, 405),
(118, 131, 508, 568),
(119, 130, 302, 485),
(120, 135, 477, 468),
(121, 134, 501, 448),
(122, 133, 522, 414),
(123, 136, 172, 556),
(124, 138, 505, 421),
(125, 137, 530, 380),
(126, 141, 230, 134),
(127, 140, 52, 364),
(128, 139, 142, 323),
(129, 144, 196, 193),
(130, 143, 75, 333),
(131, 142, 820, 530),
(134, 148, 241, 50),
(135, 146, 515, 488),
(136, 149, 106, 331),
(137, 150, 175, 512),
(138, 153, 514, 386),
(139, 152, 487, 503),
(140, 151, 481, 454),
(141, 154, 80, 437),
(142, 155, 292, 53),
(143, 156, 282, 472),
(144, 157, 304, 543),
(145, 158, 362, 599),
(146, 159, 120, 192),
(147, 160, 316, 501),
(148, 161, 494, 467);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_members`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_members` (
  `dfi_member_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `dfi_shop_id` int(11) DEFAULT NULL,
  `role` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`dfi_member_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Truncate table before insert `jos_dfi_members`
--

TRUNCATE TABLE `jos_dfi_members`;
--
-- Dumping data for table `jos_dfi_members`
--

INSERT INTO `jos_dfi_members` (`dfi_member_id`, `user_id`, `dfi_shop_id`, `role`) VALUES
(1, 62, 35, 1),
(2, 70, 42, 0),
(3, 71, 43, 1),
(4, 63, 42, 0),
(5, 72, 44, 1),
(6, 73, 45, 1),
(7, 74, 46, 1),
(9, 75, 47, 1),
(10, 76, 48, 1),
(11, 77, 28, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_orders`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_orders` (
  `dfi_order_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_shop_id` int(11) DEFAULT NULL,
  `dfi_kobreak_id` int(11) DEFAULT NULL,
  `note` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `sent` datetime DEFAULT NULL,
  `dfi_order_status_id` int(11) DEFAULT NULL,
  `received` datetime DEFAULT NULL,
  PRIMARY KEY (`dfi_order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Truncate table before insert `jos_dfi_orders`
--

TRUNCATE TABLE `jos_dfi_orders`;
--
-- Dumping data for table `jos_dfi_orders`
--

INSERT INTO `jos_dfi_orders` (`dfi_order_id`, `dfi_shop_id`, `dfi_kobreak_id`, `note`, `created`, `modified`, `sent`, `dfi_order_status_id`, `received`) VALUES
(1, 44, 1, '', '2010-11-04 10:21:33', '2010-11-04 10:21:33', '2010-12-10 08:52:50', 4, '1969-12-31 06:21:33'),
(2, 44, 2, '', '2010-12-22 10:17:32', '2010-12-22 10:17:32', '2011-12-08 07:28:05', 3, '1969-12-31 05:17:32'),
(3, 44, 3, '', '2011-01-28 07:47:47', '2011-01-28 07:47:47', NULL, 2, '1970-01-01 14:47:47'),
(4, 44, 11, '', '2011-04-12 08:42:31', '2011-04-12 08:42:31', '2011-04-12 08:50:24', 3, '1970-01-01 10:42:31'),
(5, 44, 12, '', '2011-04-12 09:10:22', '2011-04-12 09:10:22', '2011-04-12 09:11:14', 4, '1970-01-01 11:10:22'),
(6, 44, 13, '', '2011-05-09 06:34:18', '0000-00-00 00:00:00', NULL, 1, '1970-01-01 01:00:00'),
(7, 44, 23, '', '2011-07-01 11:51:16', '2011-07-01 11:51:16', '2011-07-01 11:55:40', 3, '1970-01-01 13:51:16'),
(8, 10, 3, '', NULL, NULL, NULL, 1, NULL),
(9, 10, 3, '', NULL, NULL, NULL, 1, NULL),
(10, 10, 3, '', NULL, NULL, NULL, 1, NULL),
(11, 44, 28, '', '2011-11-07 08:08:18', '2011-11-07 08:08:18', '2011-11-07 08:15:57', 3, '1970-01-01 09:08:18'),
(12, 44, 29, '', '2011-11-07 08:38:38', '2011-11-07 08:38:38', '2011-11-07 08:40:21', 3, '1970-01-01 09:38:38'),
(13, 44, 32, '', '2011-12-21 15:03:41', '2011-12-21 15:03:41', '2011-12-21 15:05:13', 4, '1970-01-01 16:03:41'),
(14, 44, 34, '', '2012-01-10 10:49:21', '2012-01-10 10:49:21', '2012-01-10 11:23:40', 3, '1970-01-01 11:49:21'),
(15, 44, 35, '', '2012-01-10 11:19:45', '2012-01-10 11:19:45', '2012-01-10 11:21:17', 3, '1970-01-01 12:19:45'),
(16, 44, 36, '', '2012-01-10 11:30:57', '2012-01-10 11:30:57', '2012-01-10 11:36:21', 4, '1970-01-01 12:30:57'),
(17, 44, 37, '', '2012-02-13 07:45:54', '2012-02-13 07:45:54', '2012-02-13 07:50:55', 3, '1970-01-01 08:45:54'),
(18, 44, 38, '', '2012-02-13 07:47:08', '2012-02-13 07:47:08', '2012-02-13 07:51:20', 3, '1970-01-01 08:47:08'),
(19, 44, 41, '', '2012-02-13 10:05:46', '2012-02-13 10:05:46', NULL, 2, '1970-01-01 11:05:46'),
(20, 44, 42, '', '2012-02-16 11:59:25', '2012-02-16 11:59:25', NULL, 2, '1970-01-01 12:59:25'),
(21, 44, 39, '', '2012-02-21 13:37:38', '2012-02-21 13:37:38', NULL, 2, '1970-01-01 14:37:38'),
(22, 49, 9, '', NULL, NULL, NULL, 1, NULL),
(23, 49, 42, '', NULL, NULL, NULL, 1, NULL),
(24, 49, 42, '', NULL, NULL, NULL, 1, NULL),
(25, 38, 41, '', NULL, NULL, NULL, 1, NULL),
(26, 37, 41, '', NULL, NULL, NULL, 1, NULL),
(27, 44, 44, '', '2012-03-11 11:48:26', '2012-03-11 11:48:26', '2012-03-11 11:57:20', 3, '1970-01-01 12:48:26'),
(28, 44, 50, '', '2012-03-29 09:20:32', '2012-03-29 09:20:32', NULL, 2, '1970-01-01 11:20:32'),
(29, 44, 52, '', '2012-04-11 20:00:58', '2012-04-11 20:00:58', NULL, 2, '1970-01-01 22:00:58');

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_order_products`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_order_products` (
  `dfi_order_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_order_id` int(11) DEFAULT NULL,
  `dfi_product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`dfi_order_product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=76 ;

--
-- Truncate table before insert `jos_dfi_order_products`
--

TRUNCATE TABLE `jos_dfi_order_products`;
--
-- Dumping data for table `jos_dfi_order_products`
--

INSERT INTO `jos_dfi_order_products` (`dfi_order_product_id`, `dfi_order_id`, `dfi_product_id`, `quantity`) VALUES
(1, 1, 1, 24),
(2, 2, 1, 2400),
(3, 3, 1, 100),
(4, 3, 3, 0),
(5, 4, 13, 25),
(6, 4, 14, 26),
(7, 4, 15, 27),
(8, 4, 12, 28),
(9, 4, 9, 29),
(10, 4, 10, 30),
(11, 4, 11, 31),
(12, 4, 8, 50),
(13, 5, 16, 125),
(14, 7, 28, 125),
(15, 7, 29, 250),
(16, 8, 1, 200),
(17, 9, 15, 0),
(18, 9, 13, 0),
(19, 10, 15, 300),
(20, 10, 13, 400),
(21, 11, 34, 125),
(22, 11, 32, 250),
(23, 11, 27, 500),
(24, 12, 31, 0),
(25, 12, 33, 500),
(26, 12, 35, 0),
(27, 12, 34, 0),
(28, 12, 32, 0),
(29, 12, 21, 400),
(30, 13, 27, 100),
(31, 13, 28, 200),
(32, 14, 32, 240),
(33, 14, 27, 70),
(34, 14, 28, 48),
(35, 15, 13, 16),
(36, 15, 14, 16),
(37, 15, 15, 16),
(38, 16, 36, 3000),
(39, 17, 40, 6),
(40, 17, 39, 6),
(41, 17, 41, 8),
(42, 17, 43, 4),
(43, 17, 44, 0),
(44, 17, 42, 8),
(45, 17, 38, 6),
(46, 17, 37, 12),
(47, 18, 45, 30),
(48, 18, 46, 60),
(49, 18, 47, 30),
(50, 18, 48, 200),
(51, 19, 34, 70),
(52, 20, 27, 250),
(53, 21, 45, 150),
(54, 21, 34, 70),
(55, 21, 40, 150),
(56, 21, 39, 150),
(57, 21, 41, 150),
(58, 21, 43, 150),
(59, 21, 44, 150),
(60, 21, 42, 15),
(61, 21, 38, 150),
(62, 21, 37, 150),
(63, 22, 49, 0),
(64, 23, 27, 0),
(65, 24, 27, 0),
(66, 25, 34, 1000),
(67, 26, 34, 999),
(68, 27, 28, 250),
(69, 28, 58, 106),
(70, 29, 21, 70),
(71, 29, 22, 70),
(72, 29, 26, 70),
(73, 29, 23, 70),
(74, 29, 24, 70),
(75, 29, 25, 70);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_order_product_folders`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_order_product_folders` (
  `dfi_order_product_folder_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_order_product_id` int(11) DEFAULT NULL,
  `dfi_campaign_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`dfi_order_product_folder_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_dfi_order_product_folders`
--

TRUNCATE TABLE `jos_dfi_order_product_folders`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_order_statuses`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_order_statuses` (
  `dfi_order_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  PRIMARY KEY (`dfi_order_status_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Truncate table before insert `jos_dfi_order_statuses`
--

TRUNCATE TABLE `jos_dfi_order_statuses`;
--
-- Dumping data for table `jos_dfi_order_statuses`
--

INSERT INTO `jos_dfi_order_statuses` (`dfi_order_status_id`, `name`, `ordering`) VALUES
(1, 'Ny', 1),
(2, 'Sendt tll Shop', 3),
(3, 'Sendt til Leverandør', 4);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_products`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_products` (
  `dfi_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_supplier_id` int(11) DEFAULT NULL,
  `ean_kode` varchar(255) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `package_quantity` varchar(255) DEFAULT NULL,
  `hvidpris` float DEFAULT '0',
  `rodpris` float DEFAULT '0',
  `sortimentsnetto` float DEFAULT '0',
  `nettopris` float DEFAULT '0',
  `nupris` float DEFAULT '0',
  `wee` float NOT NULL DEFAULT '0',
  `range` tinyint(1) DEFAULT '1',
  `forced_distribution` tinyint(4) NOT NULL DEFAULT '0',
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`dfi_product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- Truncate table before insert `jos_dfi_products`
--

TRUNCATE TABLE `jos_dfi_products`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_reports`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_reports` (
  `dfi_report_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_shop_id` int(11) DEFAULT NULL,
  `dfi_product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`dfi_report_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_dfi_reports`
--

TRUNCATE TABLE `jos_dfi_reports`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_review_products`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_review_products` (
  `dfi_review_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `dfi_product_id` int(11) DEFAULT NULL,
  `dfi_campaign_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`dfi_review_product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_dfi_review_products`
--

TRUNCATE TABLE `jos_dfi_review_products`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_shops`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_shops` (
  `dfi_shop_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `street` text,
  `telephone` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `butiksnr` varchar(100) DEFAULT '0',
  `published` tinyint(1) DEFAULT '1',
  `filename` varchar(255) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `description` text,
  `open_hour` text,
  `rate` float DEFAULT NULL,
  `dfi_shops_catid` int(11) NOT NULL,
  PRIMARY KEY (`dfi_shop_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=162 ;

--
-- Truncate table before insert `jos_dfi_shops`
--

TRUNCATE TABLE `jos_dfi_shops`;
--
-- Dumping data for table `jos_dfi_shops`
--

INSERT INTO `jos_dfi_shops` (`dfi_shop_id`, `company_name`, `zipcode`, `city`, `street`, `telephone`, `fax`, `website`, `email`, `butiksnr`, `published`, `filename`, `ordering`, `description`, `open_hour`, `rate`, `dfi_shops_catid`) VALUES
(51, 'N.J. AUTO', '', '', 'dsdasdsadasdsadsadsadsadasd', '65 92 02 54', 'http://www.daekcenter.nu/5260.html', 'www.njauto.dk', 'http://www.daekcenter.nu/5260.html', 'http://www.degulesider.dk/de-gule-sider/Odense+S/14936463/NJ+Auto/', 1, 'images/rokquickcart/nj auto2.png', 1, 'Kratholmvej 39 <br />5260 Odense S', 'Mandag - torsdag: 7.30 - 16.00\r\nFredag: 7.30 - 13.30\r\n', 0, 12),
(159, 'Salling Autogenbrug', NULL, NULL, NULL, '97 59 63 33', 'http://daekcenter.nu/7870.html', 'www.sallingautogenbrug.dk/', 'http://daekcenter.nu/7870.html', 'http://www.degulesider.dk/97596333/s%C3%B8g.cs', 1, 'images/rokquickcart/salling.jpg', 107, 'Fjordvej 149<br />7870 Roslev', '', NULL, 106),
(54, 'BJ Biler', NULL, NULL, '  Hoegemosevaenget 6a\r\n\r\n8380 Trige           ', '86 23 18 13', 'http://www.daekcenter.nu/8380.html', 'www.bjbiler-automester.dk/', 'http://www.daekcenter.nu/8380.html', 'http://www.degulesider.dk/de-gule-sider/Trige/15005941/B+J+Biler/', 1, 'images/rokquickcart/bj biler3.png', 4, 'Hoegemosevaenget 6a<br />&nbsp;8380 Trige', 'Mandag - torsdag 7.45 - 16.30\r\nFredag 7.45 - 16.00', NULL, 17),
(55, '3S Biler', NULL, NULL, 'Elmegårdsvej 1\r\n9620 Aalestrup', '98 64 23 33', 'http://www.daekcenter.nu/9620.html', 'www.3s-biler.dk/', 'http://www.daekcenter.nu/9620.html', 'http://www.degulesider.dk/de-gule-sider/Aalestrup/14838781/3s-Biler+Aps/', 1, 'images/rokquickcart/3sbiler4.png', 5, 'Elmegårdsvej 1 <br />9620 Aalestrup', 'Mandag - torsdag: 8.00 - 16.30\r\n\r\nFredag: 8.00 - 14.45', NULL, 13),
(56, 'Heager Auto & Dæk', NULL, NULL, '       Heagervej 4\r\n6950 Ringkøbing       ', '23 31 15 06', 'http://www.daekcenter.nu/6950.html', 'www.heagerauto.dk', 'http://www.daekcenter.nu/6950.html', 'http://www.degulesider.dk/navne/-/23%2031%2015%2006/1/', 1, 'images/rokquickcart/heager4.png', 6, 'Heagervej 4 <br />6950 Ringkøbing', 'Mandag - torssdag: 8.00 - 17.00\r\n\r\nMandag - fredag: 8.00 - 16.00', NULL, 14),
(120, 'Autocenter Sydals', NULL, NULL, NULL, '74 40 48 66', 'http://www.daekcenter.nu/6400.html', 'www.autocentersydals.dk', 'http://www.daekcenter.nu/6400.html', 'http://www.krak.dk/f/autocenter-sydals-automester:67198824/6400-sønderborg?search_word=74404866', 1, 'images/rokquickcart/6400.png', 68, 'Kærvej 90<br />6400 Sønderborg', 'Mandag - Torsdag: 7.30 - 16.00\r\nFredag: 7.30 - 12.30', NULL, 72),
(57, 'Car Center Næstved', NULL, NULL, '      Manøvej 1\r\n4700 Næstved      ', '55 77 03 33', 'http://www.daekcenter.nu/4700.html', 'www.car-center.dk', 'http://www.daekcenter.nu/4700.html', 'http://www.degulesider.dk/navne/N%C3%A6stved/WP5014962925/Car-Center+ApS/', 1, 'images/rokquickcart/ccnstved.jpg', 7, 'Manøvej 1 <br />4700 Næstved', 'Mandag - torsdag: 8.00 - 17.00\r\nMandag - fredag: 8.00 - 16.00', NULL, 15),
(58, 'Hornbæk Auto', NULL, NULL, '        Viborgvej 164\r\n8920 Randers NV        ', '86 42 61 60', 'http://www.daekcenter.nu/8900.html', 'www.hornbaek-auto.dk/', 'http://www.daekcenter.nu/8900.html', 'http://www.degulesider.dk/navne/Randers+NV/WP5014986711/Hornb%C3%A6k+Auto/', 1, 'images/rokquickcart/hornbk4.png', 9, 'Viborgvej 164 <br />8920 Randers NV', 'Mandag - torsdag: 7.00 - 16.00\r\n\r\nFredag: 7.00 - 14.15', NULL, 7),
(59, 'Car Center Nykøbing', NULL, NULL, '      Randersvej 8\r\n4800 Nykøbing F.      ', '88 81 09 33', 'http://www.daekcenter.nu/4800.html', 'www.car-center.dk', 'http://www.daekcenter.nu/4800.html', 'http://www.degulesider.dk/de-gule-sider/Nyk%C3%B8bing+F/30807569/Car+Center/', 1, 'images/rokquickcart/carcenter nyk.png', 10, 'Randersvej 8<br />4800 Nykøbing F.', 'Mandag - torsdag 7.30 - 16.00\r\n\r\nFredag 7.30 - 14.15', NULL, 16),
(60, 'Thomsens Auto', NULL, NULL, '       Stationsvej 3\r\n5464 Brenderup     ', '35 12 53 42', 'http://www.daekcenter.nu/5464.html', 'www.thomsensauto.dk', 'http://www.daekcenter.nu/5464.html', 'http://www.degulesider.dk/navne/Brenderup+Fyn/WP5032491223/Thomsens+Autov%C3%A6rksted/', 1, 'images/rokquickcart/5464.png', 4, 'Rugårdsvej 198<br />5464 Brenderup', 'Mandag - torsdag: 7.30 - 16.00\r\nFredag: 7.30 - 13.30', NULL, 11),
(61, 'Center Auto', NULL, NULL, ' Nr. Bjertvej 164\r\n\r\n6000 Kolding ', '75 56 50 17', 'http://www.daekcenter.nu/6000.html', 'www.center-auto-kolding.dk', 'http://www.daekcenter.nu/6000.html', 'http://www.degulesider.dk/navne/Kolding/WP5014996732/Center+Auto/', 1, 'images/rokquickcart/centerauto2.jpg', 11, 'Nr. Bjertvej 64<br />6000 Kolding', 'Mandag - torsdag: 7.30 - 16.00\r\nFredag. 7.30 - 13.30', NULL, 8),
(63, 'Helsingør Bilcenter', NULL, NULL, NULL, '49 22 19 96', 'http://www.daekcenter.nu/3000.html', 'www.helsingoerbilcenter.dk/', 'http://www.daekcenter.nu/3000.html', 'http://www.degulesider.dk/de-gule-sider/Helsing%C3%B8r/14913049/Helsing%C3%B8r+Bilcenter/', 1, 'images/rokquickcart/helsingr.png', 13, 'Ole Rømers Vej 13<br /> 3000 Helsingør', 'Mandag - Torsdag: 7.30 - 15.30\r\nFredag: 7.30 - 15.00', NULL, 26),
(64, 'Taulov Bilværksted', NULL, NULL, NULL, '75 56 25 70', 'http://www.daekcenter.nu/6000.html', 'www.taulov-bilvaerksted.dk', 'http://www.daekcenter.nu/6000.html', 'http://www.degulesider.dk/de-gule-sider/Fredericia/15312398/Talov+Bilv%C3%A6rksted/', 1, 'images/rokquickcart/agent/shop-img.jpg', 14, 'Kolding Landevej 132<br /> 7000 Frederica', 'Mandag - torsdag: 7.30 - 16.00\r\nFredag. 7.30 - 13.30', NULL, 18),
(65, 'Bil Center Syd', NULL, NULL, NULL, '55 38 60 27', 'http://www.daekcenter.nu/4773.html', 'www.bilcentersyd.dk', 'http://www.daekcenter.nu/4773.html', 'http://www.degulesider.dk/de-gule-sider/Stensved/14865137/Bil+Center+Syd+A%2FS/', 1, 'images/rokquickcart/bilcentersyd2.png', 15, 'Vordingborgvej 19<br /> 4773 Stensved', 'Mandag - Fredag: 7.00 - 17.00', NULL, 21),
(146, 'Stevns Autoteknik', NULL, NULL, NULL, '61 80 40 50', 'http://daekcenter.nu/4672.html', '', 'http://daekcenter.nu/4672.html', 'http://www.degulesider.dk/61804050/s%C3%B8g.cs', 1, 'images/rokquickcart/stevns auto.jpg', 94, 'Gammel Køgevej 33a<br />4672 Klippinge', '', NULL, 96),
(147, 'CG Autoteknik', NULL, NULL, NULL, '40 47 27 46', 'http://daekcenter.nu/7700.html', 'www.cg-autoteknik.dk/', 'http://daekcenter.nu/7700.html', 'http://www.degulesider.dk/40472746/s%C3%B8g.cs', 1, 'images/rokquickcart/thisted.jpg', 95, 'Brundvej 22<br />7700 Thisted', '', NULL, 60),
(90, 'Æ´altmuligmanden', NULL, NULL, NULL, '40 10 53 08', 'http://www.daekcenter.nu/6500.html', '', 'http://www.daekcenter.nu/6500.html', 'http://www.degulesider.dk/navne/Vojens/WP2000403/Aage+Hoffensitz+Dittfeld/', 1, 'images/rokquickcart/alt4.jpg', 39, 'Over Jerstalvej 64<br />6500 Vojens', 'Efter aftale', NULL, 44),
(144, 'Suldrup Auto', NULL, NULL, NULL, '98 37 81 09', 'http://daekcenter.nu/9541.html', 'www.suldrupauto.dk', 'http://daekcenter.nu/9541.html', 'http://www.degulesider.dk/firma/suldrup-auto-hella-service-partner:15394093/9541-suldrup?search_word', 1, 'images/rokquickcart/suldrup.png', 92, 'Hjedsbækvej 282<br />9541 Suldrup', 'Mandag - torsdag: 7.30 - 16.30\r\nFredag: 7.30 - 13.00', NULL, 94),
(68, 'Lavpris-Dæk', NULL, NULL, NULL, '32 188 188', 'http://www.daekcenter.nu/4160.html', 'www.lavpris-daek.dk/', 'http://www.daekcenter.nu/4160.html', 'http://www.krak.dk/f/lavpris-dæk:99704145/4160-herlufmagle?search_word=32188188', 1, 'images/rokquickcart/lavprisdk.jpg', 18, 'Spragelsevej 11<br />4160 Herlufmagle', 'Mandag - Fredag: 8.00 - 16.00', NULL, 22),
(69, 'Brudlykkes Biler', NULL, NULL, NULL, '20 46 56 46', 'http://www.daekcenter.nu/brudlykke.html', 'www.brudlykkesbiler.dk', 'http://www.daekcenter.nu/brudlykke.html', 'http://www.degulesider.dk/navne/N%C3%A6stved/WP5032304921/Brudlykke+Biler/', 1, 'images/rokquickcart/brudlykkes.jpg', 19, 'Sorøvej 524<br /> 4700 Næstved', 'Mandag - Fredag: 8.00 - 17.00', NULL, 24),
(137, 'Nordsjællands Bilhus', NULL, NULL, NULL, '45 76 87 98', 'http://daekcenter.nu/2970.html', 'www.nordsjaellands-bilhus.dk', 'http://daekcenter.nu/2970.html', 'http://www.degulesider.dk/firma/nordsjællands-bilhus-as:32440601/2970-hørsholm?search_word=45768798', 1, 'images/rokquickcart/nordsjllands bilhus.png', 85, 'Hammervej 4<br />2970 Hørsholm', 'Mandag - Torsdag: 7.45 - 15.45\r\nFredag: 7.45 - 15.15', NULL, 87),
(72, 'BN Auto', NULL, NULL, NULL, '70 25 01 95', 'http://www.daekcenter.nu/4243.html', 'www.bnauto.dk/', 'http://www.daekcenter.nu/4243.html', 'http://www.degulesider.dk/de-gule-sider/Rude/15031085/B.N.+Auto+%26+Service+A%2FS/', 1, 'images/rokquickcart/bnauto.jpg', 22, 'Holsteinborgvej 2<br />4243 Rude', 'Mandag - Fredag: 8.00 - 16.00', NULL, 27),
(122, 'MH Autoservice', NULL, NULL, NULL, '28 71 76 04', 'http://daekcenter.nu/4750.html', 'www.mhautoservice.dk ', 'http://daekcenter.nu/4750.html', 'http://www.degulesider.dk/firma/mh-autoservice:30613524/4750-lundby?search_word=28717604', 1, 'images/rokquickcart/mh auto.png', 70, 'Kostræde Byvej 35<br />4750 Lundby', 'Mandag - Torsdag: 8.00 - 17.00\r\nFredag: 8.00 - 14.00', NULL, 75),
(145, 'Finderup Autservice', NULL, NULL, NULL, '97 36 19 20', 'http://www.daekcenter.nu/finderup.html', 'www.bentbil.dk', 'http://www.daekcenter.nu/finderup.html', 'http://www.degulesider.dk/firma/finderup-autoservice-bents-auto:13814707/6900-skjern?search_word=973', 1, 'images/rokquickcart/finderup.png', 93, 'Skjernvej 1<br />6900 Skjern', 'Mandag - torsdag: 8.00 - 16.30\r\nFredag: 8.00 - 13.30', NULL, 95),
(98, 'AutoXtra', NULL, NULL, NULL, '75 76 10 06', 'http://www.daekcenter.nu/8766.html', 'www.autoxtra.dk', 'http://www.daekcenter.nu/8766.html', 'http://www.degulesider.dk/firma/ns-udlejning:31250572/8766-n%C3%B8rre-snede?search_word=75761006', 1, 'images/rokquickcart/autoxtra1.png', 47, 'Mågevej 8<br />8766 Nørre-Snede', 'Mandag - torsdag: 7.30 - 17.00\r\nFredag: 7.30 - 14.00', NULL, 51),
(76, 'Verins auto', NULL, NULL, NULL, '59 22 78 58', 'http://www.daekcenter.nu/4500.html', 'www.verinsauto.dk', 'http://www.daekcenter.nu/4500.html', 'http://www.degulesider.dk/navne/Nyk%C3%B8bing+Sj/WP1815442865/Christian+Verin/', 1, 'images/rokquickcart/verins.png', 25, 'Rørvigvej 42-44<br />4500 Nykøbing Sjælland', 'Mandag - Torsdag: 7.30 - 16.00\r\nFredag 7.30 - 12.00', NULL, 31),
(77, 'Steen Andersen Biler', NULL, NULL, NULL, '43 43 08 10', 'http://www.daekcenter.nu/2605.html', 'www.steenandersenbiler.dk/', 'http://www.daekcenter.nu/2605.html', 'http://www.degulesider.dk/navne/Br%C3%B8ndby/WP5014895113/Steen+Andersen+Biler+ApS/', 1, 'images/rokquickcart/steena.png', 26, 'Sandager 10<br />2605 Brøndby', 'Mandag - Fredag: 8.00 - 16.00', NULL, 32),
(78, 'Boll og Søn', NULL, NULL, NULL, '59 51 30 63', 'http://www.daekcenter.nu/4400.html', 'www.bollogsøn.dk', 'http://www.daekcenter.nu/4400.html', 'http://www.degulesider.dk/de-gule-sider/Kalundborg/15898121/Fiat+Kalundborg+%28Boll%26S%C3%B8n%29/', 1, 'images/rokquickcart/boll2.jpg', 27, 'Elmegade 27<br />4400 Kalundborg', 'Mandag - Torsdag: 7.30 - 16.00\r\nFredag: 7.30 - 14.00', NULL, 33),
(79, 'Toftegaard Biler', NULL, NULL, NULL, '59 440 540', 'http://www.daekcenter.nu/4300.html', 'www.toftegaardbiler.dk', 'http://www.daekcenter.nu/4300.html', 'http://www.degulesider.dk/de-gule-sider/Holb%C3%A6k/15861671/Toftegaard+Biler+ApS/', 1, 'images/rokquickcart/toftegaard2.jpg', 28, 'Hjulmagervej 3B<br />4300 Holbæk', 'Mandag - Torsdag: 8.00 - 16.00\r\nFredag: 8.00 - 15.30', NULL, 34),
(80, 'FJ Biler Kolding', NULL, NULL, NULL, '75 50 93 83', 'http://www.daekcenter.nu/fjbiler.html', 'www.fjbilerkolding.dk/', 'http://www.daekcenter.nu/fjbiler.html', 'http://www.degulesider.dk/de-gule-sider/Kolding/14996709/FJ+Biler+Kolding+A%2FS/', 1, 'images/rokquickcart/fj4.jpg', 29, 'Vonsildvej 23<br />6000 Kolding', '', NULL, 8),
(158, 'J. Sühler Nakskov', NULL, NULL, NULL, '54 92 40 20', 'http://daekcenter.nu/4900.html', 'www.suhler.dk/', 'http://daekcenter.nu/4900.html', 'http://www.degulesider.dk/f/j-sühler-nakskov:66891646/4900-nakskov?search_word=54924020', 1, 'images/rokquickcart/4900.jpg', 106, 'Rjukanvej 1<br />4900 Nakskov', '', NULL, 105),
(82, 'LS Autoteknik', NULL, NULL, NULL, '20 97 89 60', 'http://www.daekcenter.nu/7800.html', 'www.lsautoteknik.dk/', 'http://www.daekcenter.nu/7800.html', 'http://www.degulesider.dk/de-gule-sider/Skive/32403447/Din+Bilpartner+Skive/', 1, 'images/rokquickcart/lsa.png', 31, 'Ulvevej 9c<br />7800 Skive', 'Mandag - Torsdag: 7.30 - 16.30\r\nFredag: 7.30 - 15.00', NULL, 36),
(83, 'Kaas Biler', NULL, NULL, NULL, '98 24 50 87', 'http://www.daekcenter.nu/9490.html', 'www.kaas-biler.dk/', 'http://www.daekcenter.nu/9490.html', 'http://www.degulesider.dk/de-gule-sider/Pandrup/14837175/Kaas+Biler+I%2FS/', 1, 'images/rokquickcart/kaas4.png', 32, 'Brogårdsgade 10<br />9490 Pandrup', 'Mandag - Torsdag: 8.00 - 16.00\r\nFredag: 8.00 - 15.30', NULL, 37),
(85, 'Arnes Auto', NULL, NULL, NULL, '25 53 18 53', 'http://www.daekcenter.nu/4220.html', 'www.arnesauto.dk/', 'http://www.daekcenter.nu/4220.html', 'http://www.degulesider.dk/mapdetailssearch.ds?id=32481188', 1, 'images/rokquickcart/arne.png', 34, 'Reskavej 4D<br />4220 Korsør', 'Mandag - Fredag: 8.00 - 15.00', NULL, 39),
(86, 'Kurt Clausen Biler', NULL, NULL, NULL, '74 83 32 18', 'http://www.daekcenter.nu/6534.html', 'www.kurtclausenbiler.dk/', 'http://www.daekcenter.nu/6534.html', 'http://www.degulesider.dk/de-gule-sider/Agerskov/14857547/Agerskov+Auto-Service/', 1, 'images/rokquickcart/kurtclau4.jpg', 35, 'Hovedgaden 58<br />6534 Agerskov', 'Mandag - Torsdag: 7.30 - 16.00\r\nFredag: 7.30 - 15.30', NULL, 40),
(87, 'Præstø Autoforum', NULL, NULL, NULL, '55 99 15 90', 'http://www.daekcenter.nu/4720.html', 'www.præstøautoforum.dk/', 'http://www.daekcenter.nu/4720.html', 'http://www.degulesider.dk/navne/Pr%C3%A6st%C3%B8/WP17013836/Pr%C3%A6st%C3%B8+Autoforum+ApS/', 1, 'images/rokquickcart/prst2.jpg', 36, 'Rosagervej 15a<br />4720 Præstø', 'Mandag - Fredag: 7.30 - 15.30', NULL, 42),
(88, 'Autohjørnet Vordingborg', NULL, NULL, NULL, '55 34 03 00', 'http://www.daekcenter.nu/4760.html', 'www.autohjornet-vordingborg.dk/', 'http://www.daekcenter.nu/4760.html', 'http://www.degulesider.dk/de-gule-sider/Vordingborg/14865165/Autohj%C3%B8rnet+Vordingborg/', 1, 'images/rokquickcart/autohjrner2.jpg', 37, 'Hovedakslen 1<br />4760 Vordingborg', 'Mandag - Torsdag: 7.30 - 15.30\r\nFredag: 7.30 - 15.00', NULL, 41),
(91, 'Michael´s Auto Service', NULL, NULL, NULL, '74 52 36 37', 'http://www.daekcenter.nu/6100.html', 'www.michaels-autoservice.dk/', 'http://www.daekcenter.nu/6100.html', 'http://www.degulesider.dk/navne/Haderslev/WP17056591/Michaels+Autoservice/', 1, 'images/rokquickcart/michaelauto4.jpg', 40, 'Louisevej 61<br />6100 Hadserlev', 'Mandag - Torsdag: 8.00 - 16.15\r\nFredag: 8.00 - 14.30', NULL, 45),
(148, 'Hjørring Autoservice', NULL, NULL, NULL, '53 25 35 54', 'http://daekcenter.nu/9800.html', 'www.hjoerringautoservice.dk/', 'http://daekcenter.nu/9800.html', 'http://www.degulesider.dk/53253554/s%C3%B8g.cs', 1, 'images/rokquickcart/hjrring.jpg', 96, 'Grønnevold 6<br />9800 Hjørring', '', NULL, 97),
(94, 'P.A.M. Service', NULL, NULL, NULL, '54772244', 'http://www.daekcenter.nu/4990.html', 'www.pamservice.dk', 'http://www.daekcenter.nu/4990.html', 'http://www.degulesider.dk/de-gule-sider/-/q_54772244/1/', 1, 'images/rokquickcart/pam2.jpg', 43, 'Tårsvej 13<br />4990 Sakskøbing', '', NULL, 48),
(95, 'Sadderup Dæk og Auto', NULL, NULL, NULL, '52 23 02 02', 'http://www.daekcenter.nu/6705.html', 'www.sdoa.dk/index.php', 'http://www.daekcenter.nu/6705.html', 'http://www.degulesider.dk/firma/sadderup-d%C3%A6k-auto:32923171/6705-esbjerg-%C3%B8?search_word=5223', 1, 'images/rokquickcart/sadderup4.jpg', 44, 'Sadderupvej 38<br />6705 Esjberg Ø', 'Mandag - Torsdag: 7.30 - 17.00\r\nFredag: 7.30 - 15.00', NULL, 49),
(96, 'Allan Madsen ApS', NULL, NULL, NULL, '74542463', 'http://www.daekcenter.nu/74542463.html', 'www.dinitrolvojens.dk/', 'http://www.daekcenter.nu/74542463.html', 'http://www.degulesider.dk/firma/dinitrol-og-d%C3%A6kcenter-vojens:15946829/6500-vojens?search_word=7', 1, 'images/rokquickcart/allan4.jpg', 45, 'Tinglykke 5<br />6500 Vojens', '', NULL, 44),
(97, 'Steen Auto', NULL, NULL, NULL, '98800032', 'http://www.daekcenter.nu/9700.html', 'www.steensauto.com', 'http://www.daekcenter.nu/9700.html', 'http://www.degulesider.dk/firma/steens-auto:15020366/9700-br%C3%B8nderslev?search_word=98800032', 1, 'images/rokquickcart/steensauto4.png', 46, 'Saltumvej 2<br />9700 Brønderslev', '', NULL, 50),
(99, 'AB Autoservice ApS', NULL, NULL, NULL, '42 30 18 44', 'http://www.daekcenter.nu/6940.html', 'www.ab-autoservice.dk/', 'http://www.daekcenter.nu/6940.html', 'http://www.degulesider.dk/firma/ab-autoservice-aps:30814676/6940-lem-st?search_word=42301844', 1, 'images/rokquickcart/abauto4.png', 48, 'Nylandsvej 12<br />6940 Lem', 'Mandag-Torsdag: 7.00 - 16.30\r\nFredag: 7.00 - 14.00', NULL, 52),
(100, 'MJ Autocentrum', NULL, NULL, NULL, '64 81 11 81', 'http://www.daekcenter.nu/5400.html', 'www.mj-autocentrum.dk/', 'http://www.daekcenter.nu/5400.html', 'http://www.degulesider.dk/firma/mj-autocentrum:30833527/5400-bogense?search_word=64811181', 1, 'images/rokquickcart/mjauto4.jpg', 49, 'Jyllandsvej 1<br />5400 Bogense', 'Mandag - Torsdag: 7.30 - 16.00\r\nFredag: 7.30 - 14.15', NULL, 53),
(101, 'Q-auto', NULL, NULL, NULL, '26 13 89 95', 'http://www.daekcenter.nu/qauto.html', 'www.facebook.com/pages/Q-auto/481820358539297', 'http://www.daekcenter.nu/qauto.html', 'http://www.degulesider.dk/firma/q-auto-voday-qazo:33057323/4684-holmegaard?search_word=26138995', 1, 'images/rokquickcart/qauto.png', 50, 'Glasmagervej 20B<br />4684 Holmegaard', '', NULL, 54),
(102, 'Hyllinge Auto', NULL, NULL, NULL, '55 44 40 16', 'http://www.daekcenter.nu/hyllinge.html', 'www.hyllingeauto.dk/', 'http://www.daekcenter.nu/hyllinge.html', 'http://www.degulesider.dk/firma/hyllinge-auto:17026310/4700-n%C3%A6stved?search_word=55444016', 1, 'images/rokquickcart/hyllinge.jpg', 51, 'Søndergade 27<br />Hyllinge<br />4700 Næstved', 'Mandag - Torsdag: 7.30 - 16.30\r\nFredag: 7.30 - 15.00', NULL, 15),
(161, 'Køge Dækcenter', NULL, NULL, NULL, '31 18 46 86', 'http://daekcenter.nu/4600.html', 'www.koegedaekcenter.dk/', 'http://daekcenter.nu/4600.html', 'http://www.degulesider.dk/31184686/s%C3%B8g.cs', 1, 'images/rokquickcart/kge2.jpg', 109, 'Tangmosevej 97<br />4600 Køge', '', NULL, 108),
(157, 'CiPe:Care', NULL, NULL, NULL, '66 19 39 00', 'http://daekcenter.nu/5700.html', 'www.cipecare.dk/', 'http://daekcenter.nu/5700.html', 'http://www.degulesider.dk/f/cipecare-lh-bilcenter-aps:66672466/5700-svendborg?search_word=66193901', 1, 'images/rokquickcart/cipecare2.jpg', 105, 'Grønnemosevej 20<br />5700 Svendborg', '', NULL, 104),
(104, 'IB´s Auto', NULL, NULL, NULL, '97 14 48 72', 'http://www.daekcenter.nu/7400.html', 'www.ibsauto.dk', 'http://www.daekcenter.nu/7400.html', 'http://www.degulesider.dk/firma/ibs-auto:15025356/7400-herning?search_word=97144872', 1, 'images/rokquickcart/ibsauto.png', 53, 'Gudumkærvej 11<br />7400 Herning', 'Mandag - Torsdag: 7.30 - 16.00\r\nFredag: 7.30 - 14.00', NULL, 56),
(105, 'VPST', NULL, NULL, NULL, '40 53 61 08', 'http://daekcenter.nu/9640.html', 'www.vpst.dk/', 'http://daekcenter.nu/9640.html', 'http://www.degulesider.dk/firma/veteran-pladesmeden-og-teknik:15905812/9640-fars%C3%B8?search_word=4', 1, 'images/rokquickcart/dklogo.png', 54, 'Ebbesøvej 8, Fandrup<br />9640 Farsø', '', NULL, 57),
(142, 'Borgmester Biler', NULL, NULL, NULL, '56 91 00 80', 'http://daekcenter.nu/3700.html', 'www.borgmesterbiler.dk', 'http://daekcenter.nu/3700.html', 'http://www.degulesider.dk/firma/borgmesterbiler:31323503/3700-rønne?search_word=56910080', 1, 'images/rokquickcart/borgmester biler.png', 90, 'Borgmester Nielsensvej 126<br />3700 Rønne', 'Mandag - Torsdag: 8.00 - 16.30\r\nFredag: 8.00 - 13.30', NULL, 92),
(143, 'Videbæk Autoteknik', NULL, NULL, NULL, '72 17 01 69', 'http://daekcenter.nu/6920.html', '', 'http://daekcenter.nu/6920.html', 'http://www.degulesider.dk/firma/videbæk-autoteknik-as:33129815/6920-videbæk?search_word=videb%C3%A6k', 1, 'images/rokquickcart/videbk.png', 91, 'Brogårdsvej 18<br />6920 Videbæk', '', NULL, 93),
(151, 'JP Auto Aps', NULL, NULL, NULL, '48 22 17 11', 'http://daekcenter.nu/4622.html', 'www.3liter.dk/', 'http://daekcenter.nu/4622.html', 'http://www.degulesider.dk/48221711/s%C3%B8g.cs', 1, 'images/rokquickcart/jp auto.jpg', 99, 'Salbjergvej 12<br />4622 Havdrup', '', NULL, 99),
(152, 'Jakobsen Service', NULL, NULL, NULL, '20 71 64 48', 'http://daekcenter.nu/4640.html', 'www.jakobsen-service.dk/', 'http://daekcenter.nu/4640.html', 'http://www.degulesider.dk/20716448/s%C3%B8g.cs', 1, 'images/rokquickcart/jakobsen.jpg', 100, 'Nygade 3<br />4640 Faxe', 'Mandag - Onsdag: 7.30 - 16.00\r\nTorsdag: 7.30 - 20.00\r\nFredag: 7.30 - 14.00', NULL, 101),
(109, 'MC Auto', NULL, NULL, NULL, '26 80 34 39', 'http://daekcenter.nu/26803439.html', 'www.mc-auto.eu/', 'http://daekcenter.nu/26803439.html', 'http://www.degulesider.dk/firma/mc-auto:15336265/4220-kors%C3%B8r', 1, 'images/rokquickcart/mc auto.png', 58, 'Tjærebyvej 94<br />Tjæreby<br />4220 Korsør', 'Mandag - Fredag: 7.30 - 16.00', NULL, 62),
(110, 'Det lille værksted', NULL, NULL, NULL, '22 82 92 08', 'http://daekcenter.nu/4270.html', '', 'http://daekcenter.nu/4270.html', 'http://www.degulesider.dk/person/resultat/22829208', 1, 'images/rokquickcart/dklogo.png', 59, 'Bødkervænget 1<br />Sæby<br />4270 Høng', '', NULL, 61),
(111, 'Tønder Antirust og Bilpleje', NULL, NULL, NULL, '74 72 45 44', 'http://www.daekcenter.nu/6270.html', 'www.toender-antirust.dk', 'http://www.daekcenter.nu/6270.html', 'http://www.krak.dk/f/tønder-antirust-bilpleje:66415137/6270-tønder?search_word=74724544', 1, 'images/rokquickcart/dinetrol.png', 60, 'Fabriksvej 14<br />6270 Tønder', '', NULL, 63),
(113, 'Skovbjerg Autoværksted', NULL, NULL, NULL, '57 61 71 11', 'http://www.daekcenter.nu/4100.html', '', 'http://www.daekcenter.nu/4100.html', 'http://www.degulesider.dk/firma/skovbjerg-autoværksted:14968422/4100-ringsted?search_word=57617111', 1, 'images/rokquickcart/dklogo.png', 61, 'Roskildevej 115<br />4100 Ringsted', '', NULL, 65),
(114, 'Brdr. Thomsen Automobiler', NULL, NULL, NULL, '87 33 10 20', 'http://www.daekcenter.nu/8260.html', 'www.bta-viby.dk/', 'http://www.daekcenter.nu/8260.html', 'http://www.degulesider.dk/firma/brdr-thomsen-automobiler-as:15335815/8260-viby-j?search_word=8733102', 1, 'images/rokquickcart/brdr thomsen.png', 62, 'Jens Juuls Vej 11<br />8260 Viby J', 'Mandag - Torsdag: 7.45 - 16.15\r\nFredag: 7.45 - 14.30', NULL, 67),
(160, 'CiPe:Care Nyborg', NULL, NULL, NULL, '65 31 41 60', 'http://daekcenter.nu/5800.html', 'www.cipecare.dk/', 'http://daekcenter.nu/5800.html', 'http://www.degulesider.dk/f/cipecare-nyborg-aps:116722777/5800-nyborg?search_word=65314160', 1, 'images/rokquickcart/cipecare2.jpg', 108, 'Falstervej 14<br />5800 Nyborg', '', NULL, 107),
(150, 'Øsby Autoservice', NULL, NULL, NULL, '74 58 41 69', 'http://daekcenter.nu/6101.html', 'www.øsbyautoservice.dk/', 'http://daekcenter.nu/6101.html', 'http://www.degulesider.dk/74584169/s%C3%B8g.cs', 1, 'images/rokquickcart/sby.jpg', 98, 'Øsbygade 49<br />6100 Haderslev', '', NULL, 98),
(118, 'Midtbyens Auto', NULL, NULL, NULL, '97 72 26 86', 'http://daekcenter.nu/7900.html', 'www.midtbyens-auto.dk/', 'http://daekcenter.nu/7900.html', 'http://www.degulesider.dk/firma/midtbyens-auto:15025920/7900-nykøbing-m?search_word=97722686', 1, 'images/rokquickcart/midtbyen2.jpg', 66, 'Nygade 15<br />7900 Nykøbing Mors', 'Mandag - Torsdag: 7.30 - 17.00\r\nFredag: 7.30 - 15.00', NULL, 69),
(119, 'Søren Bang Automobiler', NULL, NULL, NULL, '86 62 41 44', 'http://daekcenter.nu/8800.html', 'www.bang-viborg.dk/', 'http://daekcenter.nu/8800.html', 'http://www.degulesider.dk/firma/citroën-specialist-v-søren-bang-automobiler-as:14823743/8800-viborg?', 1, 'images/rokquickcart/sren bang.png', 67, 'Gl. Skovevej 79<br />8800 Viborg', 'Mandag: 8.00 - 16.00\r\nTirsdag: 7.30 - 16.00\r\nOnsdag - Torsdag: 7.30 - 15.30\r\nFredag: 7.30 - 15.00', NULL, 70),
(121, 'HP Autoservice ApS', NULL, NULL, NULL, '74 41 57 32', 'http://www.daekcenter.nu/6470.html', 'www.hp-auto.dk', 'http://www.daekcenter.nu/6470.html', 'http://www.degulesider.dk/firma/hp-autoservice-aps-automester:32631818/6470-sydals?search_word=74415', 1, 'images/rokquickcart/6470.png', 69, '<p>Kallehave 18, Hørup<br />6470 Sydals</p>', 'Mandag - Torsdag: 7.30 - 16.00\r\nFredag: 7.30 - 15.00', NULL, 73),
(154, 'Fods Auto', NULL, NULL, NULL, '42 45 45 70', 'http://daekcenter.nu/6752.html', 'www.fodsauto.dk/', 'http://daekcenter.nu/6752.html', 'http://www.degulesider.dk/42454570/s%C3%B8g.cs', 1, 'images/rokquickcart/6752.jpg', 102, 'Borgergade 43<br />6752 Glejbjerg', '', NULL, 102),
(124, 'CWC AUTO', NULL, NULL, NULL, '62 24 40 04', 'http://daekcenter.nu/5762.html', 'www.cwc.dk', 'http://daekcenter.nu/5762.html', 'http://www.degulesider.dk/firma/cwc-auto:14933577/5762-vester-skerninge?search_word=62244004', 1, 'images/rokquickcart/cwc front2.jpg', 72, 'Sterrebyvej 51, Hundstrup<br />5762 V.Skerninge', 'Mandag - Torsdag: 8.00 - 16.30\r\nFredag: 8.00 - 15.30', NULL, 74),
(156, 'CiPe:Care - LH BIlcenter', NULL, NULL, NULL, '66 19 39 00', 'http://daekcenter.nu/Cipecare.html', 'www.cipecare.dk/', 'http://daekcenter.nu/Cipecare.html', 'http://www.degulesider.dk/f/lh-bilcenter-aps-odense:66647755/5000-odense-c?search_word=66193900', 1, 'images/rokquickcart/cipecare2.jpg', 104, 'Grønlandsgade 18<br />5000 Odense C', '', NULL, 12),
(126, 'Rene´s Autoopretning', NULL, NULL, NULL, '75 58 67 47', 'http://daekcenter.nu/6640.html', 'www.reneauto.dk/', 'http://daekcenter.nu/6640.html', 'http://www.degulesider.dk/firma/renes-autoopretning-automester:15022987/6640-lunderskov?search_word=', 1, 'images/rokquickcart/automester.png', 74, 'Gelballevej 6<br />6640 Lunderskov', '', NULL, 77),
(128, 'Müller Autotec', NULL, NULL, NULL, '29 26 97 91', 'http://daekcenter.nu/6392.html', 'www.muller-autotec.dk', 'http://daekcenter.nu/6392.html', 'http://firma.eniro.dk/f/müller-autotec:66880625/6392-bolderslev?search_word=29269791', 1, 'images/rokquickcart/6392.png', 76, 'Hellevad - Bovvej 10<br />6392 Bolderslev', '', NULL, 79),
(129, 'Horne´s Auto og Dækservice', NULL, NULL, NULL, '74 44 12 86', 'http://daekcenter.nu/6310.html', 'www.hornesauto.dk', 'http://daekcenter.nu/6310.html', 'http://www.degulesider.dk/firma/hornes-auto-og-dækservice:14954041/6310-broager?search_word=74441286', 1, 'images/rokquickcart/6310.png', 77, 'Ramsherred 3<br />6310 Broager', 'Mandag - Torsdag: 7.30 - 16.00\r\nFredag: 7.30 - 14.00', NULL, 80),
(131, 'Møns Auto', NULL, NULL, NULL, '55 81 56 06', 'http://daekcenter.nu/4780.html', 'http://www.moensauto.dk/', 'http://daekcenter.nu/4780.html', 'http://www.degulesider.dk/firma/møns-auto-aps:14860424/4780-stege?search_word=55815606', 1, 'images/rokquickcart/4780.png', 79, 'Kostervej 19<br />4780 Stege', 'Mandag - Fredag: 7.30 - 16.00', NULL, 82),
(132, 'Autohjørnet Lyngby', NULL, NULL, NULL, '45 87 35 12', 'http://daekcenter.nu/2800.html', 'www.autohjornet.dk/', 'http://daekcenter.nu/2800.html', 'http://www.degulesider.dk/firma/autohjørnet-værksted:15048219/2800-kgs-lyngby?search_word=45873512', 1, 'images/rokquickcart/2800.png', 80, 'Buddingevej 86<br />2800 Lygby', 'Mandag - Torsdag: 8.00 - 16.00\r\nFredag: 8.00 - 15.30', NULL, 81),
(133, 'Holst Automobiler', NULL, NULL, NULL, '39 67 78 88', 'http://daekcenter.nu/2860.html', 'www.holst-auto.dk', 'http://daekcenter.nu/2860.html', 'http://www.degulesider.dk/firma/holst-automobiler-gladsaxe-as:21326167/2860-søborg?search_word=39677', 1, 'images/rokquickcart/holst.png', 81, 'Gladsaxe Møllevej 2<br />2860 Søborg', 'Mandag - Torsdag: 7.45 - 16.00\r\nFredag: 7.45 - 14.15', NULL, 85),
(153, 'MH Bilpleje', NULL, NULL, NULL, '40 93 28 54', 'http://daekcenter.nu/3460.html', 'www.mhbilpleje.dk/', 'http://daekcenter.nu/3460.html', 'http://www.degulesider.dk/40932854/s%C3%B8g.cs', 1, 'images/rokquickcart/mh bilpleje.jpg', 101, 'Abildgårdsparken 3<br />3460 Birkerød', '', NULL, 55),
(149, 'Carmax', NULL, NULL, NULL, '20 28 01 72', 'http://daekcenter.nu/7401.html', 'www.carmaxherning.dk', 'http://daekcenter.nu/7401.html', 'https://www.google.dk/maps/place/D%C3%A6kcenter+Herning/@56.113672,8.973689,17z/data=!3m1!4b1!4m2!3m', 1, 'images/rokquickcart/carmax2.png', 97, 'Industriparken 21<br />7400 Herning', '', NULL, 56),
(136, 'HG Auto', NULL, NULL, NULL, '74 68 05 04', 'http://daekcenter.nu/6200.html', 'www.hg-auto.dk', 'http://daekcenter.nu/6200.html', 'http://www.degulesider.dk/firma/hg-autotransport:14709857/6200-aabenraa?search_word=hg+auto&geo_area', 1, 'images/rokquickcart/hg auto.png', 84, 'Kausager 8<br />6200 Aabenraa', 'Mandag - Torsdag: 7.30 - 17.00\r\nFredag: 7.30 - 15.00', NULL, 86),
(138, 'Multi Auto', NULL, NULL, NULL, '43 99 01 06', 'http://daekcenter.nu/2630.html', 'www.multi-auto.dk', 'http://daekcenter.nu/2630.html', 'http://www.degulesider.dk/firma/multi-auto-aps:14812158/2630-taastrup?search_word=43990106', 1, 'images/rokquickcart/multi auto.png', 86, 'Tåstrup Hovedgade 23<br />2630 Taastrup', '', NULL, 88),
(139, 'Alle´s Auto', NULL, NULL, NULL, '29 89 84 00', 'http://daekcenter.nu/7430.html', 'www.alles-auto.dk', 'http://daekcenter.nu/7430.html', 'http://www.degulesider.dk/firma/alle%C2%B4s-auto-vallan-vestergaard-westphal:33085512/7430-ikast?sea', 1, 'images/rokquickcart/7430.png', 87, 'Nygade 37B - ved banen<br />7430 Ikast', 'Mandag - Torsdag: 16.00 - 19.00\r\nFredag: 14.00 - 19.00\r\nLørdag: 10.00 - 14.00', NULL, 91),
(140, 'KH Automobiler', NULL, NULL, NULL, '97 35 00 88', 'http://daekcenter.nu/6900.html', 'www.khautomobiler.dk', 'http://daekcenter.nu/6900.html', 'http://www.degulesider.dk/firma/kh-automobiler-as:15005765/6900-skjern?search_word=97350088', 1, 'images/rokquickcart/6900.png', 88, 'Jægervej 2<br />6900 Skjern', 'Mandag - Torsdag: 7.30 - 16.00\r\nFredag: 8.00 - 13.30', NULL, 90),
(141, 'Nordjysk Diesel-Elektro', NULL, NULL, NULL, '98 12 09 11', 'http://daekcenter.nu/9000.html', 'www.bosch-aalborg.dk', 'http://daekcenter.nu/9000.html', 'http://www.degulesider.dk/firma/nordjysk-diesel-elektro-as:14834101/9000-aalborg?search_word=9812091', 1, 'images/rokquickcart/9000.png', 89, 'Hjulmagervej 38<br />9000 Aalborg', 'Mandag - Torsdag: 7.30 - 16.30\r\nFredag: 7.30 - 15.00', NULL, 89);

-- --------------------------------------------------------

--
-- Table structure for table `jos_dfi_suppliers`
--

CREATE TABLE IF NOT EXISTS `jos_dfi_suppliers` (
  `dfi_supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `postalcode` varchar(20) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `contact_1` varchar(255) DEFAULT NULL,
  `contact_2` varchar(255) DEFAULT NULL,
  `payment_terms` text,
  `kampagnevalutering` text,
  `julevalutering` text,
  `delivery_terms` text,
  `contact_3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dfi_supplier_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Truncate table before insert `jos_dfi_suppliers`
--

TRUNCATE TABLE `jos_dfi_suppliers`;
--
-- Dumping data for table `jos_dfi_suppliers`
--

INSERT INTO `jos_dfi_suppliers` (`dfi_supplier_id`, `name`, `telephone`, `fax`, `address`, `email`, `postalcode`, `city`, `contact_1`, `contact_2`, `payment_terms`, `kampagnevalutering`, `julevalutering`, `delivery_terms`, `contact_3`) VALUES
(1, 'Scanpan A/S', '87 74 14 00', '86 39 47 77 ', 'Industrivej 49', 'info@webhousedenmark.com', '8550', 'Ryomgaard', '2', 'test', '<p>30 dage netto</p>', '60 dage netto', '90 dage netto<br />', '<p>Franko ved kr. 2000,-</p>', ''),
(2, 'OBH Nordica A/S', '43 35 03 50', '43 35 03 55', 'Ole Lippmanns Vej 1', 'henrik@mywebcreations.dk', '2630', 'Taastrup', 'Ole Olsen', '', 'Løbende uge + 35 dage', '+ 4 uger', '', 'Franko v/kr. 1.500<br />V/Køb under kr. 1.500 gebyr kr. 50 (dog ekskl. reservedele &amp; tilbehør)', ''),
(3, 'MWC supplier', '23456', '655443', '', 'ngo.bieu@mwc.vn', '', '', '1', '1', 'Netto 30 dage', '', '', 'franko', NULL),
(4, 'F&H A/S', '89 28 13 13', '89 28 13 11', 'Gl. Skivevej 70', 'henrik@mywebcreations.dk ', '8800', 'Viborg', '', '', '<p>Løben uge + 35 dage netto</p>', '+ 8 uger', '<html />', '<html />', ''),
(5, 'Aida A/S', '87 49 09 00', '87 49 09 01', 'Grenåvej 635A ', '', '8541', 'Skødstrup', 'Martin Rosenvinge', '24 40 93 25', 'Lb.uge + 35 dage -1,5%', '+ 4 uger', '', 'Franko v/kr. 3.000,-. <br />Ved køb u/kr. 1.500,- gebyr kr. 75,-<br />Fra 1.8.2006: Alle fakturaer pålægges miljø- og fragtgebyr på 0,9%.<br />', 'mr@aida.dk'),
(6, 'Schou Company A/S', '76 93 93 93', '76 93 93 00', 'Industrivej 36', '', '6580', 'Vamdrup', '', '', 'Lb. uge + 28 dage netto.<br />', '+ 4 uger', '', 'Franko v/kr. 2.000. <br />Ved køb under kr. 2.000 tillægges fragt.<br />Ved kampagnekøb, franko kr. 1.000. <br />', NULL),
(7, 'Agimex A/S', '86 82 00 66', '86 82 81 82', 'Hagemannsvej 7', '', '8600', 'Silkeborg', '', '', '<p>Lb. uge + 28 dage -1,5%</p>', '', '', 'Franko v/kr. 1.500,-. Ved køb under kr. 500,- pålægges gebyr kr. 50,-.<br />', NULL),
(8, 'Albaline A/S', '36 78 80 83', '36 78 81 83', 'Avedøreholmen 84', '', '2650', 'Hvidovre', '', '', 'Lb.uge + 28 dage - 1,0%<br />', '', '', 'Franko v/kr. 2.000,-. Ved køb u/kr. 2.000,- gebyr kr. 100,-<br />', NULL),
(9, 'A-L Isenkram EN GROS A/S', '75 53 72 11', '75 52 25 38', 'Gl. Skivevej 70', '', '8800', 'Viborg', '', '', 'Lb. uge + 35 dage netto', '+ 4 uger', '', '1 ugentlig franko levering.<br />Hvis ordremængden er under kr. 1.500 tillægges der fragt kr. 95. Gælder ikke restordre.<br />Hasteordre ufranko.<br />', NULL),
(10, 'All Times Company A/S', '43 66 82 82', '43 66 82 81', 'Esplanaden 40', '', '1263', 'København K', '', '', 'Lb. uge + 28 dage -2%<br />', '', '', 'Franko v/kr. 1.500,-. Ved køb under kr. 1.500,- gebyr kr. 75,-.', NULL),
(11, 'Avenue A/S', '86 28 16 00', '86 28 12 22', 'Teglbækvej 12-14', '', '8361', 'Hasselager', '', '', 'Lb.uge + 28 dage -1,5%', '', '', 'Franko v/kr. 2000,-<br />', NULL),
(12, 'Uniross Batco Nordic ApS', '86 49 62 11', '86 49 62 17', 'Virkevangen 48', '', '8960', 'Randers SØ', '', '', 'Lb. uge + 35 dage netto', '+ 4 uger', '', 'Ordre under 500,- + moms pålægges et ekspeditionsgebyr på kr. 40,- + fragt. Ordre over kr. 1.500,- ekskl. moms og afg. leveres fragtfrit.<br />', NULL),
(13, 'Bodum (Scandinavien) A/S', '49 14 80 00', '49 18 18 44', 'Humlebæk Strandvej 21', '', '3050', 'Humlebæk', '', '', 'Lb. uge + 14 dage -1,5%', '', '', 'Franko v/kr. 1800,-<br />Gebyr kr. 100,- under kr. 1800,-', NULL),
(14, 'Brabantia International', '46 55 13 55', '46 55 18 20', 'Baldersbuen 15G 1.tv.', '', '2640', 'Hedehusene', '', '', 'Lb.uge + 28 dage -1,5%', '+ 4 uger', '', 'Franko v/kr. 2.500,00. Herunder tillægges kr. 250,00.<br />Kampagneordrer leveres franko.<br />', NULL),
(15, 'Brix Design A/S', '55 81 80 22', '55 81 80 50', 'Ved Havnen 8', '', '4780', 'Stege', '', '', 'Lb.uge + 28 dage netto', '', '', 'Ordrer o/kr. 1000,- - frit leveret<br />Odrer u/kr. 1000,- - fragt kr. 29,-', NULL),
(16, 'BSH Hvidevarer A/S', '44 89 80 80', '44 89 86 86', 'Telegrafvej 4', '', '2750', 'Ballerup', '', '', 'Lb.uge + 28 dage', '', '', '', NULL),
(17, 'AGK Nordic A/S', '87 45 07 00', '', 'Norddigesvej 2', '', '8240', 'Risskov', 'Martin Tønder Larsen', '87 45 07 16', 'Lb. uge + 56 dage', '', '', '', 'mtl@agknordic.dk'),
(19, 'Bovictus A/S', '86 60 25 30', '86 60 25 50', 'Hjarbækvej 65', '', '8831', 'Løgstrup', 'Finn Snedker', '22 69 22 23', 'Lb. uge 35 dage', '', '', 'Franko v/køb over kr. 2.500<br />V/køb under kr. 2.500 pålægges gebyr på kr. 100.-', 'fs@zonecompany.dk'),
(20, 'Elthermo Searchlight A/S', '36 72 22 00', '36 41 07 41', 'Højnæsvej 44', 'mail@elthermo.dk', '2610', 'Rødovre', 'Jan Olsen', '', 'Lb.uge + 35 dage', '', '', 'Franko. <br />Ved ordrer u/kr. 2.000,- pålægges gebyr og fragt kr. 140,-.<br />', ''),
(21, 'Hammarplast A/S', '46 38 09 10', '46 38 09 11', 'Ringstedvej 22 ', 'henrik@mywebcreations.dk ', '4000', 'Roskilde', 'Jan Pedersen', '28 98 69 63', '<html />', '<html />', '<html />', 'Franko ved kr. 6500,-', 'j.pedersen@hammarplast.se'),
(22, 'Nordic Living A/S', '49 14 79 25', '49 14 75 26', 'Møllevej 9', 'info@nordic-living.dk', '2990', 'Nivå', 'Morten Clausen', '26 30 00 03', 'Lb. uge + 63 dage<br />', '', '', 'Franko v/kr. 1000,-<br />V/køb under kr. 1000,- + kr. 90,- i fragt.<br />', 'morten@nordic-living.dk'),
(23, 'Rosendahl Design Group A/S', '45 88 66 33', '', 'Slotsmarken 1', 'info@rosendahl.dk', '2970', 'Hørsholm', 'Vivian Spiegelhauer', '45 17 38 34', 'Lb. uge 35 dage netto', '', '', 'Alle ordrer over "salg.rosendahl.dk" (Rosendahls Handelssystem) og kæde afgivne (kampagne) ordrer leveres franko i Danmark.<br />Alle ordrer afgivet pr. telefon, fax og mail leveres ab lager.<br />V/Køb under kr. 2.500 ekskl. moms uanset bestillingsmåde beregnes gebyr kr. 75,-<br />', 'vsp@rosendahl.dk'),
(24, 'Royal Copenhagen A/S', '38 14 48 48', '38 14 99 11', 'Smedeland 17', '', '2600', 'Glostrup', 'Jacob Engberg', '25 24 73 60', 'Lb. uge + 42 dage', '', '', 'Franko ved kr. 2.500. <br />Ved køb under kr. 2.500 + kr. 145', 'jae@royalcopenhagen.com'),
(25, 'Ørskov & Co. A/S', '49 19 49 49', '49 19 49 48', 'Bybjergvej 5', '', '3060', 'Espergærde', '', '', 'lb. uge + 28 dage', '', '', 'ab lager', ''),
(26, 'Adexi A/S', '87 41 71 01', '', 'Grenåvej 635A', 'info@webhousedenmark.com', '8541', 'Skødstrup', 'Rasmus Østergaard', '87 41 71 45', 'Lb.uge + 35 dage netto', '<html />', '<html />', 'Franko ved kr. 3.500,-. <br />Ordrer under kr. 3.500,- gebyr + fragt kr. 200,-.', ''),
(27, 'Eva Solo A/S', '36 73 20 73', '36 70 74 11', 'Måløv Teknikerby 18-20', '', '2760', 'Måløv', '', '', 'Lb.uge + 28 dage netto', '', '', 'Franko v/kr. 1.500,-. <br />Ordredag:<br />En fast ugedag, som aftales med Eva Denmark. Det er muligt at afgive hasteordrer, fra dag til dag, levering ufranko, dog + gebyr kr. 100,-.', ''),
(28, 'Melitta Skandinavia A/S', '46 35 30 00', '46 35 30 04', 'Skomagergade 13 1.', 'melitta@melitta.dk', '4000', 'Roskilde', 'Flemming Skytte', '23 60 56 57', 'Lb. uge + 42 dage', '', '', 'Franko v/kr. 1.500<br />V/Køb under kr. 1.500 fragt kr. 60<br />V/Køb under kr. 500 gebyr kr. 40 + fragt kr. 60', 'flemming.skytte@melitta.dk'),
(29, 'Dacore A/S', '58 11 14 00', '58 11 14 01', 'Hovedgaden 19', 'info@dacore.dk', '4261', 'Dalmose', 'Jan Kirk', '40 89 59 51', '', '', '', '', 'jk@dacore.dk'),
(30, 'Georg Jensen A/S', '38 14 98 98', '38 14 99 20', 'Søndre Fasanvej 7', '', '2000', 'Frederiksberg', '', '', 'Lb. uge + 28 dage', '', '', 'Franko v/kr. 2.500.-.<br />Hasteordrer + gebyr kr. 250.- incl. fragt hvis ordre er under kr. 2.500.-<br />Ved brud på colli + gebyr på +10%<br />Transportforsikring + 0,5% af fakturaværdi', ''),
(31, 'Stelton A/S', '39 62 23 55', '39 62 23 50', 'Christianshavns Kanal 4', 'stelton@stelton.dk', '1406', 'København K', '', '', 'Lb. uge 42 dage netto', '', '', 'Franko v/kr. 3.500<br />Restordrer altid gebyrfrit + franko<br />V/køb kr. 0-999,- + gebyr kr. 200,- incl. forsendelse.<br />V//køb kr. 1.000,- - 3.499,- + aktuel fragt', ''),
(32, 'Condor Danmark', '33 32 88 34', '33 32 88 35', 'Strandvejen 102 E 3.', 'info@webhousedenmark.com; jesper@dinisenkraemmer.dk', '2900', 'Hellerup', '', '', '', '', '', '', 'nguyen.cuong@mwc.vn'),
(33, 'Groupe SEB Danmark A/S', '44 66 31 55', '44 66 11 10', 'Tempovej 27', '', '2750', 'Ballerup', 'Jesper Nielsen', '', '', '', '', 'Test', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_groups`
--

CREATE TABLE IF NOT EXISTS `jos_groups` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_groups`
--

TRUNCATE TABLE `jos_groups`;
--
-- Dumping data for table `jos_groups`
--

INSERT INTO `jos_groups` (`id`, `name`) VALUES
(0, 'Public'),
(1, 'Registered'),
(2, 'Special');

-- --------------------------------------------------------

--
-- Table structure for table `jos_menu`
--

CREATE TABLE IF NOT EXISTS `jos_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text,
  `type` varchar(50) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `componentid` int(11) unsigned NOT NULL DEFAULT '0',
  `sublevel` int(11) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pollid` int(11) NOT NULL DEFAULT '0',
  `browserNav` tinyint(4) DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `utaccess` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `home` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `componentid` (`componentid`,`menutype`,`published`,`access`),
  KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Truncate table before insert `jos_menu`
--

TRUNCATE TABLE `jos_menu`;
--
-- Dumping data for table `jos_menu`
--

INSERT INTO `jos_menu` (`id`, `menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, `componentid`, `sublevel`, `ordering`, `checked_out`, `checked_out_time`, `pollid`, `browserNav`, `access`, `utaccess`, `params`, `lft`, `rgt`, `home`) VALUES
(1, 'mainmenu', 'Forside', 'forside', 'index.php?option=com_content&view=frontpage', 'component', -2, 0, 20, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'num_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\norderby_pri=\norderby_sec=front\nmulti_column_order=1\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(2, 'mainmenu', 'Om Os', 'om-os', 'index.php?option=com_omos&view=index', 'component', -2, 0, 77, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(3, 'mainmenu', 'Nyheder', 'nyheder', 'index.php?option=com_nyheder&view=index', 'component', -2, 0, 78, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(4, 'mainmenu', 'Kontakt Os', 'kontakt-os', 'index.php?option=com_contact&view=contact&id=1', 'component', -2, 0, 7, 0, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_contact_list=0\nshow_category_crumb=0\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(5, 'mainmenu', 'Tilbudsaviser', 'tilbudsaviser', 'index.php?option=com_content&view=category&id=7', 'component', -2, 0, 20, 0, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=10\nshow_headings=1\nshow_date=0\ndate_format=\nfilter=1\nfilter_type=title\norderby_sec=\nshow_pagination=1\nshow_pagination_limit=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(26, 'mainmenu', 'Danmarkskort', 'danmarkskort', 'index.php?option=com_content&view=frontpage', 'component', 1, 0, 20, 0, 8, 62, '2014-12-04 11:08:26', 0, 0, 0, 0, 'num_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\norderby_pri=\norderby_sec=front\nmulti_column_order=1\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 1),
(27, 'mainmenu', 'Afdelinger', 'afdelinger', 'index.php?option=com_content&view=category&layout=afdelinger&id=11', 'url', 1, 0, 0, 0, 9, 62, '2014-01-10 15:11:49', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(28, 'mainmenu', 'Bliv forhandler', 'bliv-forhandler', 'index.php?option=com_content&view=article&id=25', 'component', 1, 31, 20, 1, 8, 62, '2013-12-06 07:04:42', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(29, 'mainmenu', 'zzcxzczxczxc', 'zzcxzczxczxc', 'index.php?option=com_content&view=article&id=26', 'component', -2, 0, 20, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(30, 'mainmenu', 'sadasdsadasd', 'sadasdsadasd', 'index.php?option=com_content&view=article&id=26', 'component', -2, 0, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(31, 'mainmenu', 'DÆK- og FÆLG INFO', 'daek-og-faelg-info', 'index.php?option=com_content&view=article&id=37', 'component', 1, 0, 20, 0, 10, 62, '2014-01-10 14:35:03', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(32, 'mainmenu', 'Vinterdæk regler', 'vinterdaek-regler', 'index.php?option=com_content&view=article&id=30', 'component', 1, 31, 20, 1, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(33, 'mainmenu', 'Teknisk info – Dæk', 'teknisk-info-daek', 'index.php?option=com_content&view=article&id=37', 'component', 1, 31, 20, 1, 1, 62, '2014-01-10 14:54:19', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(34, 'mainmenu', 'Teknisk info – Fælge', 'teknisk-info-faelge', 'index.php?option=com_content&view=article&id=31', 'component', 1, 31, 20, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(35, 'mainmenu', 'Teknisk info – Hjul', 'teknisk-info-hjul', 'index.php?option=com_content&view=article&id=32', 'component', 1, 31, 20, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(36, 'mainmenu', 'Vedligeholdelsesguide dæk', 'vedligeholdelsesguide', 'index.php?option=com_content&view=article&id=33', 'component', 1, 31, 20, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(37, 'mainmenu', 'Udskiftning af dæk', 'udskiftning-af-daek', 'index.php?option=com_content&view=article&id=35', 'component', 1, 31, 20, 1, 6, 62, '2014-01-10 14:54:12', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(38, 'mainmenu', 'EU-mærkning af dæk', 'eu-maerkning-af-daek', 'index.php?option=com_content&view=article&id=34', 'component', 1, 31, 20, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(39, 'bestilmenu', 'bestil', 'bestil', 'http://www.daekcenter.nu/bestil.html', 'url', -2, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(40, 'mainmenu', 'FÅ KREDIT - RENTEFRIT', 'fa-kredit-rentefrit', 'index.php?option=com_content&view=article&id=42', 'component', 1, 0, 20, 0, 12, 62, '2015-03-23 15:24:12', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_menu_types`
--

CREATE TABLE IF NOT EXISTS `jos_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Truncate table before insert `jos_menu_types`
--

TRUNCATE TABLE `jos_menu_types`;
--
-- Dumping data for table `jos_menu_types`
--

INSERT INTO `jos_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site'),
(4, 'bestilmenu', 'bestil menu', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_messages`
--

CREATE TABLE IF NOT EXISTS `jos_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` int(10) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` int(11) NOT NULL DEFAULT '0',
  `priority` int(1) unsigned NOT NULL DEFAULT '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_messages`
--

TRUNCATE TABLE `jos_messages`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_messages_cfg`
--

CREATE TABLE IF NOT EXISTS `jos_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_messages_cfg`
--

TRUNCATE TABLE `jos_messages_cfg`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_migration_backlinks`
--

CREATE TABLE IF NOT EXISTS `jos_migration_backlinks` (
  `itemid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `sefurl` text NOT NULL,
  `newurl` text NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_migration_backlinks`
--

TRUNCATE TABLE `jos_migration_backlinks`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_modules`
--

CREATE TABLE IF NOT EXISTS `jos_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) DEFAULT NULL,
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `numnews` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `control` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Truncate table before insert `jos_modules`
--

TRUNCATE TABLE `jos_modules`;
--
-- Dumping data for table `jos_modules`
--

INSERT INTO `jos_modules` (`id`, `title`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `published`, `module`, `numnews`, `access`, `showtitle`, `params`, `iscore`, `client_id`, `control`) VALUES
(1, 'Main Menu', '', 0, 'menutop', 62, '2014-12-04 11:57:21', 1, 'mod_mainmenu', 0, 0, 1, 'menutype=mainmenu\nmenu_style=list\nstartLevel=0\nendLevel=10\nshowAllChildren=1\nwindow_open=\nshow_whitespace=0\ncache=1\ntag_id=mainNav\nclass_sfx=\nmoduleclass_sfx=\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 1, 0, ''),
(2, 'Login', '', 1, 'login', 0, '0000-00-00 00:00:00', 1, 'mod_login', 0, 0, 1, '', 1, 1, ''),
(3, 'Popular', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_popular', 0, 2, 1, '', 0, 1, ''),
(4, 'Recent added Articles', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_latest', 0, 2, 1, 'ordering=c_dsc\nuser_id=0\ncache=0\n\n', 0, 1, ''),
(5, 'Menu Stats', '', 5, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_stats', 0, 2, 1, '', 0, 1, ''),
(6, 'Unread Messages', '', 1, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_unread', 0, 2, 1, '', 1, 1, ''),
(7, 'Online Users', '', 2, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_online', 0, 2, 1, '', 1, 1, ''),
(8, 'Toolbar', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', 1, 'mod_toolbar', 0, 2, 1, '', 1, 1, ''),
(9, 'Quick Icons', '', 1, 'icon', 0, '0000-00-00 00:00:00', 1, 'mod_quickicon', 0, 2, 1, '', 1, 1, ''),
(10, 'Logged in Users', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_logged', 0, 2, 1, '', 0, 1, ''),
(11, 'Footer', '', 0, 'footer', 0, '0000-00-00 00:00:00', 1, 'mod_footer', 0, 0, 1, '', 1, 1, ''),
(12, 'Admin Menu', '', 1, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_menu', 0, 2, 1, '', 0, 1, ''),
(13, 'Admin SubMenu', '', 1, 'submenu', 0, '0000-00-00 00:00:00', 1, 'mod_submenu', 0, 2, 1, '', 0, 1, ''),
(14, 'User Status', '', 1, 'status', 0, '0000-00-00 00:00:00', 1, 'mod_status', 0, 2, 1, '', 0, 1, ''),
(15, 'Title', '', 1, 'title', 0, '0000-00-00 00:00:00', 1, 'mod_title', 0, 2, 1, '', 0, 1, ''),
(30, 'logo', '<ul class="brands-list">\r\n<li><a href="http://www.michelin.dk/" target="_blank"><img src="templates/daecenter/img/michelin.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.bridgestone.dk/" target="_blank"><img src="templates/daecenter/img/bridgestone.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.conti-online.com/" target="_blank"><img src="templates/daecenter/img/continential.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.nokiantyres.com/" target="_blank"><img src="templates/daecenter/img/nokiantyres.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.pirelli.com/" target="_blank"><img src="templates/daecenter/img/pirelli.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.goodyear.eu/" target="_blank"><img src="templates/daecenter/img/goodyear.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.kleber.dk/" target="_blank"><img src="templates/daecenter/img/kleber.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.maloya.ch" target="_blank"><img src="templates/daecenter/img/maloya.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.barum-online.com" target="_blank"><img src="templates/daecenter/img/barum.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.bfgoodrich.co.za" target="_blank"><img src="templates/daecenter/img/bfgoodrich.jpg" border="0" alt="" /></a></li>\r\n<li><a><img src="templates/daecenter/img/dayton.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.dunloptires.com" target="_blank"><img src="templates/daecenter/img/dunlop.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.falkentire.com" target="_blank"><img src="templates/daecenter/img/falken.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.federaltire.com" target="_blank"><img src="templates/daecenter/img/federal.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.firestone.com/" target="_blank"><img src="templates/daecenter/img/firestone.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.generaltire.com/" target="_blank"><img src="templates/daecenter/img/general.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.gislaved-tires.com" target="_blank"><img src="templates/daecenter/img/gislaved.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.hankooktire.com" target="_blank"><img src="templates/daecenter/img/hankook.jpg" border="0" alt="" /></a></li>\r\n<li><a><img src="templates/daecenter/img/kingstar.jpg" border="0" alt="" /></a></li>\r\n<li><a><img src="templates/daecenter/img/kormoran.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.kumhotire.com" target="_blank"><img src="templates/daecenter/img/kumho.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.maxxis.com" target="_blank"><img src="templates/daecenter/img/maxxis.jpg" border="0" alt="" /></a></li>\r\n<li><a><img src="templates/daecenter/img/novex.jpg" border="0" alt="" /></a></li>\r\n<li><a><img src="templates/daecenter/img/riken.jpg" border="0" alt="" /></a></li>\r\n<li><a><img src="templates/daecenter/img/rotex.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.sava-tires.com" target="_blank"><img src="templates/daecenter/img/sava.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.semperit.com" target="_blank"><img src="templates/daecenter/img/semperit.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.silverstonewheel.com/" target="_blank"><img src="templates/daecenter/img/silverstone.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.tigar.com/" target="_blank"><img src="templates/daecenter/img/tigar.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.toyotires.com/" target="_blank"><img src="templates/daecenter/img/toyo.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.triangletire.com" target="_blank"><img src="templates/daecenter/img/triangle.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.uniroyaltires.com" target="_blank"><img src="templates/daecenter/img/uniroyal.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.veerubber.co.th" target="_blank"><img src="templates/daecenter/img/veerubber.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.vredestein.com" target="_blank"><img src="templates/daecenter/img/vredestein.jpg" border="0" alt="" /></a></li>\r\n<li><a href="http://www.yokohamatire.com/" target="_blank"><img src="templates/daecenter/img/yokohama.jpg" border="0" /></a></li>\r\n</ul>', 0, 'left', 62, '2014-12-04 11:17:50', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(28, 'banner_left', '<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FDaekcenter&amp;width=180&amp;height=395&amp;colorscheme=light&amp;show_faces=false&amp;header=false&amp;stream=true&amp;show_border=false" scrolling="no" frameborder="0" style="border: currentColor; border-image: none; width: 180px; height: 395px; overflow: hidden;" allowtransparency="true" width="180" height="395"></iframe>', 0, 'left', 62, '2014-12-04 11:57:30', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(29, 'footer', '<div id="footer" class="w950">\r\n<p>Dækcenter.nu - Hele Danmarks dækcenter, alle dækmærker et sted - vælg din forhandler og se din pris - <a href="mailto:info@daekcenter.nu">info@daekcenter.nu</a></p>\r\n</div>', 0, 'left', 62, '2014-12-04 11:57:13', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(31, 'JCE File Browser', '', 100, 'icon', 0, '0000-00-00 00:00:00', 1, 'mod_jcefilebrowser', 0, 2, 1, '', 0, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_modules_menu`
--

CREATE TABLE IF NOT EXISTS `jos_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_modules_menu`
--

TRUNCATE TABLE `jos_modules_menu`;
--
-- Dumping data for table `jos_modules_menu`
--

INSERT INTO `jos_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(27, 0),
(28, 0),
(29, 0),
(30, 0),
(31, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_newsfeeds`
--

CREATE TABLE IF NOT EXISTS `jos_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(11) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(11) unsigned NOT NULL DEFAULT '3600',
  `checked_out` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `published` (`published`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_newsfeeds`
--

TRUNCATE TABLE `jos_newsfeeds`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_access_components`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_access_components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `component_usergroupid` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_pi_aua_access_components`
--

TRUNCATE TABLE `jos_pi_aua_access_components`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_access_pages`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_access_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pageid_usergroupid` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_pi_aua_access_pages`
--

TRUNCATE TABLE `jos_pi_aua_access_pages`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_actions`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_usergroupid` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_pi_aua_actions`
--

TRUNCATE TABLE `jos_pi_aua_actions`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_categories`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_groupid` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_pi_aua_categories`
--

TRUNCATE TABLE `jos_pi_aua_categories`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_config`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_config` (
  `id` varchar(255) NOT NULL,
  `config` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_pi_aua_config`
--

TRUNCATE TABLE `jos_pi_aua_config`;
--
-- Dumping data for table `jos_pi_aua_config`
--

INSERT INTO `jos_pi_aua_config` (`id`, `config`) VALUES
('aua', 'language=english\r\ndefault_tab=usergroups\r\nredirect_to_pi=false\r\nuse_toolbar=true\r\ndisplay_usergroups=true\r\ndisplay_users=true\r\ndefault_usergroup=\r\ndisplay_pagesaccess=true\r\nactive_pagesaccess=false\r\ninherit_rights_parent_page=true\r\ndisplay_itemtypes=true			\r\nactive_itemtypes=false\r\ndisplay_items=true\r\nactive_items=false			\r\ndisplay_itemtype_in_list=false			\r\ndisplay_sections=true\r\nactive_sections=false\r\ndisplay_categories=true\r\nactive_categories=false\r\ndisplay_actions=true\r\nactive_actions=false\r\ndisplay_components=true\r\ndisplay_toolbars=true\r\nshow_joomla_group=true\r\ndisable_joomla_group_selectbox=false\r\nitem_inherits_access=no_default_has_access	\r\ncom_content_access=category_access\r\nactivate_modules=false\r\ndisplay_modules=true\r\nactivate_plugins=false\r\ndisplay_plugins=true\r\nactivate_toolbars=false\r\ndisplay_toolbar_superadmin=true\r\npage_props=true	\r\nitem_props=true	\r\nmenutypes=mainmenu;Main Menu\r\ndropdown_buttons=2;media,4;community\r\nextra_buttons=			\r\nnotify_from_address=no-reply@pages-and-items.com\r\nnotify_from_name=	\r\nuse_componentaccess=false\r\ncomponents=com_poll;Polls;com_poll;0,com_pi_pages_and_items;Pages and Items;com_pi_pages_and_items;0,com_pi_admin_user_access;Admin User Access;com_pi_admin_user_access;0,com_banners;Banners;com_banners;2,com_media;Media Manager;com_media;2,com_trash;Trash manager;com_trash;0\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_items`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid_usergroupid` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_pi_aua_items`
--

TRUNCATE TABLE `jos_pi_aua_items`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_itemtypes`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_itemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_groupid` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_pi_aua_itemtypes`
--

TRUNCATE TABLE `jos_pi_aua_itemtypes`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_modules`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_groupid` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_pi_aua_modules`
--

TRUNCATE TABLE `jos_pi_aua_modules`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_plugins`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_groupid` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_pi_aua_plugins`
--

TRUNCATE TABLE `jos_pi_aua_plugins`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_sections`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_groupid` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_pi_aua_sections`
--

TRUNCATE TABLE `jos_pi_aua_sections`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_usergroups`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `email` text NOT NULL,
  `ua_toolbar` tinyint(1) NOT NULL DEFAULT '0',
  `j_toolbar` tinyint(1) NOT NULL DEFAULT '0',
  `extra` tinytext NOT NULL,
  `description` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Truncate table before insert `jos_pi_aua_usergroups`
--

TRUNCATE TABLE `jos_pi_aua_usergroups`;
--
-- Dumping data for table `jos_pi_aua_usergroups`
--

INSERT INTO `jos_pi_aua_usergroups` (`id`, `name`, `email`, `ua_toolbar`, `j_toolbar`, `extra`, `description`) VALUES
(1, 'test', 'a@a.a', 0, 0, '', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `jos_pi_aua_userindex`
--

CREATE TABLE IF NOT EXISTS `jos_pi_aua_userindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Truncate table before insert `jos_pi_aua_userindex`
--

TRUNCATE TABLE `jos_pi_aua_userindex`;
--
-- Dumping data for table `jos_pi_aua_userindex`
--

INSERT INTO `jos_pi_aua_userindex` (`id`, `user_id`, `group_id`) VALUES
(1, 69, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_plugins`
--

CREATE TABLE IF NOT EXISTS `jos_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `element` varchar(100) NOT NULL DEFAULT '',
  `folder` varchar(100) NOT NULL DEFAULT '',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `iscore` tinyint(3) NOT NULL DEFAULT '0',
  `client_id` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_folder` (`published`,`client_id`,`access`,`folder`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Truncate table before insert `jos_plugins`
--

TRUNCATE TABLE `jos_plugins`;
--
-- Dumping data for table `jos_plugins`
--

INSERT INTO `jos_plugins` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'Authentication - Joomla', 'joomla', 'authentication', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'Authentication - LDAP', 'ldap', 'authentication', 0, 2, 0, 1, 0, 0, '0000-00-00 00:00:00', 'host=\nport=389\nuse_ldapV3=0\nnegotiate_tls=0\nno_referrals=0\nauth_method=bind\nbase_dn=\nsearch_string=\nusers_dn=\nusername=\npassword=\nldap_fullname=fullName\nldap_email=mail\nldap_uid=uid\n\n'),
(3, 'Authentication - GMail', 'gmail', 'authentication', 0, 4, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(4, 'Authentication - OpenID', 'openid', 'authentication', 0, 3, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'User - Joomla!', 'joomla', 'user', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'autoregister=1\n\n'),
(6, 'Search - Content', 'content', 'search', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\nsearch_content=1\nsearch_uncategorised=1\nsearch_archived=1\n\n'),
(7, 'Search - Contacts', 'contacts', 'search', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(8, 'Search - Categories', 'categories', 'search', 0, 4, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(9, 'Search - Sections', 'sections', 'search', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(10, 'Search - Newsfeeds', 'newsfeeds', 'search', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(11, 'Search - Weblinks', 'weblinks', 'search', 0, 2, 1, 1, 0, 62, '2013-05-02 12:58:13', 'search_limit=50\n\n'),
(12, 'Content - Pagebreak', 'pagebreak', 'content', 0, 10000, 1, 1, 0, 0, '0000-00-00 00:00:00', 'enabled=1\ntitle=1\nmultipage_toc=1\nshowall=1\n\n'),
(13, 'Content - Rating', 'vote', 'content', 0, 4, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'Content - Email Cloaking', 'emailcloak', 'content', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'mode=1\n\n'),
(15, 'Content - Code Hightlighter (GeSHi)', 'geshi', 'content', 0, 5, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(16, 'Content - Load Module', 'loadmodule', 'content', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'enabled=1\nstyle=0\n\n'),
(17, 'Content - Page Navigation', 'pagenavigation', 'content', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'position=1\n\n'),
(18, 'Editor - No Editor', 'none', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(19, 'Editor - TinyMCE', 'tinymce', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', 'mode=advanced\nskin=0\ncompressed=0\ncleanup_startup=0\ncleanup_save=2\nentity_encoding=raw\nlang_mode=0\nlang_code=en\ntext_direction=ltr\ncontent_css=1\ncontent_css_custom=\nrelative_urls=1\nnewlines=1\ninvalid_elements=applet\nextended_elements=\ntoolbar=top\ntoolbar_align=left\nhtml_height=550\nhtml_width=750\nelement_path=1\nfonts=1\npaste=1\nsearchreplace=1\ninsertdate=1\nformat_date=%Y-%m-%d\ninserttime=1\nformat_time=%H:%M:%S\ncolors=1\ntable=1\nsmilies=1\nmedia=1\nhr=1\ndirectionality=1\nfullscreen=1\nstyle=1\nlayer=1\nxhtmlxtras=1\nvisualchars=1\nnonbreaking=1\nblockquote=1\ntemplate=0\nadvimage=1\nadvlink=1\nautosave=1\ncontextmenu=1\ninlinepopups=1\nsafari=1\ncustom_plugin=\ncustom_button=\n\n'),
(20, 'Editor - XStandard Lite 2.0', 'xstandard', 'editors', 0, 0, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(21, 'Editor Button - Image', 'image', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(22, 'Editor Button - Pagebreak', 'pagebreak', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(23, 'Editor Button - Readmore', 'readmore', 'editors-xtd', 0, 0, 1, 0, 0, 62, '2013-05-01 08:56:06', ''),
(24, 'XML-RPC - Joomla', 'joomla', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(25, 'XML-RPC - Blogger API', 'blogger', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', 'catid=1\nsectionid=0\n\n'),
(27, 'System - SEF', 'sef', 'system', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(28, 'System - Debug', 'debug', 'system', 0, 2, 1, 0, 0, 0, '0000-00-00 00:00:00', 'queries=1\nmemory=1\nlangauge=1\n\n'),
(29, 'System - Legacy', 'legacy', 'system', 0, 3, 0, 1, 0, 0, '0000-00-00 00:00:00', 'route=0\n\n'),
(30, 'System - Cache', 'cache', 'system', 0, 4, 0, 1, 0, 0, '0000-00-00 00:00:00', 'browsercache=0\ncachetime=15\n\n'),
(31, 'System - Log', 'log', 'system', 0, 5, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(32, 'System - Remember Me', 'remember', 'system', 0, 6, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(33, 'System - Backlink', 'backlink', 'system', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(34, 'Acajoom Content Bot', 'acajoombot', 'acajoom', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(35, 'System - Modules Anywhere', 'modulesanywhere', 'system', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(36, 'Editor Button - Modules Anywhere', 'modulesanywhere', 'editors-xtd', 0, 0, 1, 0, 0, 62, '2013-05-02 12:34:39', ''),
(37, 'System - Defrieisenkram', 'defrieisenkram', 'system', 0, 0, 1, 0, 0, 62, '2013-05-02 12:32:07', ''),
(38, 'System - Contents Anywhere', 'contentsanywhere', 'system', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(39, 'Editor - JCE', 'jce', 'editors', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_polls`
--

CREATE TABLE IF NOT EXISTS `jos_polls` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `voters` int(9) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `lag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_polls`
--

TRUNCATE TABLE `jos_polls`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_data`
--

CREATE TABLE IF NOT EXISTS `jos_poll_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pollid` int(11) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pollid` (`pollid`,`text`(1))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_poll_data`
--

TRUNCATE TABLE `jos_poll_data`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_date`
--

CREATE TABLE IF NOT EXISTS `jos_poll_date` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `vote_id` int(11) NOT NULL DEFAULT '0',
  `poll_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_poll_date`
--

TRUNCATE TABLE `jos_poll_date`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_menu`
--

CREATE TABLE IF NOT EXISTS `jos_poll_menu` (
  `pollid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pollid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_poll_menu`
--

TRUNCATE TABLE `jos_poll_menu`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_sections`
--

CREATE TABLE IF NOT EXISTS `jos_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` text NOT NULL,
  `scope` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(30) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_scope` (`scope`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Truncate table before insert `jos_sections`
--

TRUNCATE TABLE `jos_sections`;
--
-- Dumping data for table `jos_sections`
--

INSERT INTO `jos_sections` (`id`, `title`, `name`, `alias`, `image`, `scope`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `ordering`, `access`, `count`, `params`) VALUES
(1, 'Nyheder', '', 'nyheder', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 1, 0, 6, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_session`
--

CREATE TABLE IF NOT EXISTS `jos_session` (
  `username` varchar(150) DEFAULT '',
  `time` varchar(14) DEFAULT '',
  `session_id` varchar(200) NOT NULL DEFAULT '0',
  `guest` tinyint(4) DEFAULT '1',
  `userid` int(11) DEFAULT '0',
  `usertype` varchar(50) DEFAULT '',
  `gid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  PRIMARY KEY (`session_id`(64)),
  KEY `whosonline` (`guest`,`usertype`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_session`
--

TRUNCATE TABLE `jos_session`;
--
-- Dumping data for table `jos_session`
--

INSERT INTO `jos_session` (`username`, `time`, `session_id`, `guest`, `userid`, `usertype`, `gid`, `client_id`, `data`) VALUES
('', '1432631244', 'drpbbp5l073g3fklfbsrpct0i4', 1, 0, '', 0, 0, 'HQ0uoHaOOluoWiAjER-c8J5EZE1UT_Zz0PfiEl4sDpAvzk_F8INxvNuoH596n4fee1sIK31VGvl2LKQ-QPeM8cZpKwjrQugYVgIDcL7xE9wLOB8gelIsT7M_dmuvmgi4lfxIBnsjQJBJbLbM0gWHhWYJqbBpMmVkpud7wNVtgQPwQmq3uNjuMSW4-OyjGQndKgUJN7mbXKmhM8zE1eSCZmym9y-iwzTVTSIFm4DkzndpSkkdtgLuyuzGSuA54r69P1NHBP21U_Dnv-WZkSfQzkMBNRASjuPvevkzhoOjgDd8hXDfON3MUISDnDtfPSiXUQsakWX4hgqpP9PZEtjFTY14vw2jQ1Pc-kwaNWOD9rYvp4H1Kl-AiOtB61t3kDnMQGmFQtRABPns39swGn0eqp9N1bTz6RLvnvFp1U9n6vTShZPiXJokNijIA9RgzQaa6SHGV9jOvRnQHR4br63gqI-ByLk7an8QkneVYy8Nbgh5QUcZ7XvtOCTum82IaSZzzYHj2f6gB-4fkKxa6oHDzpu34sBiUQGFvu7RJRWCzKJdyIDtXjr3EJzmIRyY9FOizOIClbbh7I_nkHNl_V7xdDZ6naPnev0IAM7nL_lS0kxEGtBPTW9AiOwt3rYIRX5-PmGdi45ga-93o7JQPhSP1tuXw-SxJNltIv6lTv4QY7vZ0GfpMYGbzZKxMOx9CndJ4ouKZbkuGYYKAvClYPCyzfa4wKyL1m4orYWbfFAsNdRhGBrbtZ4UhgMqYTo8WAkPYvh7xS7kNZ_InxrCUlvYln8Fv8y2Av-xJsFTf5WO6lWIVFKO9LuEAqzV1sYu37nTGULY5qahQhMbUnhApXa53nBHo3ZLtCjWEmteAmSeAEvT4YWdOy5K9BuHD1tK73mFGnlcarWQXoUlsuaJhIuLEijoXgdw3y4jtCdkORB2_nvR4jhBZN1HKOo-ijHEWlA3iNSr_Z6TgNrRFWYGj1rL9Vo7PLvA8SGNkoY533sY5bYm0lR3Oh4x1gTZlwrSzGA7QUQ9xFuKSCXk8pvK2C5wkUCk0JXMshqbYO0dBXBC1bZ5nUqeN4YoiIgNR2OjownqXg6hrjkMCsuGznbG12xTrIX7z2HWb1HJxb3ApCTJt7XPOCywhDMC78R-7JO6aMsJOy730RrqvpPKrwU01F7p-CCZBReFFIilfS7UTMTf90jUsSbFVo-wlmhuVVMTvKgK9k1HdQ7Vqh4SQOL1CRszMIGfSP9fBSdQKEJK-DbGMhor3C7-HNNf5KVeWL7SOy-yJIhWs_IV_lN9TsTPCcKefuqT00paNv0u46LjG6Bq5Fgjpz8doCGDUlskAMAyACgjOj-vfCpu4Vcvb6xZfZaTwTZYIFxhAk5tjnSHTUWeQc5WF0mSxua346Ua0Wotl_Z7krcH-VtsTYlkKQBsDi4PjUk-Kr1Uo8o0WJ7yKI3zMunq6c0YyD5EA1KjIV_vGQKjyL4PGsjpvhsOygrDltp2Lg..'),
('', '1432595575', 'ujfm5u8ku97i885mmt2lir5ki4', 1, 0, '', 0, 0, 'Qb9-PqohCqPdaiXjjGY-P8TqisE9EDE5BEqxx1TOgqCDn8xISCAs_JU1v5-F5MTLcgUofTQC6xbwZmHxnZ5pCZ3EuM7bvJQLnki207UbBakaCyqObpgVtvjO3Qj2FSQFmUBZEha-VPKvKEvq5eq0_xTJ5xeTtA1oy7lrogZBU9jIM_Yki-SJR0l6IafrFac-eykeOW1WJARHw5Jl_JONVBcAhTT8ZWLBGDwdI7fXZbfGpWjBx8bGkqOTaZcirUTJzSZ7U_SoWIpxQd5A7-w5lfkPplTx6hJfcI5JMu2zj8-UKZY7hPDu9B2B5JUnqkHSKl3fEHodQdFYcYD0xquC2e_cxVAq_Zebzn9UVUpOjH_oQrui0giv6Qa8S5TgJNqXiQCJTc2ZOluOjiyVALiOT3lYHcnkcou4X3rLjSbi11WFc6W8PX-aE4uSOkjAmGGJEKbv78346H8JLw_GCErGu1mcWZm3Z15iya1_Nj0oychWfn-lrKYCbSmjJk0oY8iQtAuDXcqYeDRry6N8qjVuCmEMhcm9MNKAHVt-KMwcKxKge9Osy19yI3FM07ENRy4Zmqia-5PIDZcT02jTBguWNNRdlsKj_ZHXClkm3D7Rx5i0wmaebwp2SReO_5Ci5oJfeKdMQEW3D90KFhYrLMW77nsnFE4ZfJz_tddaWnHkQ_uvVq2M5tp1q63yPL8UaI9gWAt2dabtdDEGLjAp52kvb6cE1meN-kYvF3A8Cn0LTezTbFAvZ2j8kcmP99xklBjYvMoJvvKmnTANIjuOBPMQ70M0rSJuK0fK2qYimcUsfi1thGpp7vzchQQpruXfNx8Bp0qhM8CFdRjFrmcBr0Da-vSu08Gif7sJqOLzrfBZ2pnQxKSGZA3Q74lbltUIzVqH3g-myrB6zFyQ9WKloMO0qdlNVIC2weBfYJjPCCf8SopHRJit21eBolCwyfbHwBE8MXikJ7Q1IWQ7ecgoKkHcWEVJf-gzGjgOmYX-5aIGYvhQ20ZNRuU67xCl_TN2eF5BLpKXz-vDjz6CSOV5anpeFfE9rLgpEb_3PA_5HitgC6H5tXw_51-H5tTWDIBPZgqIU4ACkDjvztcM_iT2oBpgaLmpLLQJU7l93cQ46wsBGxOYprGVc3dQYV_05fkMmtZGgoVj2oVBq3OqfMmOPy3v9xE2Z-dwpHaZPa5MAty42aha75a7siJqic0U1VennDG41DRmiz_E8jNNfD9jKNekhnUiMTpriRn3POqgEN9NHwibLPApLVr8QYM8qOkHFTJWcNyoQOk_xMKrM6TUltz82tUlBv1E7OeMEEM_51PKa-aZf4-uyD6NkYo7J1PbaWLGvCYRhhS_ClB0SBO7FPqoOxkFLbHG4WIzruBqKp2nvjslJmdhEKDGLJboNIrp3BfeZgrQy2ScHqaKUzzKwaXVNBgxSVsOFcexEj0r6kVBjIo1QlHH19WfC4wj2DDQusMO_3-j3sgG8soKEjaKgQea6Q..'),
('', '1432599976', '8i0cgsgj4d8e6a0n3ipkgo2d05', 1, 0, '', 0, 0, 'VwGR7ioavKsjL5vAxuwIJ8GDvZ554Hd1zLVFuQnP18VxAh8nSEkdS4GlzgcGsQ_Kj_8uzQx_Z_J5gHKgkYYDPdndBSwkQFcu2qrYsfLMKNEnaYaUG0yRHDKC7qWEHrdjU-cXi-30Y2QBfOGf5TMJgctk5V875IOVA2LQuBRjnj84PD4RvcVHXN0vU8bP8jwoHQhqJtUgdL7vWjHwO9eAGtP4tsHmCundDpZ3-WysQv2alz8yatf5CdsRm4s2jYFJibnrZHcN5qj_g7goG_dZefvsJX0xItniygtV9T57GWnSwsb0Ey7zVYzr-tx2Z_-X8ROMFxvsF2lX8JoTsABfH9u3Dsahpgr2yK9OGB9qI_GYG4R9AFW_GFG0WC1iBXhoqgofPyxLlBdTmeF3D7-rP8w9xGllpoi3c71u8L3PC8Z-5J6RTaFW26m_4hi1xOKX0N5RBQhwrdHZeXYYsZayNPTRkBcPLo0s1C3stR8Y9TKwkOqQkLMm0acFV6yzH9tH0s1QPjZ27GmqklIfUYqGVYDAuZyiXZsaoTIS0rMiickh9akfWNzVKe_iueuAGdHdAFYGyo40xUb7oDfcKsHxHvS94xA_Q_cFjzLHUGWkRw0eOVKOK1xo6m_pfKw87PbJN_gm77fOOD2wmN5bV21pPvUFh4A70Eq1UeAfUjuOdrdv10ZpU7edSSbONgrJhedbacdFuShzlHo1_KrBOAagWV1B91H-Wo1gp8X2cXC6v3tdbrVNb3QPl6YmrO-TgrUcWaXrrKAdX9Zd1B4LbJ17mk4TCldUCsIvIbQRudZQyEEt4-vqR_OxtkIx6jzDWeoCApP2jRJk7_ZviRGLz8vu9PC5mY2xxL6jXglKJYNW0eMKsSq-k_fcEMXi15UBGYtaUintrKifX7-tLd0mRVIF0Y-Ax_S8AsXpoOF-VWE4RuN6FwUY243-h-HivuG7W992wQliM6PkStQPDxdeKVQ9bGnJQs4V0C6dqoQSkiAZJa8TEJ1J0rkHKVmiB7jzAf-53-kFrPAHtxmhmQaFuYfu9xQrDmY3ROP8nAJVa-aee0YMvN79MO1UxT_AedlQtLYXDs3_ba8Y0HbJHpa6ZII9t4pVZHUDr6Z8UwiLpC46mtgEwbjwtLdNdkchS29N4WcRZZtJyWfMb1rVGSn4a5wJGEw2LEfXZQurP0ix7ItqJvcUbJc4NmPHRXbLDydIZg0ILyYK4KNnN_noUlp2F7k8WjIbYbNsH-Ri3zcXbjkSy5sIn77EdRbmvcFSsGrlJ4kJco0e6slFAQsxsQTii7e6ZaTezGnlCFF8IFRdkRtdfqKdZowHQ9no4DZczsiO6y6o-aNK5pWfxM34RVi6_b9V-vwCJJ1SoJuzqzdhFdzmtC9p6lOjohgklFaV2SOu27TPVnaT1XtAuGLjWnfEgweAVjz2K0OWVfPIWHkK1Q-Zp6e3QOvrjhjny5kZc1epHafXJFAq3iZBYrKKlliN8Cftng..'),
('', '1432622604', 'h00ltscuhkru03b00pqu45i8m7', 1, 0, '', 0, 0, '8RK8nkoLGUq0cxUVhgifElfBc0X6xU1dR-5IHdWNVGkW4OPWixgE6Li-VA9Lo6LwYUYJ_9HKrCwm5Pj1BjOuE4EccUrpq9GNRqwd_Np5VJpwznWMcOF4U2T2cZipAkGRZWw2kdZFIbQ86hVtbw_IV0j56wn3cSxm2f7YH-tTyyB-Q1xK0-nYkgVa3H6gEeadnnczy9bqnG6fAKWl_1wioty-fSXDKFwo7DWbLeA44wRsrDEC154HRPCWe9nqmLxPx8ziijJ9QdawfiCa_l3wTqJXkWWwUW3QF576dVSjejAkul4jmxo7qnn9NZgAbSHWJpR710t_II1nKUVmpVxTrpXrkyGDI5vGIvK9OCTm3V6APvtdyMPvkUnPmbfofCPBJ1ikdxIQyzbVJZR6hqCfnR-G_mho_dAT9_d4HzidNSbKIgaaATIXWfAg7TQO_AEuoHJ6IViw58W3w6ed9KOj1gJf_GBssHeQuvuOduRMM0--Hd8cU82OpvkRkoWK7ul1xQMqwYKwn55xGok6Slk0YgAelVmvgaVJR9S2Rp4pG-YgJ83NRCJjRZvKL8wrR0hooxBGUO54wIq7HbM5LIrgEEFRbzZct54NPCsQl5BUAG5S9-fiDIUvKArKj3FMoLa1fNWyrtgKneju6Qwp5G5nlRjCw239-JGQ7juX3jC2hvPqvspcYw2jG4A5sFiYtkkNFassYErgOiml4XFVbXKP-Og1xlG6BYkx8w9uQvfCebDMzPC8Fm4x7DBhQiE1TVYY389VSOU5tIGKGV-8wdhf2glnJtxisSKATM2UU_LuXcUJubQ4gdOK4MT32GizhwlpJ8p9qa9UObOnrlapkwCnFh6AWkeZNyYuTDNFdrOzUSa9VA5f5FwLTEAYkDLxk1m8uxHGpXz1TR4W31ZoE9trwEc5hniA2T9D66GimuGQRPWLRKVImBvXgCZM2YxqaQktP-7Ed1sUGBdoaEbeRwNlF_s7aF6rcAv-cAeWoZtORlnfAVna28372BupcMHbvlR1qqPJLRzvSB88KsECcRtTR6ZXxAsu5QBa8yx2t2lifsEM9QUz96xchG3wi4tidWejuI96k1SZJVUh35Spju1q_9_vHcgO5gH6VCRi1iOgGIZS_ztJeja_8T1J1dFMXHXJW3lNKLxZXyfsQJ-sBKkFTu1YEdPskg-agMCAPVZpyJ5G9-FPsADyaMTXrhn6vhvOmiz-9NFYuUu1F5t-4FFmhkhoe0RbTUrkBpXncQO9f0YXM78817-zLB_iCkf2pd5vxS6dSLp0UEy27GsOZyQ4ZBbkXfYfmXP3Vtq12ClFle4dtWeGUWTTtXQ9kHXoSOl2-Cd0cr3CU5p3p8f9yrQdONxEnRPCngsbDDa_HUlcN_ABDTH8SxDEodIuRdONMisQyTybeoal2r-_jQorWA40B0e4NycMlKQYKI5V3laPHehY20STPbt_Ixbvp843ZN5PDiFZaAZTlZtSaUkPW9IsxA..'),
('', '1432623273', 'q7kpuiaqsu5eh6cfcnmp8ke5m7', 1, 0, '', 0, 0, 'qwpZbCdd19IJ6VT3sCTLBeWG9A8uHGKwkk65B3af1x8ZfsKe3Tah0VdPv2Y5qivF9UB7nn3Po4DhnlPIrtY6CADOal9cErQB6qN6g55eh48JgtiUxWcRKfOkAR7NyDBgYkpXMTssYaQKXqcZwPfBk7U99A9mBV9v3_nG8bBW4DAHDc1JRBF9FAM419bX_pFoSKaHpm66aqq5dyxfBq_xHK3_lR2YkWUtcIvvea_C5Bjod_gY1yRWtRR1gNlryQUoRKs2ft7LtGHeceZVF-bMm2gpae-hjJGR2_Yu5xBzfC68yD-_VMvOX677kDHDlTT5BGy2I5hzRH7rhdUXDroyQzqRFsR0P7PokTlLWPMpCgfKUKKlw1JXc9gZ0DcN7fV7rFDB7juOODWx1eX0YGmymt36budKv9eTZANodJAi8FMVmvaSbhZ3QTLzOen-15gawh9rMDHHxc_Km89f20qZa2RQlrEIqw8s37LEyQPCfB-GFzYMyqdYqCvDCvKZZwjpeEXjVYE6sM2vgrIGV-vkL-x25I16JtVXysWi5aI4XMLCIvO-wNWHbcyXS7OwsVX3j81TMxTVD_bllqB2WXWySgDNg5d7FYoHNUyI9QWulAsgMPxpS7Bp3p-4pRZ1McYuh3fFSvLy1QsgL43zAZhUM_z8uwtusoUcDuIfqweJ8nFkvfC3QaAOoFELL6eXqKw_5xCuImyjnsTzEsO0BNdZJ0TF8bNaOLso3iQB0U_zrJG2lQqXHFtRba2gIeKUaxRMrh9mmZGide6m3YDU1UmYWcbXY8OmBEZ1F4PShewhjVU-SzQ18g2yRJ0u48DFY3JKu5MkE3mXraoelwIs4YN4pBG6tegyuGOcNg-XOlO6bG4lzHTV10CUXzEp5_dmjQ6T7N-489r854Uy8jacsl_ETDsZ4cff2tGNb7XWqZJsEH0b4xHWt-9nhTgAWHMYmy2U67iLJsFkJCiI8gGxoz7giTJB0_TKAso_6aVe0sOrAqMI1byN5UQ2GFRKPROUuP4_Xth9Sb89gk5FB2meIT-9KG6uTOwhJVDyOLYMN9ZtYtk036Xd8dwDZbJSNWPin8r8F3nwGviqeds3ZBz-_lP1J5-rLaE2763BmTidSm1Eb6Oog7wKEyS5xuqEkHd6If0b8eKDynJse96nx2oiAsYwxo0AkDRE01GeB9L74Ab-rijJotuCfTadFvvdGB3x0IVhylYDw6oiYoDZKP0fX70CSQd6EkCHZYTXxF76UVA-8aASDSIE3FCjbxkdOIpeY0U4VjUcjeo1z0eXmS1ufMz1eqel90wDdvJ5CMmgwNS6sQ4MxBieNpJ-VhfbHv0oyJy4LKef2iGth_nmziUDM9Yel0iguidB7O8k_aHhsPBB8AA03Q334TocJgZNtaQrhf6Ccxx9UFS9dTfrsbXRGcmvBpLwQViqO4pOcbMbjOXq_y2VSH3HyGcnXdKIgTnJ0jq8lvYkl9bPBpj6EwNE4ShSzQ..'),
('', '1432626281', '2t0jpnikt3d5goa0t65ceov8p5', 1, 0, '', 0, 0, 'TuWKNRTQOrToSwYq3sqGPbrHC64Niyuwzxwh45jRPZ30vntqwSyGWK2wVTYSMRM2Dd8KWSxvjRuuuJrsk4i8etQD9PKksatP1oJ3QWZoQVlSHH880TJU8-t7QuOge4YDC91CELKfzC7kvddDb0gF9ZrRPUQ-VBwADCCKCP-0_73G3oapiBohE_GtuZMiElo8tATXMzJ74jzliWcKCMDPcafcgb5VipNU0pD6f1pe187XmYMdlWmS3Fb9Z0_UbEMjrIUBH0W2z25tdz1LBYP9SA4Zq2e62dNafgh9vptbzCrbqZh0eRaKovjrki4N9CD2vVVN3kUfwOiqIM9T5KmEagVjjfZuGlo0JhRvE8pcn-9jy2s5T7gWt84ChufeK8-YkfcHrp-zQ2Y4Z-hUFnWLTGeofLW4aAz3UfsWStoW-5KoVL3Vr1F5UnPc3m_zFyMiResGGYqDCm2M9fztbmdjPykMvg4n9vuWeoG6kECN52VcYbaoJA-iwsOh7qPzIB5FYersrwc2BXWN5WcmCaYsdNSUNZzbiyarw4MNWr5adafDBCgXiZ65d0ts1A3NE12T6Dyoaqc2Nv4KtF2CSoDRN0z2-gzHlmfB2QJWNkNVnu-JEK3mb_b4xufyWpz0SfmSawZz2CnOda0V4JVpuZElxyOE8lmjK-zuIbdmFxgPZ3LTNkLHtddOpWduKT2PIiEt_rqcI56lG6kwJ6MYCt6OHMYmZe5-wwtbi2UCoKkkzHs8CxBhUk4O5hIhcztxhhoDWRGxpBrqhV9S16q_TgMROrgrRm2x3kuxmXz_4eLpna3wF9qSRufhlG42ydBEiHd7xjdgNXgIslhXI4m9g0KbGUe7vGuJVU5gON1gxIpFMu7HoaxNSE1Ao2s5E_psqxPYHNxi5lWWMn5BG2pBKUC74_wEms-Oduw8JC9-24l2Kibx53u4vbtw18hz8wHFbXVTgRWqGMd74KkQl8pE8qDksX_kBtFbkir5YRuWrJRWxCgRpNI1HjPWi0X0drwgEH0ppXYN21Zx7GDpyMJ3Bryobv_pp2sil7ip-3dxoTZ0KXP9qrfKiCY5kSO4lN-f6vHgd0J3WAHU7bacSHPIliHxV9RcI8BwpdFAjoUZJz8B5gW7BPZ0T4BgwZA5dacFvfhoods0IYK80vripvla5qRloRMlzAnQdfQxrxPOOX_hBcpr7KlQRz7g50XbItsE2l9Gw17M8x-U_xAyaQ4GkHtyMHZraHfgscintvxJX-mdMlnokQo90UyKl4g0XC6-1TAWgzx8C56egDe9afr-As6XRsA9Z_W6qxYnIbzbMF4S2wK5PM2YuQ7b9uV9fPA-Hv0sWeyLYeoVwIFVeK7j5kzfROBQiOCdjGjH-c2GXu2EoKb-m__3Wrls3B-ertx0vPb46wtdKgNw_sp3I1uVIaK_eUtWnSsK9JwoQjscLmM5sWwvRnNxObFRzkGTJnn4zOa6C0eofO2mS-Us1j53g_Bcyw..'),
('', '1432628469', 'qaq3kfolre70u872a83fcbat27', 1, 0, '', 0, 0, 'aZzvOvAXlTklprXt_i9OFH3PMaK4EwMEdC07rhxyeHiXbELVG3D0m1958TCxSrb5uNMC-4wB562p00vAVCD-X9aYxFcsUVK3AVe1xLDXHIeMqYqWv7hQ50HirAnov1dW6rA_ht9tKHndYlZqF17a0PFIJ92lrHOp5UN39pX-LMnglLqCqTfp_ik4xMtbaiPuFEq1Hc7qqOif41y-x-zo2tzSVAu0fKv56JJ-uyy1ppNu5-qIJvb0v0xfZ8nxQ_S8i1SHB20hvIz8GQo0ZybmtY0tMpsGJejjc903eXmp7xEcjGryN3XUzxR8wEAeXakc4cQ_Lf23lL1bemgMVVyNd7mHzIWVqs7abPb-2ixHY0ysIOD93tmHAx1PfXDS6Ns0Vgjxk4oehYM6qR9O4tJxb0rjN3-cQgQW0yOET-xZJ702pTk1adC1Mn69SkpG59mJGAQ_p6ddFvpaiOoaSK35k6xqG5K4wP7GKrIM2BzzQfgWKfsFbyo0itguyH7iVqYL1Nm0IpiIhCChV9GTcqPHQBih_VN5Tt_WTNc6Z1TfQJRansfHAGWqI1j06kC32cXDiBD_DK7IE3DAMONlfl1TDm96YWaHRM_IjOGkO3Tq_8IYjVLWsRl2dPZjP7qcy-gW3ySOX8PJvFEjgQM2uuiXL_g40aHPYyLK8wz-q4oxRBHQz9bh4Unsi31a_7NF4G4uxDzezykfopsqEFwq-XBe0RX24EtdmhAndyIv8212AOMJ_BkDWegXXIQ2K4UF4b3v6leemVNVn-x6Me7-w6_4FsxYsaE5HzsHYRPw5TEXCg4n7EzWM3ZlJhf-Irv8s_UFI5Gx-zK1riUaEArZy-h3dp0veri_njxG74kj6kpwwOF8MmlGii8nLW9xItbgyhXHboWD4IUUNx_82l6HvG76fDTl9BOhiccX5tEW6oZ2_Skh5rArwhzu2nHSbkjAAxcLTKTqt90_G_m89TXiAyFk6Fxog1JnLT8wJ9QkqW8UofAbkWYY2qCXxor3YqyaDAUxxuGEk3jzNJSls0DgwSQ82y8d4zoCtnSfWSaFmAPfSMx7IkjtmQZBy4aZiFf_S_vK9u2ITJlbIbLcTekF6lGnQyl62OEAfE0cAvBCVVM_LNuVQWdya6H9a8_PqMD5iyWmxiStBst-VSqU8_wpG4jXhYOTTz579U_rySrj7gTKu8RgwHBssf1qpObr7fTFMV7drrfxU3L12C1i-5CFGNIQDUd9qAgoJaVjGNDedWfsyXc1W2N8RW8eQeb0t_lFp4S1zS3qw_2cm_6QnloCnZ6ZJDvauCZKwOkxe0dbSy8d3jTG0AXhInve7SmneDrpYSg4A_3FHOefNaClF71HnUdONOoPUh1_N8VRgauxxqrHwWJDIDlJbNIslQsEe_xnq6UBpXpDnmePYZng8p-8Zcw37-W7LCClklH_bXVbGAJhBgo9bHN42AvGzPF3VfaVGcw1w3w17sD_XhH1zsacy_bo9A..'),
('', '1432629785', 'vmrlpvbpmai788v83nhbjfpgf1', 1, 0, '', 0, 0, '3QixF4xM7Ccdv1QEsEIk2OSiv15Dsib56gscH0i9XH94VU1t0q8Jbn_9KNr-Dpd-9mQ_Rt-JgHAyscO62xQL3FTphdjKw81nbhAouORphc4prANaRYb74shjMSLA22qc-fOCjODE5xBVJY0LoG3dMtDr1Xj1lLdd2E0IECqjJFNij9aSDKTOlpXZMOHO-uy0p4-agP5ABzls9XHNN1KcUfygZpKrp-JxD-dLcAz8bi8MG050Io-rBaVG5FJatxaJ2754OPs4NqIIBzDKQrhu7rHVhHLAVaR6Gy0bGqIDAzWa673tgm041QcOfOQPmZc1fkZtNQa_1xwRnYJ2EGCN9z4-jv6LimG2bNSuhTRo8XphdWy2cfQXSZ8NOUDAxh9t9pVX7rLfa4hNFBPvj-EXWyBzJMkyoBZP3Xw5cvdB_y02uIRVc8qDOYDYL5LsCvuWm2plbeA07GvLA6VqcTbNrVH0aDjC2LpksOBgnGIrSk7yZ5Ar0P2iVSWqIWNaCyrZLW1TjjeQGsQMEUJijR0ygYGwUXQlbydofxEOU6FogYAk_BhqOBw0A-iXDnsMu5B4qju--5j9r3HkB_Lqaf16Y5dM4mpA92z0ff3mx8EBQ75ATajRmUrhKTfjce5ywkS7fyNXze9Z09yh6TXGvxq8AptjFehgsJk7cYRFpoAcqJ30SudtBqrc03mssnBGNQ52ptpwLHtpb35oHKDCzoVfvSCW1J424cnC0fpU3WtM-CJ68U-qgaHmlHmrCuRmFbeBh0AmkQ0751VemYkkNkMY0XkjPngI72oyXMtNVSWC3htuz64h0yIlSchR998uZhyaJuPX98QdYaSeVI6p3FBOiKjZ49LWrlJ5lIQTVXsGlSfY5goFo6axc2FCGd3LQzot4GIfiyyqScwwqi2oDEFmId5TtR__DSrDTIDljCTxZc9eDhlkBrD9NXlQXgw4JxULiSzYXB_rc1grtN1MFI-AEPGIhILVu8ZYrF-iJd8Zpo9IiLcYkO8q7U8tYfijb-JBW7KlNti0lNIdoxb2qBCkq8wKugnjge8LBC82StyWpADiU66GbdV6g_84FQCOfuwlC6Iw-cgMgQcXJ6CP9rJXwQX2cdvDkbIGJcXyHiGUfSr538R3YGt_nfpJibhQufd9rq8Lmb3zli9-L1E_QfDs9noPId-5VnXIbIN_4obYbfrzJWJIyuEyyftviXrbY1RH1VUuUXrgHMOLfpCd9S7OVjdNKIqSqx3KvFl0q6ds28dje-gXFSWLgzfM0O9hadKZLMkbLpFOWWl7bLYEs8wCAmPU6htHjv1o2wVLvS6d-9IPafwJFquww1Xj-E_iUZwrz3_2ZXHDFcFC3iP1F8mw2ICN57GJdGj5tqsJxieetJ79w3OYok7Z-B7v4Y-UPAzCH2W_hWIrXqS7AgxLqlUF_kZPvbTePDYURHC0PT5il--LtMDfBugcOqZU-xqRZiD9jaLwpZSz9tLV1y-MGud99g..'),
('', '1432630122', '4u6abb0oi9glm13kvik69u4il6', 1, 0, '', 0, 0, 'At9WWIpTwY1O4qnJ5hEKtjIi47029C34mw4q22ZpFvQo6_kTGZA1WD3H1nI9NPfEFUbcPA3Cm2-1gxLZxLtZLXkhfICnCsZAi57PbSwjToay5wC4e2tZ7ACfXs_AkLimMRbvp6nAnhkBvTZUGLn9h_PQZXs1jdgiXwbtRKIlph6JbazwLXELt_cXdFEW_hpoE-2CM4WBaplQ0-iUJRLfD6A37aeDZWfPFaFGW1Rgyud166k6qYBo-Tj1z6sbnRWD_qHlB7xbIykxox6CaDVa0c8eZE8Lbw7gaXpjbwp6iDNG98NrfvggpTVeiGvaPTUn9l6czeEFWTbUsYTeNKeXok_bAeed9JyF2ngUpGWxdwFYY7kIFGNylthJ2W9gY8kir6sUVAMcXh-tn3sHwCqYUDOGmZce_hdZ2zccAkb2uXA-R6BjPTLFgkyxtPLan3acylrsJdQSxKHgtjTbufbQ-FjvXAX-8ZGobTJTEjC0ae9S2kjUQ7EKr70v6jLIml4jADHWcaEEZjObWJ_f1GsEXfgEZDu-sIGGyEhz-81wIrQJvu2pZLf98bv-p34PGccFWjaSkFTpn0x997rKA0gH-iunFyANOZkUlQ62_XG2m3_KBxdi8KTXUSQdzTLvkpbIwN4xE-sSx-jXyXC9vP1SB3uKo-_ws3Bv5cI_v3BGQsZ8JLTWeB5qRGmBs6ZBEcRkXrkEtshV6Lc4iT7um5fEp00SeHx__2IIkzOlWqe2gFvG9j5NzfLiQ7KS6ajHo3APkT4Q2hBhkKNJ9DJKJ9NYlhhkWKZmkL-jbls4DsH9qYG9Tz1TupDQuBM9hHzRWVeBNUt4glhQgBJu3Frl71VUaPBJOzolt5UtbkqXl1rAQBaNLFbp-lXnp0yjbqevBQjKA1FC86xQgyLr22YRAKGDJBGnvqB-KgGez4RdnhZcTL-EwvwJ3M1nQXYrqIusMV_w2sJEsyGPJXwdGXIxRPtVI196UsyBIdOouKC9_Refz9duPLYoo0vE5GoUN32mQ9hka3Z-uTAWZ_d_pmIahAP6ZZBZTmqpsSkfTUZFJroU0uHCKtH65KJHo-eEld5Bk5II6IQLjsITA8ZHuGzrv10bpaxn58tuqbRQsDaufcZENLJtq8HwaeTS6O69VcI0ua52h6S5x2RO_xFAUlbfUQIz6fC43_vTI86uZmdBmmR8Yi9ClUcuTeZBZggjA120_OwtQKg-y5A8_C-rHysXBL-q6_B4tFqhYTLsQBTj4XnzNu5HAwVp7pnv7w-xOXjOPb4Fz5hz4YkH9At4NlJGC_1r8rHs9t-uqsbBDsMGIkf8SBZcT0cLZ5fpVOuY_ib5rQPFKuBDMfhG5a4UpH4eOvtOOZ5yT_aTjdelQAL9UPIaQ0FAKvIps2Z0N5mMDQ7bt5ysWOVadQ8dwGoOAenAy4vDZ2pHZrKbCpgf-78s5HhoZM3DEI3qSYV2GkrlhylOHqDHa7EkWV341jxyVtxx2sNHAA..'),
('', '1432630489', 'v41t1q5td488piugbb6lkl4l53', 1, 0, '', 0, 0, 'TCFDymfuQ-Mt4Tx8sHczYtiql1ChFsU8HIrk0UGp11PbFa5xMHGbtlR5ldw2CkeD7vZMurViyUBH-FcL22FVKNbE0plqoVNrGax3deuk24jIST14MRBDfHfIPLwkV8L-ilYFS-x-MWlrp6j04zBslCUbg4o5r49nzVIq8wsLX8COcwVTIgWV_1_IL2d6uq5Ueyc_hTDoBqpgSaBya57F8BN9qAf8gADbq6D_Lk3EI4WNPWgTC6MNFBw9x_g9oKawIK4DEHzym5K4lJXe3vuiGeDp1vfXQHNodXUMTq1p3CcQamg_OJ6I8G0oFY5DBA6G7WScRchJpplqhoHub5b8SQRJgpHCKRSFXQUZ0J3f_KtBdhVjJwnSkdGOITksZfRPASNoaS8yekgTGP3lO6dvGdaM4O8_CxcZ1YPz7JrA4yluNskvyXUnwSUp3JptYf8z0y5xAR-Tzp4gvAc6HQPMWohon4wEthNqfxswb7w31sS1cYh7gIO-R60lg63ABDOgiccrOERV1O-kA7kskf7V7pxkWH_pnh5OwCWznAZh7eDayNqEJwrE0qyr2UKlCWnNlU56NYhR__E9-r-KCiLOURHjK80JnnesplqQWXAb3lEMFMd3qKpEGvuC46sbrLuTfWFy3KGX-vs71CqE3AJ5L6WWgnQdd6TCQkP84gV6eeeaPhszj-m-CJJH7oXOMP9MaKnaRCcwQDz-WsxBXMYRksWzm2t3oxWujUZ3HGtMMV196L-QZfsVqe4YNzn6uPWzFMkLvG0AzNRnTGU1Q7xRmBGRAN4pjYrK7K5GPRtPkpgz3C37dIm9YKTIaIyG4cENZJRqSiNS7wz3543Cvy_7ehbBglWNVGRwf3Xpv-deXO2s9zKxIWtzhq8Er4KdwDRfUKrznrEO5lLvHj0wnCW2_mPcQQGrWyXuDjSCvRVf8VZNt6Cude9Jcr4nsxYMeMUnKWh1VI6EC90LRtYB3LM08LwRBN93nIF1zBytEt2WWKayKMuYE55FjkgI8DN3NNDAxm2qCi2X1IT9QjABHdRZFeOTbr4X-56dPHlJ0jPlN7tMqjdkEHSGBO8KnMfBGJO2tBzL3V_4jIwG3ZqQviIs5xjeTFRLH5DJG-8VOuWCengHQLRiA9mNLeQxh7cwC1qEbYaomLhEWjmtNzPERHW9JQ-GvkjNOyHTTR1BV-v74ffuzA35mr3mRLLcqrj1tSzQfAvxXCzOXFQ5KYeWotl6PXiHbAl16F5pGduXQC9dZt7QPLGC6GvTTA_9LLDQMdZUZMFZ_oYP5TQ7FBOedEGWLkGg_Es36icRg70Z_6JNkfmrcrOIIdzgmeX6TaeKHsfzMfM3MFHV7VT8g0ycKmL04lfCgem24FUOqcZbedyYiVccXOuaRNkeKVcQesADi8ZMIUmdUfkA50ZYuJXo1DWw9o1uC0ydzj9ynEd6YkDk6DlGpl_EiDfTJGS50Qn2MYciJJDMcpszZ7-myFRlWpUClA..'),
('', '1432630873', '3ov6lfse50tt8rkfl9t2u2m8i0', 1, 0, '', 0, 0, 'XjP9KqAfB4zRRsoZnVsFj67mlGwnEnBnhIYQENIPsA1N7qlzeNVhyYC41oO8uoqwuSblOtzD4lb5qhqBHTUe00MleIEd26WtX53SQeWw7EwXA06JqIKgIHZFGiMjHtuSmK6Dm8X1Drz0g5Kk7tKplfwimZwu5vdomq1fcGBi7pxgQ-X7OYvb6G6cQvvT-aaGrNcr3Q6bDMt6bX3S7SBmUZ5J5y72SdUiBnWGXzCAwQosiLXBEsPkoul_HQMcamtwL-UpTG0KLOgZR1683ocY9yBH7IEU0-Ap6iEd8AgLJds4TQyY3vYwmzD5B9B6v3ZyEE_BV-i0Mq9V2iXsmMGBb5zQOBnBmMF8-sdHWbfYqyJGmu1B9P2Y5GhrZ7tqN6dXFyuaVfcI_lbCJkElRb_XXISWlX6bnUdvKVSYGBlwJxEEa8BE6fzBXP_QFRzYBJcuSIiGNUAaJ37rxGZ_gf89KlmlioFo_TB5aFm7AU1glb_e2mgRWXwj1JJiK_2qr_dTa7YtZ4CFRgr0voH7g-Uq6cUkelbhkLuhHxGF4fRfzbzx0YaWp4YJWxiEteT6E2PIZ6mzpmo1IBFlUJPbyMpJxSQW3g52h80M6oo6eptobrL7SjnhZsMax-yR0PUocw-EwR8KaHc1NV24SFOKTYjumaAbbHX0hWJywTf93Q1lB7GzfOUiYwzpRjDJAGMjwEvqvj3Ubos0fHJuTKJ0-6JOhJafyWFjepiQZo5EYkhpEbwamUD1tP9GI_2ES4sYZN_mUYs1ug7iU4yqC_ciOVdG2xfC_soiTTLGY6FrTR7rcIdCH2bPanuNUZI2I42RRwfFx3UU6AEkgudMNQg6S4Gf-odFzSh4hnFBNZ2LndWU_5aoIZ6wobn-iY3sQY61qiAxVUwtkFJ_GSGg-ZSnEd_zA6tmCBiiTcUQ7uuRiJow15CgIFIQrCsEIvOWWo05WIdzN7oTY_2_Yczkmk-0PetJQC5vtrj7vh_7BQeagqa_gY_s5ZyRbzjkBqygQBQ9bapHVABXgIOQstgCSPkDA7WegJibl84pEC4dyOjbb9BJ6-IMxFtq6Up48q-iIQFO3DsOEoxe47klopKosBxTEBArAWlt_hXCBa9ZLWy-iORZ2mGD3yupZBOAFUBnVdF3I77GENZNNqlL9YNdkPTpkZO09D0H7xJwAN4TIZJtZxLaNMmtEkwlg4V5hwfcvANmSys9qo3w9sVSJRUCLoY0zMjtWkIZ6w0-sBVWlJCKDQM75Ejb31KPgpl6CzSytPOoOe256S39O0BFZVec0eIGmkv2ONwONAPNMbYatGFZsrYAwFzD1SGaUF-5ypwo01so1G7_7UuX6SF7HunSxxGXCzYpTxsjNvVlQlVCoTSZfcu3zkTEFKwQk7rkIosfHsReKFjKYqAazkVDDuRfZtzWRD0vWrzLDVD--JybzthP8X_SqgUoeoA5TvlitTb_LsoJBoyxb9_ijTrG_9yrnY7s2kc9LQ..'),
('', '1432615196', 'pnsghng0r9lmjcod1es6bga940', 1, 0, '', 0, 0, 'f3XH-9oQeauH4zOyUPs8-DiPu4a9G9qU0Iyj-oh_DUWaeV5sMt9Htas2HK-y4y7__UYBbj4hlqQU37R3q6R7LGptlyKedlSm-iDMROcwkd-CPw20Fqhzm2sMsjzOJbEOoyomuKgdhLV9LixFmpu65-ctTLRBPKrb_KTG68yxAbRfM4rgGiyZAymPZCUqa7Ry9sEXSuf50iBxtK-YPy6FqNHWpkHxpHOs_JduzxMr0ajg6WiSIyyKid1kIDHFkMxncOZqqWMf0oMtGe7L0V_SDOF74rpOHKgNUJJepg1S5MZV2bq6J4SMmvEsAMitKfsYwYaRi0EqmHqSh5LeBn_o-Y_hjCsVLtlEKvzQN4gTbhyTD917BUJToL-OdzuzgIY2naj5s_hX727E3G0h99AWPtlNkKrC0IuJz0dsDvuB17njO0uY8gpBr6GsnJro24--0VxBAYO-4Hr2GJ6W9oSZPimp1MqxMEVa5zqNcp_BZ_fc2Y_uRFSS433L408JetBcatAVQa3xW_jPP_So-cWAQ3fuN-LPSfi_KHxFOITpNch0l2gf2IcP10SAVPFJRDdB65UHwlylt613pF4jL44gopK30DSWNc310k-3tWtgUXaRM9soFk6hPfAXMwsHc90vXjCyaS3JU3DBR2wXPLPNxlVeeFli1K_fZcZuR8nJho5eztfOkygbExeKxgZnwwBA75KYw8hiewB5XnfwheWBs4CkQ88zxWrDGqRsP1mmdpE6_N7vdPAgDNvi2cSTuzrZqLKDObltd6lyEeuKcl-ADYbiiKKbZjqeBwOyBsSnoYeb3U9QGP9snFcnFZfg7tKGZMtY9Bb3ujlzwjdG25Z9QoqmMwn4MQK2re0V2kSpttFHmLETR41zkL39lQXkZbv42xsKlrKWDRj4lck2ClPankWyUmxRDAIlgvBfsCqdJvepJxWwMwXUSl3PjM6z-dRtf3moqN0e5qVDOn-Q0BYSffLdu7_GfxaEd9HtXohAS9_dQPDqt1XEnqm0mcY8dkVezoiji-j1_HZ6_m5ifUrQPDiyhWsNy-AyVvwDX5rfVowdQ-6v3-0u4NnOETyMJVies3-D5SYUEMbxmr2rP2rWz-MVXjX9dZIFS64zStrBsKAlv2A4RrSjN16JULTCVwun9QmJY3pHICsRogql2IsfxROep3hHXE00VgJF3JQSIGEYvK4PPymPmNj8xqwCckjImKNo0JDN3VNY-unZAfZv3cnDEJXTJZY7pwzj21Psw03bj0lwrmzDDQUgJ6RPRwlNAJsWWlTIwVsMbfBKQYUVqyoka-8yJcMDv9z3vroo5Kx8h7ySObl7NtrWnP5SCDtXA8BDkKuag-3oz7IOSaNS8Wa1pBMoZMPC9r-S_sFBspA588x6YGkEK3QfG_vbqWtbudABByoXbHdtwty1KpxVY73-UpT5ItEiRVy_Yf_zQ7wck4j_k8L0Vy1UkycROBr_YcNqIbnU-yQUqySL53X2UA..'),
('', '1432617697', 'rd0gvffjcih0rjgm3qi19bd1a6', 1, 0, '', 0, 0, '1wjFY6WjR0r1LUFr4NhtcLAZtJD0Wk4aiiupRlZPGmzbjxGQZuBd-MEKKE9JT2fKbtRT1Svtc1bBPG_jLrjdxOYPfMYp9DT5WizJxyDmTnyKAUQQKfLfofhDUQxBZ_VMf7g9y1F35CjrRTVLUOXfcudhICsEPK_UUkqCBlGao4k2TTpBFXL3Fyu6mXZfJOrmr5btgIM-V1VqJBSiaDBkaowPV5BIVm8Y1nc8_otbpCZr0Esg2QtTcOILWUSN8yix2cyiVN3mqsp2jFsxZANUiwy-jTvO7U6PND0jw-k83LLnMCE2A4RSTZ9rGK7AL0lS9KeqpUthvyVRbNNwoZN7dsqYOi00JcstNzYveS2Hwo58TDKUT5k_GKTH2MMPOEBskgl_LTUlcLGDUWm2x45CFadHf8ERSRaJXKGzj5OJ28Mnp4G4d7URlFZ_iIFuweFNksT1LJQmMmAt0k0IeV7aRfOIySL9uVkVtN-tnrDuoAiHFn5eFlGCgjHv2X7Ze73BjlT8xt1HCMoDmTTD02DnoOR_qUCGJyMnrr8Ijcd4Zl1tDtA-Gansqr-uZ8fHrmZLMs7f_ovATDZ9Gz5YVswhk2kHjARP2zuHVJCX1O8bH2TnGaGyaXj0j1GW-8PSHQUejlx8i_R9xvDi2WiUfN8OtlzHwgwkInDe7ZRTc8DRIMiqXpbLSP_eSz5ImbYNmGiVDNM35g6__zJ59QJhFptAaRHFHCQSMdywcFJB4FbGVpcdgpUvy3IWhHksfBna26WdlTpHD88BGNkVgybIPIf4Dlrd9RiiDxa8wN5VDZp-rmxunQfvWFGm5XzJ2Z0KG-QGphvpAS29ttahHKRg81DBSylmDx5SN4lOZyORhH7BUYsCODuFYk1nPdeULW5t24TbBK4dSi6Z7KS1DuUbAF_kQZhbVa-JXatL1h80_toYaNyP0N_rQYMZjw96VHpIXRpUJ_ointYWPb-KNzvbW-Q7WOK8zlmjhRv0cyZiq9S7zfb_H-_KZ2OcYXsuVOWhOhk07wBr59F4n8hn283VX6pk8Mdf8Z5wnmx9GxFXluAnVJmtW-sJvgCKR5ll1uYhlQrpfseT6xEiacw_PB3VoQb2aDCrJtr_OTQrIAHva8Qyv8CWo8y3j0D81kTPKkKwhsK76KI1Uxjj05P7LC2duuOTYrTf85dCZm3lmkv3c-GMGx3PyMZzqP7JQmX8uT5Euf0SOJt6mlsxcY6tVoXxgbX71G_zExvYlk1szz4Abwk0IpxpNpwrHnmhzUsieouCW6_ZqCArEMf0BSe4Y5O1nm0t-230UtTrCXm2F7EuIEYa31--s7U8NYWI2yFhq3J3RCadtqVpUQOzdyCRt-9CQAj9HPzvhX01UvesjjbpQBFq_so4FzTxCIR4sCwD2snb0PMYAh8sqYIk1vthSoKJVKEvVJN1vy1FXUCmtODARQn6WXiW3gLMythxpChgFtq7pV9TQLw0gH3jZqjXJTc1MiXaqA..'),
('', '1432618415', 'g62jegmtfoji9p42214rv8mbc3', 1, 0, '', 0, 0, '1vemztJXFvad04b65GTwzao57IUvaU8EIL8nR0qKWMPGkcNWaZ5qfw0DrIBap5OxRT_DRHS05R287lMZIZaCKvb6i7_QApG0UbvbprOK5tQDO-asyEYDDqbPQS-BWzDSNHdKhkQYvncMt6cpVZ7KUKRD3xf6YWCvr70CKajuOt4xuVMe3ecRgJ1ykh0xoLKpNnysrLpsg_JMzmzb1mIr2oSuETCpSw9-5MgHoRaNeIzuJeHH41VZc711FhHzyWPXs-sDUuO1AKdaGUO-hZtFzcu1yn0bz70Pq9fjfTv8a4Upu4g8e_pDDMnX6YXdklCnWrh-HGv0mFmN3ejen3sDItvGJ9QgUAqGDWbJTJ1QsP8ZS3rW5y4ulNgOXxFA5I4LcG9P8Tf-lvzmn8r6GVe4uDBwAEzydReOkdYv77o6Zx_plpq26yk8Tj550hbDMXdTVVCCt-EjRMW2QQEztOSagNOp490zqs-oIJlHiSWpycbLP5AT1-KIzM88muVFMPubbwc1FWgQ7CofbOpPlmxPHN_OGgwbERSduQ85qA-zkVVDs7Ix7uxk5vhMEN-lr-hWRhmTaBbZ8c2ZNTO1AlQ-Zycoi1Maj3j7KOt_OqJh5mHGirBwym2HRj13-Y_HcnP8ZYn81Iig6G27BGW7kWMlAh9c70h--BiDagZUL_D51PufDbjs11qNEFOj6A8LmStjRqeKyyHXLw83nS4WodkKs9DW8wBb6kuGLB97dezNjDsxsKw3sh_OVz_zOk5EIBlotS5VZyr0NNC2ILuVyUneXP3xP3lzC3nU3cwSxKsy2eUQ-ZzsDpk8n-6a8cFSpSwbveyoixALI4GaDYB0cxLSqFaiOw4wuWb_lwyflyWZdVvT5VXsOOC7oeSV42C2r4JiDq7P_QZqhmy2ckL6OFKAPfEj6-N3gtG--BU2zTACmjFbjyp2zlaeHvBqTjU0oLFeKgJLuO1muJoBtWqvogKDeWI_nMCuqU1LWL7-WxIsSwMNNPb3lok23y9H7FEVHEtowjBV15UfYD3ugMPTpnWj8EiDGIIwFpNXMTixgWi9AILjWB7yfwQ1YFAA78VMr1pQB7Nxc8uk4TepG6B9F407xA4HjVnOPY0quGuXMtNLNt8YofYt7cOwf7E-f5lE5Y2V2Nsx1JlqeUiL24KKa7X5zll_z5EJ3_oVkKiwYSymfbk60DGjlhfx8MjlP4QcHfXHm5KhRxs_RZMaFBtz_rpVEi1y4sTQRvOPvQ9xe_N1FoBuu0ROt1-CTIG2rtqd8U_X9gxJch-Im-9v7-WUT0FQI-iM3Q_Zlz9E4jmpqw030nSCYsylLkjMd4Eir-bCtVTfsC-s3v3YyTYEHZSprSgpMF6JtAnIFkvo5OaqzyCcqHNeMMSwgFlitvXJWEH0_ME10peGhrzsyiQR1g2CR8ijBluV37lzyJZUelIYI_ZcYm886O3SXM2zW1faiyxHgzPsfUDLz2qi692XqpvsRVIZSQ..'),
('', '1432619463', 'nort1feb2cm3oupncv13prphk1', 1, 0, '', 0, 0, 'eTooZ8loW_BV9vCBBT8sALx5Em2xV6XxvZpGDcsnMIdaNjvM-xZgFZeyh71GehLYoS9XLrXF40vCjXtbK0y7sdPqJg0U6njXHCJMnErzsE3ZQeulZ5kJsqRX96MZ4PkjDsj5qMmtX519r_wrxFSuPsERN97ZuTkHpb9g35GiUPIK01nGMAX9vVi1WxC05oLNQt7qE4KMAfzKrPswZh1xmE-JNaziGez6md-ja0fPDZv7DUqvW-3Fsh9IMRq9ZqAtelhxegYTrWW3i-A3-rCS3vEOk1O4D1kMWzDuaD0zi5T6NoExhbXkdZAO0pc7EY_KApeR8FMB-bOAGWagdlx2qvVCSKAfMnDnIzvjXYAtMJmoqBjhyS0GqnUunN3p_1XAP_RK0MoWnchrCWY_BDf0pt445vgSLp0qUKnxtUXmlPaZRIAjXCe0huiZn_60LEIf36tK9-_3n3AqW8nNxM9mMU1VPcwVl5XR2ZycsU46DoBhRSsyJQeWxCxV7yhxwXT5GnNcmTQY3-AzGCjciblmuCSI-Ta3YQmuFGRnXzOXT6CZZ_wo6hB5Yu2dAmnjG0mJgNUacMu9A4nBvdS_SMF99odSFJO9C1hbhgDi1_nkX4SMZj1Amqd8gOkHHq3b3atGYdrpa0L4m4JQkJRsbm8OTClTw-FejpMlTO-u7Gl3WuD9VhowtTULvvaHfMYBgKmR17yRW4ZcDy8bU54B2ik81UeksbbLX3t9PAF9ymaSpVrjlCbdC9qR61j3S7ivjSgj7CH5b_msysb2x1FOZehBxfVWvDSFiW5cl1tgSfn__QMs3F5mqrzTVvImPEpl0ySRRh8HeVAsCEI1_JQ-AKpJg3gh8GARER-75Ds7PPrBU1qZ-WaGRIxrloDAWJOIqcB2A8TiQ6LPkgXWLSPlVGZruHqbR5xZAQ8Izl0mJvYt-tib34V0iX-RRGT12TcuiS2w6vNhulGMpjiNOIUyZHlFpaokoaVMcSqj2L5FntzBKzeU5yYu6WBucHQ9FVmvr6H6kh-0yqKidisZEhGLLWCuPWODRcfta5kwOtlCIP_jnZmTNe-GXQv5duCG8CyWYv1A6GGW0cmlxzRHo0wRWEltlEhsrdPqdQ3_fFRdfKXE7bZOKzkXrtkbx89w_WrHtGEWp8C4q7Ejn0DC5snWRsS3W6oEtvPiF94l8yk4Pc8UR_CQ4I-Xw7fSMm_vdt1-ALP65TGcQWTwGgI5Cxx0s8ju1P9EV3OOFL-ceaAO16oQ_IkaI5zQlMowcY34cpjjQ00iU44gPbo0cWcvYP_aBv-1lVbqI2nNi41TFtlNoSa7Y1dYpg6RgqBOBpKi3bVWUly-21yGUS7JrYyBwPQUjt181T6Tna-c91rf2rFz-2Mo644RANNLuCsLb8lcQ9_EZqaqrC5lqNk7mDJ39pq57MWAEUH-nC7YE2MQnw2pGmFmiXKcO0ZnkUl4djRQ8dqVoFR8QuoASXidVaVVmHYS02mf0Q..'),
('', '1432618948', '5i268k9rbq5i9o0e9un5pgvdr4', 1, 0, '', 0, 0, 'zPEzSlchUpT__pZdUQ3NNOF0opTK46MOiBSixNWd2Nzgv9bhSLgtxIc4hu9u4hf7mSj9IxpCE2In8lsFkeT00FK6PVH_KzMoapo-evbNEkBrsAARAyzMRmBxFk-kzZohidD33CPkxt7zZVEKQP3Rez9GGu9eQ9_AOv90of56KwtxF7_uDhUz_4WbYsGtLNCkyZEYWhuftY9QNRgLUQ3AX0MjyHI9AJOF8cXAHR2klAa38Ru8Iessbhd2N3jEUxAuKaxje03t90bXhaqFOMkgkmhENwR3tK-oCQaJPIWa-B2-7exNwmg9U27XHEp9Lm5EONaLEkhzOdUqt84ZDgT8iLj9QQdmI_cglReCQDVdJUawg-KuaEOvCYqFa3E6p5oLO9hwNv0-NlLA0s4LJprQ6siOi7FXvNYFaMMJc7SZaf2xsL3ktAGAc_idMHsX6n2YvQmkROtQaaaWXOeW6t8uTEjoa_Z67RDCjfv28ZP1d1Mitn22uMBudlBUUqLKSYqpwZQqnVNqy5k6L_KcWH_CPqIdADnW562akmlmZEtsHKywoqzCuylYrDi-cbNYg3-CM7ReWM9NNbizpLqE8iHJcyNINTX2CcJqs6ZWU77J4BF_R1fcLycHH7FoyHivlvIWDAYGUlA2_NzNoeG-KBPaIpKW6uBGWnNdv9hIgrpeLErAMGeKMYg1iE6uk110aRLGoYnZcXJhGODGVtz86w5RtQmyW_ssqHXAUMbor1T_enrfMp0bPu1SrcjCbJGVc1h3KMPI810LV6U-NvUXM60keHJe7JfL87wRCdLw4dhreIJ5JUlqdn51zHUL8qUO2R50NijHAks4_YY8FTNqUgDpSy-icyyCpMYgdPgKlubrrIrKb9ikaZNZdygX_PesJiDuTZm7-Sf4BbqjU1IrqrXKtu_hJMMS7tZvaDIioYrVirJbqXGgpzIZwAv9FRHwGx1PsCxfBuP0QRTMxlZ1MuFdK3JkXArY-uionlOCjzG96if3ehKkGW8-V5shdcr71vI7O9tePMwQxvTrdn--MWkb9W8JpIeWT9uS8yRyWy1KT72H8McBRqdewDUBtcxBfjlnWwz-KYbtGJbdVu2RFGXsoGdkeTwqmLx9XizyQdJ6m04kP6vKxD3QApz5570bB_xptcjTJ_je5DxbGCqtm9hAvGpSrlLbznyRke_wmlw7j5cM72LiqFBOB5obAEPjn11mamKlRneoJy9rSzN1YzpHbwr65MOyIiubLnxYNFYJp-UH3b8b1Q2zHWFV9MLaceCllDhgrZ9tNjqfQ3bTmiwmuyG_QiwQj9DVJ3tMjlOVsPTpBwx1b1J5IfdyXEnc2qI3-QiKXIR00m-IsP2CEc7PDPhgHldAgbkYKTM7aOCf9yVujHuntkyxceDjhx6wmiLFo-xWd8mmYzYzejORnKMdgQv4YzcN8unr7zmVTBV1yWsLRj4c46aU8BHudGolJa3nwhMZcZFFD7WGnfX_7I2qJQ..'),
('', '1432619957', '7s5g3mepmt34fme53bc31acjr6', 1, 0, '', 0, 0, 'SjeW90W1Y8A5DKqdOvD_iURBvVO0v6NuQpFHL166feMYqu7KDYtlYhB7ZG6pcuMcwzj1vTE-nAWmJz13i1vkE348ZjlUXZUzlLSRMqEOaWTp5s-KtkwOMAN98LFVamwnPN9d5IxmdCheGHW-HzEFo7V6Frt35YhgSS_oJ9rTn0PCczB8-mOPY5gC3pUTKmhGoEA-XCCTR21cVa1AjhzSJPPEmA7cRbiOz3kqrlBQeMMQIqu0wNgor4UFKQiB1l0TxeiCL5DYq3SGT9Fh7tMFWWf8kPq3NLxJkGxOrPtcj3imEZqtiWle0f3Ob380tX7gcEoN656oPq2t_82uGTn5kdSEk-8m8arZpkchRb5JRw7XdgU4m5i3uZM8vv3kPC8BgYsU87CobQFLifHzhHOTVnKV_SiJb2TPid54hHjGiykkpAZ0apk6EQLcqtZJVVJXvBv78nmOcQUd5joUhsJvWqpbes2uHjcVF86s_u7ci9sb4PtGCExkzmzk7aCLAC-11_TNQIh6JLHT8Ig5k-DQMhp-BLuS9oaILhE8Ic0ys-jdMkToZ_MgEgPymUXzbCi4GrxkWDXUXBYxHNe5CGpqlEJ1mJhE4Mz8GfuqYQ_5b_VkttXWS3nOYFRDVEAXLw7GVP9zlYuHwgO6Ow_dK6p79gKr97lNb2khqFF3M44L0JoduNj0swhSSiL_K7VTWNkQJqJjCnpvQaEdmcpxWLwXrPlNFEWJ7D_tSoz96evR8Cy2xcTCmM_UG254B3XZpDvJtIbLWEK007w-Hk2Rjlaj_BnP33W0W1TvDZzZ_XjII4VyTqk7A1Cu3rOSlL76sb9zSWtt2jXEhDyErZN9ZGP5tRnsCgdFJcFc9uvGfEpYZ0CHW5WIN5QxRpcOr8e1NmhY96qdD2w7W_TPP9mTr86VEiQWYSKk50Cy8GG6jwQ_gzMOOz53Cy67iH07u0y-XYCKRv5glsY6biZpM2ej_B02g5AiL_xOp_gS-H6ZSPnRKROvLLiHq8o-BPZ_uOFd1-YZN0Z8yTPQhXJUn5glirzBSWkndti9CuK0DBkdc56WHu7NHX5QvnR5pxG2vJTUWoZkD3tJ0Rt5UDvHAbJTnQZMzhmbPSndeQhvsCWF8PEClYRXP-S-YyohpSXMpJgsTOM4ZiyZd7bxZlB3tN8TW_TIMwkKAxrpa785GitAm5bH3_ssAt0e-qfu2_0epq6tUZqkhddwic3NU1wG4583fV8sfjBNlYqFKGjUyGHcbJqbUWvZyv4VKXnepNmTs8kb6glY46DzcN2tb1QVpiEdqzJwWOjmpPLqsVtk0At5t-zJuTNohCOGWfulWZn4cqAlGewAZ9NlKTG-Ade4_HDwvwgqJ6fYdFajtPsTu5vmHSk3l5BI3jri5YPIP_qWUlLcHvC2Q6lMWQGqvSL6G-ylF5TE56cZ5Iha-FAr671j8MPqTrYPz1Rk6qEHO3oo-OZ_cgV_K_j_bSrJNPpzarTaKbfGjg..'),
('', '1432629191', 'lgie6qcc1q98kgkjhd9bac44s7', 1, 0, '', 0, 0, 'E5B1ko_6AzE3nFuyY-c1gK_Ja5x1bvobAW4ShE-3f1cJ1DmJV8RId7HwbNDRXaBgyAJKo-UeMzsB5jWYLkDr86izr4PZFp1C0BpWATkSITTxsiiNWGjhs2txDazUQn14ggHATeJB6ICFtL5QSptbsZbH1m7gmqqiunyQNO0oZDSP1GJb8ek4a0yIR8TlmOmjVn32xfWpy6cj7yqF_xWEH1nMCp2GsPZbw4S3Ckq6gUmcTLlXjY9Zxf5v0_7mYjP1mSWvxWmRkP9WiBV3sGkYlbu-zwV8mUYnTzvrGSvJWtkJTinrNnxORbzYiBFKLTM0d0W7iM2uMudVNlwD9vJxdtoeU9tkGhjEO5dCq5lpBxI17CvWGnK9D0Zdf5iqs8MDcvgpY2aQurMsINVxBMjitycAmKZyAJej8Zzel4PNMAQKkOG_V2iMmdW5C8ZujjJ9axI6uxqBLNlzrfqfTr1xy57TXJ2nZL7sPVVpPUc242LHRKZlzjcUG3vUcz1C6jOCFwVsQIm10Z-OE8BvoFd-4BFrb3NW-jlL5N8ugoA2ojN2nJwcLmxS1Z5t8wmQFcl8LXpYHWrjGvLl5qd8fpU_PMKQUG8Z4gbdeyWNf3IKSQ9O6ohX0B_bBBHp0CgHShT7KnnlyIRha82JA0XIvzdrEUu-6P_zqJFZIyVYW5U-lUhX98512HauVmNa5ClRYZU1KroiTz2EHeX4qyJWJqC4qIEcXdMsrC68nXSG_APLbCmJXRq4mcrzqyZvu5eilsOI82gmQH9VeocKK2Ym0fGpxxGcb48jXZBySxFlnr4mWl3yYWT_SY45_yCbMNSA9UcESL0TeHpkVnNsO3NKA2a8BRPYnGntJIxofmyVRMys99bmNkBTMT3taoTqzu6MdsViPRWmbp1sDFFxR0RzQ1NYY9EZ78g8HxtNkKI-r88c9oui3oz-smA9BxyqxzILPCDgBjTXn7jFumxLf7GmLr-txptXJT8GNo9zkeKes2CXXwW1i5lRE6ax28h_894J7S5W-tZ8T8tYPMD7INe6nDgv-edPbkUNZUix7gvzxEBunpuz936We-83ZRbj3_4WhYF4B9PCiuOoTbo4MHGf94RR0gZKHnRPESIm1mTHJqp8k4nEJvUk-eTNEycVmAtZg_tA_4kbDNYPhsdXc5fUqlvAFhmPwILcTRhJPB1eOO6mCGl4EWNdQA1n209duOq-t8u9F1966aaW4fEPOFoUZZoDnaQAg22olq65rxBLZ2mwFZbbMP4_6M4yA4hch0EeIOUzgXuNiDIr6nqPtcz8T836itF0-ZSYA5iGBaCs3hIlVNuuZHu0X80X5H3pDdo6TuuaEXvJRU6w-35IGG5t_81iM-lY-jZrgyRQwqWE-ZqFsbMQARBAMPdU2308jie1fouYC-B_lYrDoCpF596HLn-vDgmUd0iGpl6DoBNq1DWdiFcuOqi49UAHXrf3yHLUVinv8tFC4bREOxWGUFctsOSPEA..'),
('', '1432629392', 'csmu7f1h9al1vnjfmndc7q80p7', 1, 0, '', 0, 0, 'tpJrmvscUFvGsKJTa_rg4JEZfxXCJgNRM5O1zDCaHynZIS1s1ugAebp1Wh83oeGH3dwL39METB3NRDZsvDtJHrLJWZ9aKDN8rST5VLbkpd786MaMbPFBuFSbj-_POdtS1ttCVkR_97ME9MFxeDG7YISHHsUvjLY-ldbtccrzXSsUnOMR4_zHV6EIXNhm5N_dkTObWwqhEpLUSHlk5lUeaXFQ52Jete0QXKGfVTLimOaSGFpzv2pCYIc-tAkiGOVyp6U4vhtOhUzYKTVk27_LSDbwNRHYr-4pGC31neg2-a_zYwIU5RNurRqGn9EdoKcOx8BV21AvpNcBX_8yHDmKyaRP3cJBsbEJbI1X6sGsSw2c3u2LH-mH-zdSbrFRFMGk-KifkRwB5zHzss1LyJM0KrgTwi4JwdxPj0iiXvLQXdz_wDlX63hT1PY8IGyIV0YNO-zaQQ5Ah3lMnGiZqAzK_kVBy_HO_UZWZhM7sofAUgcOH8nN4SpJS2KN1hdaq5hUcjn6WLHES2cvEJjYgc1sURx82B-mRRjJpkjkQKmcEl9yM-4U8n08rAqCVj5DgI_mLS4hLVsaBC53rBhXLVnMQ6twFQwSzu6SLlJ_2s5gQL2ez1XVgSs-7LWjfVgHYrPtU-WfUEXREppB222O2eLFUBJiLNO3CC9pcPrD1Aom4P3pr-2EgsgPMkxazPBrNoQV9LcvsvxoXeQWAKRkFHn0A3GqE_5Q8WEFed4He13Ksk9v8Bz3jPZyPpUm6PMt_VRLPtJqfPe2CMhI-se47uDP_jOWG3RdC8F1dDsRe5jnbrjSekBFwEHGgjFbSposPu_R5Vbqh_VeeyBVEEHLZgjoFkozB-yHKf_YwMcGHbSB7npgWyxmwqfjR74TGdoRo8-EX3HmfloFm6tAbCAqUEVRfUpvjindZGctSZ1GTt7Asvnlh2JqfUCZ6CJZ-W0iCuDwKii4uj4FNeIWfo34OP0WhLFGp9uQEVJHIwJHsqlw6ao8Xbw1uBuZtATTSJIU7EZ2xFlNTDVPGaORuf2HVhTiuhl0x7PIjugE8GWpQI7gZ81kzUvagqbe0AaAS_JI_T48bl2t7HjltpAJFVXnmwJWMnzHaEIGacswuwi91RI-JXaC7fYW1V36V_dJsJUWkCuooo82UrYTQRpF-2E4YWdfhEVLjs-XZV9ASUDZmgCRxck_u86GOeIgnRuRjt0V1zFOwhFegi5eLzIKorqTjgSGaZuy-dv6FS3tPwQh8TThR7qYZ5QlawgGq8h1vehdGbwKm6a3cvWu5pUc7vfsqskVTpLdmwfaQSNOd0aOouWmVC2ztckoTLdNHn_hqpcdQigNVpPiEVxSLtyNM-UJzxwuHkmogrLIvvlhem2DkArk97RodPp1uhhooYqy75IXFcdVZFxINDs3qhdUcaYEVof5BqnZP0MncUL3C3Wr39LxrmixqSsgRUJCUn-O3RF4zhYIVmd_Yvo-lsyJ1-zdWJ2chw..'),
('', '1432596020', 'ntashnu6vm9uvoc2iadletefg7', 1, 0, '', 0, 0, 'E7vfwtRJu60STm07B3c11HMbfHpGKjss8I3IPZELAjh4Vyi2TZWRD6PjVWiroUsb-KFp6x8-EpFPhxep_TQL-dbC9DrcStP2sxyPZU0QtSamWl0NhNgpxfTSHzD5ZuvPioPs3G__sMuxiQ4oFCJyUHyXwDcaOxTWQPItFxXR-t4yMgfDm9S_eSWZkrGQ92qtgSvm_DUQPN-NOogrGTEQxRbNorYI7e9LIbSdcpPTcYBPuugNleSpDkkdWmgrp3jc5qYwNl9HfQZBdgPnR1qvcoKlj4iBuRGjDQkX8gCFSQyBDgdhr94N7PWzY3NxarRZWMl6Pyagj-zQS-N30pxN2VjEKUPUQudWP93e6RoUtPEXg7exL0pcdN53Iz5R0uj00qj_NlgU2ZKp75rsnuscgcoxz9CIPfdTCGUR4iAHfPJ1C-b-C0Ec_GlOXGPKYanK3UKkLw086zkO6X4g1GZfMYHMoxtddrTlf0eaI4gzX_c5ZdQ8ADhmGX36FGaSVCzvCVIprJzjvIInUEMRPvJ9ddOAuWQH9zDORxA2DqOFp4yaDk8JyQVKC06AEjtyYI27EBFPLZ-UjpfZCdO1BidYbIOPYjFIFCltpW_ysQC0wZSSm_rzK_-9a8FC58FlUrFQN0nCfigQR5dbQJuIf4Cy5k-KD--IA_P-Qea3WgPy6DtLzPcQG1tk0JYdZJ4kAsWl0uYUhfczzm8wB0By-sst9wCsTUWJEJYkAQWrO4K4n7nISz6dE5VODibuBNA1dU1t7cz1Hr6QZnTdD9UYoENclwR5gH1OJooG32G9PoEzrCdr7FKyFu916skraH9wWs8udOFPwU8BDjzdQ_xD3dYVdFaKtNhk4xTm347hnWto1DR-YASiCQSyhtGhPD-uybjFU7gw_5Iqm4Vq-qMFhEJ9iGSKVDoifoFNBOESyS_rDRsrbwxO-tlUJuHvFlDuf9iq8im-295pZG3bgdPH1kbf8TRHUeWXx7D3yMRZu81wTkefLUcXhjSsDB4oE75p1XhKML8wCQWfMv9yvyTTKg8BlKELbmfiQcvOnQ6T7k-M2g_Kch6lNHaaTPghq7AifQg2qbpNY_AuK_bM8hk9S7hY8x-nVBQdbDX6p6ZzisoK8ObjjciYM9cN08VX2lV92oBq-V4KPbrShFWtmE0g4VOwXKyCa7ajOuuAokI1NEhiVIyeJU-hWKdtquC16BBszV34WUX90L8muEW_3TeRJAaemF9OWz95W5uhx8gbfwjTwI50adfqhsDWnKEnuREHvyfa-b1KkEx9jIUOIfZVSXmUYxB7g8Cgr1bPTcZ2hY4uHFcfJFNGbEKXDB9JKp0W3dhZC_gWzfIRumCQlE6-BswKfZHjQ8fS6rT8Austo8CjT90pmqYY1gQM9DH_nLHmHw0XouMQFotSSlOTytLYyl3ht8pxPufh4IjJoXnDoMQfADKZO3NNzk2qWYkG_e19RblUCCJ7evRYSUigGEFjlWUn2A..'),
('', '1432596057', 'c2pjsqu1pnbcv3fpt6qlfbldt5', 1, 0, '', 0, 0, '1NHUtayfw3T3gkvPWo-QSWXffy5sx72dOjk9FKZWAgaXQsEvwBH8-NPe673_zIz79s2Q_e0aFQOXCBbHXjSFnOSi_0WenQ7AqYYh9nrMaTtO4UKeWo1qefxKhAQn3j8bKeZNEOAKbNoCaq8l_RJTNJkkPnSZjilRgb8Q4VdlwJHR1RAuOOrwKfAa7ohaPwf6RhExgd2gYwunhdv-McIauJ4jROSRPZ0EDTnaH6t81HKkKzocY66wvcbloGIw_3QbQzypZAD_qZYyl8s55mHfNI0SAv64zdY87FpkRwugF-vzl2-RJR2VfDmk0G6TtBGWoIIddgX24pl0lCHNtPpP_-KUWbsTijNEZTHFvI1FKFwKFaREaaiYc3vvuD_TF3Q19bECKV1kRVSUsUAnX3ATpUJxOSDxsbRtjxaz1-wwKvhBXMmBuByIP5_aF2p0x31cuOds3tIU5yqpQ_5Vd3jTx1oFGL3U3hSMYoRF1VlcnqBNylfoqJafyt3VVN-U1oSEOWPoCpWLrffF_66COzQURXe-eq-qsGYp1i8y3yoV-mM6i0gr3JaItjiwIPixH0PEgpTLna7VvyMVNP-yFzu5EMKnLwyU6V1CTItHz23x2vIGyfvNNfRTq_uRxkYXufCRlQusMY9jZGAT4mlHrW2GkNW8Mk0hwtgktLPsMqRtO_rQsm0EzMEtVtRH35d4S6eKYt4Q5dNYOQqPHFhyarEEUXe_gbuCDvu0MDhTIlg8JuJPg9D7dl8x5uaqQ58uaNbl9UzlUhFelPm49rEvAZooDsQH90zTZ1VeAGHcG5E7dF5Vr2pePmlP5-pR3tAsmAOw1ReimzhsBKi1JCuiZ211HVYAquEm062PTf1T0R1el9XG9-Dc-BrZE_k2EWXHh9TdYoJyTwkeiZ08nqtWVwmrdy4PcclzQyXhtUxYZEYHOorMrWFJLhKi4NaqtMCzncTxMyGGOjAgRQnHGjbMLQXR1CCeJ7Wi7Sl7Ruiq1txfhgb0qMom_q5yU7BOVs1nOhIsj45iyPcf2S2Od-oks2C136Fy3KzJFpOCM7BoLT6I4jWMWS8VW8U3Yo_O8tUNm8Ao6b1TwszUsJXBuHA-P4jhRKnq562E0UaDQB-RgoY4bYAm97PVkAhaK0bpH2XXM9lX1NuKH4kS-y7wbYpdXo7Vyu7nmyCA9jMoZnYOLG3psge0X3MUt_esNFvfhW22W1A0jTtDtuHGoorO9fDq3x8cWffPAG9AOO1zdz3qHpX6BQPLP37dxEjdG5eEPz9oGow5gYX2N4lh-MNQe4eaPFawMpjX2c8dO25uRbWLHjvZebISnPu4pDpTU8LzwHF5Kj8pt4rFKDUkuyO7GjyO6bVxsEvWKeOoAdiaNaZXxpz5ef1mTt3pTinZb969ZgMRAGfq9Mh_hzTxzrkKJRi0eheyUwOKv0W6XsYVShaAF15NpSb0d69pr3Bu_McJAxgDekOW4tJMW0ZImaa393-d0PyMNQ..'),
('', '1432596992', 'b16htj40n4me73tfluc4ogq5o7', 1, 0, '', 0, 0, 'nB4WAommkfDCxKkNt1T7NxKQTyWNaZZfXvMmHa9L0DvR4QTb0_CwhLmhQY-8IddQph2DavpF1hn1_dvaqCAjg24M5DdBldek1R97afEEIcqfcXHsqR8_4NZwiLl-sk6gBQ3smVXQDpkFRCbJdLsQwa5HvY-f70CKkPA7d2OS7-VObevBrvWhe-dYlmBfycnIlB2cYMGp5rYvJpoN-Kt3ehHQQfRUKwTB81eMiCoUH2XtUeD7wmPU2p3ztubAacD1NiNUGRiJ4HaFg4jBuMFLXfOIaObAFoxTUq8TulpuJSSHzBMLY-vDLlH4hgMW6MxqHffmy5Q98Q8ySyTFz1ewbsc0BncZdkqQAQNahK1c9VCu78X1tBF_G4m7t-1uKr9-bil_3Mw7EzcoyFjCZZiwlKu2JVsJvDWVdGGcJFv-NYCwB7aaCbeom7zi5jdZ3YPbnUWHFn0_zoy6jyy2pgD5dmpCY33M_rCLep5ESuqyOIwu33WV4mRr4hDeLQrge9IBb336XfzTxBAVNEt8jBnXSej4Y-uP9Z931vCSHYaLG4JLd5R3NeAwDHBmsSCyO0b9xU6W-323PvqPuVJ_189cltlzMLoVnG84_2WxIsxaec_656H0XdxCswZOujXJsood5fOME0coUHMvoiJRFvs-RDbp5_K1OSTELDvUDhyFCoAbl01VNVL4FQX15yff4hW4dxrRfcumKS_WPB_D2JmAxdJ77lu8rWPbtvfUDyd1px1LOyRZmrO7cDbRPBSLrqUiM47qAQW6H3qoQySHPNbhZNi823S1JAZW9vXlOxBEpLB3l4MSJ8Nj_6wA2X9NTBCYfRrY6XMtXsOQR8-vA7N2zaai_PKfDk7Kp3PzFCSi_zCqmczDka04KyGeuN07jTUtE4mjAsdCFwMuhIsQWkKISt_XEuJ3Bjc5KDk1bk4j-18_XU3mKmGuotCmsTR55rZYCPYfDbfFpkE4kgAmX4RLmjchVtGCYGc-gzp5rhLb-hZjNyIdcxlwBWa4d-RfVsHvVtnPKrpCxdBRYxLaZqZNKY4QTfDu52VrJwbgtCINAlQqpmdHTNcSv7msx-f23aSpbwPsRrafIIubWIYIq7e8wW2B3oox8XtJ3L-n3aLUB5TW7ooLtBiI8rwsf9xo0g6LcJZuJEhiGYfL23MKFWtJK3iMFTIGoauMbMZBxMIu67pMF2-CUk1GYIr3EgARZiNwMyFjwCehKdjPNyZe_lfNBaOiC4TqgcyX57GNFI5v1IaAaECCNgrI8pM5iSEqliBwoKeBBM013XhMlXMpLUG1GFNYX9HgyQhODh74w1vOt1jZVU2EyKqYjNqW5QvBUSFU8sRjMSblZ2dXJf32rUw53iWh4qCex4paZtUIWkxyZ2ihBYEnCctk0p7-cc8kq6gvifP7Bj_9Vg5MyRDEVl_9OXzloHV_Pr7tsSjvIqd7ApkzsZ68RdqDv47Ri71_02gQ2kKsMsEHKqe7T7EDkxmkJg..'),
('', '1432597576', 'tqjg5a638g90r7cp6tei3mvfj3', 1, 0, '', 0, 0, 'AqodREEjoCdBrfmBk2pNnMIMzcrPBiIUYrW9hhKfuUhBsxAGj5cR1_x6ZiJRF1jvj_sxxFvb8MmsdPK-eImAFIoLFQA6CP38ohUoNMCVA0Axo3NPdKHsroNSo0Lmcu2E_ay24YOfEqoXan8Lgu-t-dp6xpiFInEJCHGvGecVkeNL_HCNb41U-JYPkriJoA8Hp5COFXz-FXK3OJRMjKu-2mDebuFFjV6tvYrRLjIHYsK2ede5uOF-JvWoBZ7_Xv4LVIUQKG5_-RUn6FtVzRpuAdaqzSi_Lt4oNaWplIEz-GPQgqbG9eNumq02_XmUqlPSDVXLjyKSlBJ4DAeTzdu_kHvMvJ7RvsgHE9CjyioixkIZ6_JXVe9jHa_dvXFTQ-NfHghMhMlDbjQbwUINsRYMwIR3dYnxueAeVdfi4K1yA2Vz6Nc-0JQmT5G66IWIrGrGhJruzPs6HhEkupomBvmDvn0BmsJDsI2mHIKOTH3uu5vHjTXFta5_bMcOqoOMg9Osp-4WHrKZVB7YqGK-mLyjCamBq04UJI9WVZjS15RoGVWXewP7WA2oHr_L2CRYJeDGmu-usSAIS1ZuFRMM0kY1kiZBFqQM8M77LamD_CnCDk4fU4Mg9YlYF-w-OReD6_locP-XGO-Y6cx2K-3QO1tqrMH8WgLLrpRqGrDzTF2EbAsD1gged045wUh4xxMHbDxbhK9NeWM6U_ZQgxsnSrnu0f3gUhWCJDzFjg6w6dfS2kOg0BZF2UxaPLR8W796bhZvitxLFGweZMlQrtdMWruG6J5QPQPsIF9-lS1kZlzzuiM14b06-4GDk9XNM977TJEnbhUoc8en1qcskzf4U8u5nOtpLAISFSfYdebAjXUHvJVImiSwGMVb2SVWfEUhPoUiJpLqtVphhFikXoBefV0MTsVNqiks9tDyUZrfgVWnkyOZsZPyy6_4ofSqDoc_iatJQMkTbxDrH3mEm__ibQs6mL418YTAzSVnmhKxd70NgKhUUasdt87DU69JMXyRaLhaW4yRhsx9Ex515TcjzK5nQjrkuc4MAt02c_DSxvDRrYwXuWo99xCdaVDe4DSygBHVru1l3WEi2UI8QaQt490IQFWrRutFFNoSXbAtsNIRSL9010yvpg-jFMOvurOWDK7Pnh1T1DG1PQnGCjo5fYHP8k84-hcoW3Qy6A9w6pcqFFQmi6paQ4FFDzAIEWx8S-6fQ0RGMX5KjycFJ8DhfCQvS_sRpiVRdm8OnKEZfq3OuRrgbKKuYq6HQXqMiau2GJMiUuTS8Q4cdvcLK3S9j2Xvr-NxOj5BENI5HMGT9nDzQ8a1IlJUCj5q0NB6TAwH1lUkllK1wGZh3oz8hOh3M_h18m0NFVYN9UICkGdCoclsS-ZzBC71tfHinAPFoocSCteaMIb6ZhaObit3yFQw_4QQQe0EMycF0vEM4ToVBz4E4-BWHi11uHuydIY5HUANVuEOyGNEHccn2Qv-3SuXvNaXFw..'),
('', '1432598768', '8b41phokvre4jpp6ju737jrn54', 1, 0, '', 0, 0, '7EZfcl9EQwh-jNkU7un884BfQvBaiG7W8vOAE6P9JXiXd13o9I0OpaQDjaAaVknIWtzOwPkdR_qds67GnnDB6VWGl9CbKo49wtsWNlbSFMyklfgCYFQXpCa19s4b3TqIvjCwOZXBa79_w2HbkzzZZyXZracp1NrWXdAZhh4sW5Dg3gG6EJ-GQuHfSGI7Aud9aZsCuM_yhAfUI1-c1vWRFpl7hx7u-vpl35h8vuIpfUalEbzwIxBqxrKJoWbdAtZyzkD-GsVeJ7JjK54YN3YOqmnWpG8MxuvZLcDfrehd2ZNtjZlSPYw4FoSxA4Dm_iWOvKdujx8Aa__YRsSIIHSoEstvHS2C-uE6BzgeJnTddKU305hDAULdHWjaIruksHdbaABxTFCcAZX0Bs1pshZHeetb4luyuJAbdLqOIGG3B5mNp-lVy-Wov13Yyxljs6QcF18IGueNPtHm5un9oi4ZnVyVDpq4mVodiNIAT8se4siTpkHmMB70sxAzLujbV0G3ZWu-WVStXktQvoQWNJX3CcpoOFk5l2ErGjNpPKpPij5jEddL8XMIXxiBMI-3nVNCE6qIEJo8A2vC65ybMidGBgvCu2GdHgkkPxZ1Sapc91XT35bQlwl0vOiRxlLjHWfs9qkc09nZh601BIDn8EIxF_0WqwC_yt3NSJcTv2-VnM6BfYnJLJ03HbQoHJ22mbrIMurChT-M4BsnFGM-Hmw8uNDpnnaJqr-VqsHtnHxrDK0fr0xsuXx6t1nrcQoL9n9XiSFq7dj3oR-IEHdSHCc9V5T8yw9vot-5eBmAZNS5fxq6TO6vtoEBuV3W_eBbYkTvbJ4tmUd9eki7T1NFBJKxQ1fN6Ga80inCZfc0OYPul6OWDs6lL1et_V37N1smSCTHOFL7zE18cMdgvLnj6iQ9SqTrfbxCDRaYfMXn-iRckw1SbAAIJ0CIn7IDqe8m6Vp5LF4jlySMd0t8bwHilCvTO-ANvS6nXsbvHeHab2gTavklzBURG9odAs_SkFKEe_9zB0Lw10TNp9kTjqSEl-bNbiYmjb7UT738Bob0WSG24Qy8dZd5IRBGaHlEtEvZmUn7eR_i2lluu5syUNfZOkeNYAQRdaOjhdvPkdeHtcbUS_3sh4hkcC28Zpxs0YBmSsplQ0h_qrYkAJUbfYAaQOcfcHZ9KiEeVNO7drc-hn0fLlLqsJddEdyQZMMh-K_Zsg_ZmEz14_H7FLAWw2P_LcCEz9qCIN7cj5_L_Q7JUpTrHREVzQ9lUbkoTkGfu5W6kwfaCGgranvibEB7JdzP2ybNJWozQP4ZqX1WWWYCRwS85-AIYmzhsP5I-F52BDKEUjVjemGrgmaVwWA1AgmMCx9-IRz_0n9KIk2FNHwBBTENlmeDMYKMRME7JprOBLkbNcFL6KAdB5siAq_eS2SvVuagt1YTIkMLnQOQnYosSvMqHUp1bLF5bf5Tm1cxaba9kWybigiXyXy8nJMBvEkv0896gw..'),
('', '1432600909', '84flfuel8e4eqktghcae287gm3', 1, 0, '', 0, 0, 'LpxvjyOx4cHGZ6pf0mwz1oDJgDgta3gutWgtRevEuApbabxs5vIJZcMN4jUVn2QtLhpX0jGUUDvRwu_hcx6GxcDlUPwfA8Um4sUcX8G7B2wTI8toU2dGXZPYggQTTeHd_Y_PaJ2QdtE4d1KMSAoN5t_kveDrLRe6ztuL47nai0pwJZT91umgrkehzQ43jJM5AgMnWPYu9tk72fpWilGOrCbDOidEuolivssAAX5h3dhDZtm4-KA3PWn69uZEJQsJnau3MNGKyH42PxsHla-zadxJ1Lic3lpReMXPLeFQ6rN0Xs_x03uXEA4pUAhQHiqRWXIlrfrBTHtbnV5z0t9vMzff-j3JTnh-tS-QkX5kUWUaBV4xR4Ot5T-5f-AMq9RhAazMaTGfIzLmF4o6tx5Rn-3YcaBQN5ZVUGcmOT-l1AvXTjUksbxT9MECVETWzwE6n9aNiFJrUhUhgcii4d5G2pXudjhNVb1Tq5S8ZUoJwptnmfnM2SDFUNqJgvDFJRhcZf5sNXWEOgrRZp34ZoHvIv9Qr7qVxV2IgbspwBs4n7FtlBC1SY3-YwlppgOAtsyVOZYiIftMkjupiG__F-CQxhIFhDYJWGLWfbtrnKCpoW3B0udrmNCkuGR6vrIvxfipWitkSLhBVrfM2Jmyt_R26mmzzKiP_EAJ-f_wv571Ga_wfVssF90Ghdsg4w1mvWykkxyDtXKkIgV6Nsa0eLKoS3-i_x8TTmHa1dtLWRo2HFSGAIoBUfM95A1eiKopkb1BVWFuNVBtNDuMlFvhc9mo2WRP1OD9SW5MjuZZZ5UMMD2WSWa4fQUfSQyZ_H3J8qA2uikUhCtXAV77Ny1ses53UJZqyL1AKsd0ZvlO-Q87CnZrTpgQwpdPyhy_THIqSB8QJ2uvxM_6h-zCvROswOZixWjbz53OaEEe1u5V31_H8HpTgqsmmxf2krmwEJttCwowso3XZhhvsBcD5C5ORebncQdfX8Kase55mTBwTVxVXVxdQzi6IM4dr51ytt_4WexJRDe9OlMmGjUHeZdn3NLPMLnnM7BYUXkPALSA11lhFIFq9xkkOQwQTJ79Z9dGrhDY4l8-oKttrUnr3Lq6bEF6T1Ll3mH8ACbDc5WeiK8kCZRNJFr6vkEgAmIhYwP0130SBQMr0pZj9nvQgOEz-2gUWrLHJUC-gYqKmABmQn6B5RcJg6Xr3AbdyflTOF_FLbtTEE1wA3by6TlFJMSMheKMqzqGSYjFtReq57nypfascwo9ocASOUw8i6vGTKGNfAIj-z2oc_DwmIIvAraQUU4JbYJtR58WYmUehiw495lKVCcGJn7m1eJxzjeS4ys20YnvkAOC3fHeaGcPht3w8iZh8Js3t2VXFY_AK6IAA9FQU7V8Vj5HnRgL4l-Ykx302B-F31TExg3bCS7av7iXZpoKE580FDTrdp8mhEK2tmDvCWJdu4euelj28vzkX_hxm52MZqbHyC-HJdobOkT1AeiCBA..'),
('', '1432602896', '3bdmf49fmomc2e8abcg2jd7ar7', 1, 0, '', 0, 0, '3tZ7CbNHzkLXJ5WxAoeReqWqNY8MGpKJapA6auJQkOt-mTs96aJmVVLyQcYgenmNB1bw9zXUs5XZm407BBTxmi2k6Db_iPc_WI5MdLzo71eM-efDkevJ_RBAZH49kZHYzS0kxjY00OMaVG8h-mq4SAi2GUNSNwIZiUwX4b09YIGMYwDUW-qAMTJL4kl-rS9mqTE7NGOFvUcutatOOgK5jj_fB-w26esd0qZPP4snysUEW1WskSvubNFQqHn9zH9v5vNLXfUXVvBzj473zIxWsQTco_mOzCDB2rhbBUGEbxuxdW1tLXYOq0i-3j8PukFxV112qlvSjOH1NalQ1APcVUoyC2W753-gzl13Fy8Bm0gyLO3d5YANIZHYXvyMjH_4wc7uPldsarEI5w-cA-gD02EXyj98JREfURQZ1EhWSgq5fUqyphyQTPGb1SyiLn0n4av4plOLns7eV1HA56C6TR6FDAHI-JjI6oNtRoXxO9HeSpTBpQVhlw8o93dUZBmkUhn8SuXjUUmvfmonkj6vxlVEgQTi2t7SP6HSzidnnkQH2QOifQpopBLV_gO8qwWKSDcENFWEV15a_EqRPI_FSOAAXcnIu6zM1A20r-aWASFaOeI87hugXecO7NUb03tm6o2Ph3ZcT1o22ieYYljaiNZnf7bIzOUUveD0--ZkV-q_V5CG0yOw1MFKhebWYuQvS4A1N7bIrwMvhcXJP448lWlLehWhmrNIHNYQkY4jPPctgroJ2uPUOVVZNFPK8jm4krakzahUpB_3qa1PgZp5GmoC6WA9aJYLtQma2kbz-8aHFJRS6W96_Znu3LV11Yt-W4sj_i0raDTq7XC7HA8dabidm-krsiG1YH-ntEs5zPACNRWp9pGMgHmzJpzoOglGwzCQRHzfvCd2hPMSsDm9ImhITzPTf69Fld5XJVi1XIoSgiCTCF_U2JJ2RCdZ0HBqSxcPGE1K-AKB_IFWWeamC9vNocZop_Vf8DMw0mxvj-XuTiHf5qSm-fVBB0pTVnGQMJMMB-Xx01cXXYeOR6PzUFg8wPsDtIvYTLIP45gAcGtNa8EL1U4fsR6eJQv9DiiH94T1j8-wYQvlQyP53-_kamrByQwfLvX8uFnZbnV-6GIcZGl18bQW20ZpJ9YFgL2Ck2aDcGMjhIYaej8HE3EfIuYKo4Tp655DSthZxT2fOP78ZbPyocYf4fiBoH_I-z9jzobMGx_09lq38n3uaj2XY82TQCKbp5pYhSbznCULaLaB9tfZzRDBI52yyIkPWufKoaFJLWiuvT3pZ6CRzDKVfY0Q25RiNOQFRRyEn20Qq6YVwlCRK_Tci0V6a9axBDft3jhx5Nb1yeqEtAdM4hegLaWS7aLYkkQPu5TEQ32njVOcrcDXCpXwojX2nnh_3IyRrrNeXa5hs9fHEeq6lARRz8sK2M_xqq4xGXpK14KxP3VvhFEJDK_2wpmlFRyRvL2EoXxTx-_qsByv0ikSVX8B63rRi--5TJDEj6f3yi4lwjQxU5Ftd50aj7YPoHbnjFQh-w-Yjoz_80UNxzd8MLT3XA..'),
('', '1432602847', '50nnr4nbp284hpok4jq9cag5o0', 1, 0, '', 0, 0, 'mIjnFQXEMlDwu4mfVnIrWUhR1iCv8iZwfeIVfp5m4P77-1gv1G3hYYORvytzgl0samiBUJNFmwct4UBuXgiiWWpCAjgK0b1wYgDNd4ZakiM8IVX2iLB8whFL6ZDezWEi14j7m_h-9aS1k87TzDlsOReGNbYhDk6MJ3gXx5_dasTJbcPS6-xl8oikYJWgM891dlXRMWaK4OkjytY9hP48nKPtQoZuQ9WjxuIOLhKjGEytQtVuCNY6nUaJcUBq9IM7Zi6yCNMVQRKVXSjgKCMyVnQgpx3R6ZDfTdqJ1xhR4Fv2lYQI6Vn_4yuwFaPs5_L6hLs3xm5SrlR5-7cAV6f4JkZ3ZcdzAojxRoIV-7PxkAsJss2P4H3XlPY3TEFDrSrXgwko6kmz08n_TfElQyPfx97T_2bAQwmbHwYcughS8cfVlWEH-GA9QqIfpjmHQahAdyE8AqFOLMC5Ew2J2Jw0eGVgOg3HrABlG0e6Mm6nv1bBsLM7b_K0lKR-Tr5xa4yrDXoMYotXArDOo69ANsnQCTttG85PrSXGbCF27FjC0PaK4O5VXWwdRg42OmF-XBVDOIX4Anwdsi0e_tVCj95ehMWre_jpS43OtNBtNEviYWlKeuN-JyDCZEp4Mhv8l1rB-DO9pwfNEywARji0MZgsDldCMmn6DtDr169uorRehOu2G0RzpxlUOcTwHD1sCG1e8lbc8eIv3fg2yzw3tfHUL7wMUW0jPMBYFcxp0kk5KQB-bILQP9wNNOWKrYzLLBgOPUUouQwBpClIX775NqRCcbAnaEu5B_OwgzTQ0sxjJHCnda2AoOjNhzFd2gau1nnN6A3HOJPkHLwF2vcv2suoAaKr4wsJMkloB_cMnLGtl4Z3oex2jkxxjSnXyBvEshZbR7OB-jDutCCkyrPEmKIeB4dXFcHAOecKrzv_RVcIAwZNirEE7wW6NecdbYT7P8C5bP1G6xgZ2sQxHRVODDpfTgHgjCP62i9_RlGkF0blEc2GzIHrBPw_Ih0mQuSsRn2kxEtlc0GqD-1lyAM8HwPnd-0aiko97NgdXcgW7hLz51A7T6GD7CyS-WEWDDvdnnqdF9z-ydj0mk9wQcKuICqm5-owYJM0vriR-pzXr3iGM4IsBk62LytzeRohVhiJTyTMI27wxg3TbWjrz4Pzjif_hC1TNcIneMGBzD-JPt62Pr1Gcd_6STDBJ0ANeGxLJ00ZceYg7ZuwQNSRWS-KiydFe7C5gr9RjAh63RcOe03GSSzbfcvnI7Ejl1B1tvZc-iRGWuTFcP1tqB8M3Y0fG5D_yUmqaA-TR5j0pvsIpj-2E38ILikJMsXJCOpxVYfhUEd3FQA_mlXbh2OsZmeCtOOsIfdEwyfZ1dPnoDQZi1QyXrGQTiB6bs_lvjH_VwN8DS_nUKZXTXbq0M3HJS1k7OAPLLTeEIqnJyXCOsXvngUAia8mmHzP7mznMzeArn2foXIGQP3WS-rWme09HHN--ahMXA..'),
('', '1432604720', 'n225kh35284k6bqkk4fmu65p21', 1, 0, '', 0, 0, 'Ev7KQHickONN7poOWa1Mwn5v1avEoN2PkedHfFaYCnMKZ_HJvIJaS5KbKyNqVUB-qQnkuPtiGD8awh5PvQQEJnC3_VEoOBEgAAsz4__Zsgjj2YXhvIoQ1rMyNPsxH0oOce0OQx9UaSKsRMeLE76TeAT59I-9X444jKPSzx3JYcUf9I7xmnO1Ug8iWHY75-3qxlUH09llWBXHPdvHNXCi3RZWgj0l-u0gqukxjoGJdRLykDJt6NE3PdK4y6WV9CP3_J_5kt4CXkf3atfddQeaPkX_imRX7SOD9m9iFE3ris_8AmKP80P3cceirS-DCdMBPucqN6VIUcFGLxuNuLi9pi0qr-KJ36PX0x0oYRkAkOH7ITVIvI0Ue0XzpqRbQmeKPaIhw6BqzjxFapYKW7PnZ3tFElS_xKkz1PrRRSY_ZsA3mTtfIsxHGHcrAERf56O9gwoYZQ8_X7FFA3JoSyzIu-yE_xYgIlM3FadeekybrbYhChyR7isXphFW_yUUPhJ2118WLImEv-ex6lB22vERt27C08bH2EYtIQiP7pmsmIUgavDsnIdMET7baLmJRK_PEH11LdTq-YFS85Kr9fHuuet5S7GBSeDUE6Cdue9-Z20oNK95DpnnLabwEImBhmdLik0EzA44a_-2fXLd_96sYV5wBLAucQ6mAkcK30sWluUXElZ-Ns4U86o6IOhBchBYC6-Vpha8O0WxijReNmxugpXFqVs3LqvWNcQyXKtN7bi4RExOcVKEsskqBlIdcGpyVtAncPf0OuqJF1uyZuQeSUcjW1EJprf9bWSSzj5lH6l5DakzvNtaOGw_Zc5ecagZv-Hgmd2aKRm9qTJcA3k9gCVhcYhFh4MbRX6hfI7Yf6E-shjSaY8SCyeS0eBde3pvsrybnT9Q2ilKOJs7zUa6rE1JfyoKdficdydynkYVrxE7xDclrxBlezrhwTw5n9R6aYEIUMDnw2xVgOWeWzXlryqiKA-pJ2NtYicqvVk2zCCJd_K4GXEpwZ7_AsSE-cHVg2TkyOo6UB7TbIcoEUulaKbc2qKxyFtVojDP_lfuf2o-3LuG5D1u5h9cmQz_KsHuYYU1AbefA6MCVdVrp899DTOz9P0yywMG0amF-JkT86M3xPmJvoyvxGNFcd1KhhgJ3a6V0rCGJxdXOaRSO17WfmALbrVsf0u_zUe6eLdSUj2iXoKgpq2FB1sUmEK3zwwjIEimTKHgv3JXpGFnEHxePh3TnmdlvjHHDZB6qS1Xs_s50GyCa9FNAtE0oDh8rKus18WNCQGpSvypLxyRGfoD5FD9SPnUzU33Vzd1Zxj-dAW3_ANwEz0AouAUu_7G_lBv9-YTuINxBfH0iM5WjbN2tGHaoBSeBM3NeqieIn-keRbyKZcfpLrIHwqF09bN6-_WaLPec_Q2pJfG2xR4YA3Ocw..'),
('', '1432604889', 'eosqrcgg7pjn9vq90jvuvnvag2', 1, 0, '', 0, 0, 'IaPMRUSC11qIHdD6AI31tWaIbCcV1NrVJ60fVeUhWEujIx5bV0p7dp8vY5MWQO8KXHVYQ2ArEt2UyK2zyaMWjF2f0OXJKrMl1UgjY26qmJMp0JQ5AIZ-gX3ISDNqK9calrf3G3y6lcCpjf8C0wodlvFij4nPJgUG0e73YxP2Xc7JlKUgWbtFctUFCf_PDlPiWIyUTShlt5moKpv7G8GjjD5uNrqMMw5bgg-v9X2gHVbURDrYzzvQ9giUHwk-ca7LtsjYB4xOsiyN5jlwPSq6F1fhesKNXlth2GdWPeX_cd8HXtXWG-AIzJ4VH7vW61i0dgIboRpw3tRV4Xv3ZNioColR7Y1cdATvxrjW3X7rrZQgCbraf6s5I2BKDKTgaSw7Rr9OYMkVlr5S1rr7szNhqb9i3OJYw-7Afm64jovk93d6uIivm0REufpS57mdyyueLr_BHI9wWmDyAULzNJErK9GbvXUhMSVCSFfJISEeVdsVJIRq2rXZETcpgI3SPuIepYufqpwo75m5yvQQMZW7L6h33Oi4Qc0BE1DjOrCInu6Hc-TalulNxqIvv_626p5sB9mj0ZubxhHHkJOIqlTjl3fiOsiOFXQ3JRws0Fkmus0_BCToojjTv9rBFHVxXDR-biVeV2HUbzf4oYqEvibJxycae78L0JatKUtOdBqHDUrLdw3c68BjRJUhQenjkR0ALj50Yjhnew3TcB6e481ye742U8dntIUk258XxdGYl5VmqIFbh0a1CPAivVqfJjOos4DSKdTNHrE0Yru6OtjZDBRXZJBQKE8UWNtyZ-uOf6MlkHzRea7pEvqD_K4qJpWNZQ5HMNPLdzlXpVQxYy6Xv4JmdlaFSnyTasA6mGNZm1TDo8sVXLOL6COq8SZbmWJ7j30ZVx4W_GwhNfCSE8AmtNeJj75QD55UHIzVB6GpPIgdxcM22ePvVUSr1Iq8uKH4i6N4Ye-cnMpNXE1yuRORahWj5MhTgqXGqt-W1ZarEd5Vy8aQJC04_WMvOaOVT_j8UdPMB3k8WDOiM1NnmJbc0souCYOMftlqT3MM0qXlbqWFWpJTbduX7Xt51g56Y-nWsZ8pZwNymVey_jaD8CXQlXl_ZMcQK1I-FRvtvWWn0Inok5mzajFUd3FL8uKgWnqA9Se_yKCOMKfSDtA8oAzE2XdD-CviSbAuJNyD4r4NQ7U5BSx69L0OsW8cWI39daREbH514Oj2A9_HyZtghdb7lmBW4sl_AY8nOVGyGsD83T3Vd_AHWFSDOXAfzf3V84hkyhjOZcnLtfHd9pbc64gYnJUOcBDSdHWuCX9i4cCg9PYh8-uF19JvYjObDCTuq5UytZh_e0d0FRU7xgW4OWlmlXPvu2_pySYluERFYD0z-F1joj2neZAktsq5QM3mrYnJkHRiBs70_ga8drtkS9xDlQ..'),
('', '1432606292', 'ssfe6e0gde2d5h5g2c0aeao3s1', 1, 0, '', 0, 0, 'F7wS0rRTcvMI0-jQ8P6qtGmprLHUkp3uRWH4g8H4tXCxb7BUJJAFJ35hjGfCr1Ycj8AlKjEwkLIQows_yO7wb41AAjoMJ7MxIdum0zWrplhzPuye4opZaXNg49VOYWwK7An7NRIpkx3mdGiDQ4xoPscNVmjvyITQMnXEcicuM_guyzLbDhg7y068lX6QHjF6FyB6NKxxIt3MRUXgibgtW3QqFsRMMkXc6hE3cOQVuNvng7MsOf5nmEgZN9EJ2aS7sFQLZhrEatJ7i5yWUU48KmbRElBh7uGD75HoPYSSE7xUQZ0gHqQnSiDfaFWN__sNpQrIT0FL53SNUNLT9rWoeNqCFMx-tKcHS0wNdOaiblqcCyP7lOBO0LvJkhGysJwbZPiAAxyECsLALQVOdSIURYjRpQ3uWFqVOrj8QBwbUx1MMwDV_XslGbdkLSZ2Ex-wmQqpobnR_67dUU4xvnOivLyvkZUz7OkGBWdT0YwWZ8YiRkBIdUpoaCTTTxtAVNOi6uKjn5n1EFN_Z5pt3D5XuGr8Y_E7kHNOXgRDr2v5I9Wgt53Lx1ZDkHXuhxJ2FNqrKX50u9yvxCAw8iTPh-9QnfB7GLtSo4ug2D93NilUk5Was6KDIxfC4bxfnr9X_jZNL1j_ZGrTzlDLBBiJ-6NqUvNLI6KiQmcCGVgm9hM7yKjmf7_I0PLtEjswzsMduniWUUSNXPGkDJbcJjeLe77AvAqhcJNgHNhAnDD92P8mfRCCGsRP94UUjqDaPAWnyGf2nkm-O27YQqFt5D4m5g_hjrwqSd1p_CoxpABjQIfIhivrAQdb2e3ARfg-O3IwtpaAyAyJbLnIuAOCHGmjT2v1WHg95hMb3KCszyGwpPiD4Z3IVgHJp7aiLA5KWvTkFXAd9DF_KsqwH54mwL9sl49N0vZqRzCH679ZslbagpRKGJZ8K8QJKHcMbU5HrDE81Ds1LHTmqdFj1L8SNn3eY6BIVJtuHc5YVx3GYAFwfmMT8mFteacEz0c3lzPT_Bz9Nehr7aDXbkFKDWNbMddd__IGQJqLt_TrX6XACjn32y8e68zlzRnzAu9ywStT9JFNN4YXXrOAd0IZkUyiKSnP8c1xiCAMjWpJKBKkqyXkOqMGUDCLZHY8NmljHHYBCHe0-xziAFHHesfh3jvN-7jsVil8KkmFmsIGzFwwZ_C0vDO14Mk4eF_7Cgr5Rln7IdaPtxwRJ0pgq5-QHtAWuneKuMvfTgf4YZWJdGQQypXrb91cIxZ7Hy8abJgVuT4DNs-DCHu689MdckFG8aTIuHybUe3LgTuIxKiG2mG8LfSFiu5EFgfDjnRPDgvfku_gpZnPE2NC2hqyuhUnX-yIdmTE0RNotT7tJdHZ-V22jupdQwccuqvyz-FR6iGgagg0vWJ_5EN3CJa9EgpuL1U94neIT41Ua7FJElYsid4A7-Ku_Ob453vVKn8LJAsUTeGJVlWo50AZ-e_JZxR1YJV5jYqG4UyzBw..'),
('', '1432607406', 'bhb5p2jo7gklokmfgmmnt6t6m0', 1, 0, '', 0, 0, 'ZX8Q_wV0stRyM1lJSo8F5vsGIR9iWkdURwgjs16AEJM521MaxbjkIEVtmFFU5RJd2Y6KzJIXvLqY0FQ4nPRAWasEpPopN72zSxMUgwLI_XJrw288mmyonINaA0wHIZoj1-scRhXB5PYk8lIR5CkGndXzdZXVMb9f74vNsRj67zVw39XjTfTpPTb5BiW85j6PZWbYnfxz5qxn5jZRV7ImJauQtcFoiqV97qZjxKT1IT6T6ggFwNAtc2LbmoCtLraAj286JKUx6od0vun_G9oZxMIZsqgnZ3Cp3bqyZ6kHzCz0v3yONKmoQ0sVxg7srk6qVeREj0dL5ZF6hYNPqEpuIKSuPBXPoLGODR96vcC1lBq7ef73Pi9F8Zt2FXHpeO_2Bavx2hzIB2XSzpu8qHLl8nbQGob6qq2ihtFac8xEPZeu7bUG8EOcZzIaNc7ozoh265mK6cGtukBN9sb0O65ghAzPx190sxK7hnmKJCLzdQxTkm8qt3VSRo_PSrv6vjulYlQvdfZHZ0ajiMh7als0cfX2m_GtkfogUgyIWssl7gMSu8E7Svg5NK1fsHL_T0M2wb36COH_Hp48LZeszQC4QBKh4oPmMdc1dhgwsQLLxn0Rt1QYLP98Xl-7zlnpFkQntq2465fHoEXSh5N9TAe3AXoDrdpoo2Hqm9Kf26-ZznfBKPjYr-n0HtB1CE6VAqz22uklAQ-8Gr0g0CO8uLJHv1qYu8Cy0PEdYFhBOMkqhYbYjx_WHXbgq2764xTzNtXxEFUJO6jzTtfaFIKOl5i7EjEgV_gFqthsO3NTzZ2eJC26wN8nDedcrxtbU6Q-XN-411fc7p6QgWBmSPZ91yWijyiYm9YS8Yuw4zP6HEeOKY_OCadORbO_Ad-ygeC7BlFNcDLXwkM47anSVV1EV8HdDhojSjiRBXXTS5_tW_9sr7LD_oLsnfzE_jZw1QAh75nHN8dojTtVJdfPtFhGR_AG-bSfsNit8Tg58ypSpm4HK8PUXb0hhtkgty9OBmX33NElXAJqoQJ86TtdF1K7pGgyYCTPq1XHXOLnCduWo-m0FAlWJYQF72ecBYy-lJMq05okn4MqfGZ3OGdI_cz5N1lYb_thLTtahP4I4eclVDrgpmsni8iN3osLwuKqGrALUqnijPe3apUY1X_L9us5amE9dRjryZT5o38D6jxrZIoLsTpFdXpV9QO8fJOEuQjtoOq3IthObFhNbRkLyVPnsPywH4sv2p1l3oApK6tYLxrwlyZ5qxZyEBX2GeIcxYULG4vQcZY-yh3qeuF9e28ZBQ1FOB3g-Hq23WJTIKn01JECYr3cmoRNzp0z12vxJPoU7hptd8zLnkE2HKbvAbFnjkErb13n4lEg-0ds2ASv4bFraj0uAaUSB829mjhW-I-9P36zyoMJUFv_VN8py98yNAm-X00gTkOcY6lFMSM-qWa6EEs9x8ghC97zJ9m1gXgTgB6WoZEY3BP2ZbU44J1jTBh3tA..');
INSERT INTO `jos_session` (`username`, `time`, `session_id`, `guest`, `userid`, `usertype`, `gid`, `client_id`, `data`) VALUES
('', '1432608181', '5t03p3u1j5t4mpqe49mfcenev7', 1, 0, '', 0, 0, 'fWs2BSEYHkhGQtOQozMW5F6dH_h78Sxb9r7_LOt7yNwlwVpbSeU_7jFrY9rVC7Kglkt0gC6Ch9NUmpivQ6HpRzNezx43_-Wsqp3yxHXgHxDyjGCoLe0Z7QhMZ07yx7Cg0Wq0T_AJMxnFwxjIB_qEXmv2rfxQjSbMJbKq8Kl2sXB-rfWfbaKAPVXgzmzqmbNLd9i64Md1zldth8OXHR2s40AC8UlQAl4FhoUGqimpO0EdwuwGFi9AiE5JEyl0wJgygzZdjZAFn4Eycd4zOXWUawC0_0TFlxeCNs2_lTe6imoBICCWtuLCtMDXvLLc95oLSqsO4tbhnNEJgfqNdXRimkmhN0CKQad1XsoYgzVv26WDuWEK2UmrLIP2_F8UGPWC9HleiR1yGl-1Q24CWbeeogFJvB94rAw0OM8_pFd9Znv8Nr39l79wZLIlZrtv34-SxXP-FcEo9Oe3_TCxyzs0PSux4rxAeFByGYz8yGPLQCHdHrb-MtKGvqbGqX6kIvD_8F8rO-jk9y3u2C8gfxo2UuNaCoTT7al0NOS2QbRRVjTh0udmpZucxtSfnbBScVLejp0jSbDBeAvZAIPS7Mc0aTbRbjlnOKBicpB0DBUXsbdNmdG7Qs4OkjQZ4XXS6NNdjHyC7ovYGWzEDaVaJW600hPvOD_EtEA-1dK1WIlw-3dkcYTdrGShqP2LncZaiogPhLrMIC1f2yrArxS_P0o4xP2MqoumZaigAYOdAPlTX1NDrUPl8C1ux8LLhHtvOTD_Zf8iTY-XPDuOjSyKy5SBBOV4b_wQk2u9wWbJvyN6nyrItNw2_ayKK0CKbq_BZdsNxxbwXvqBMpF4QU8Rkg-df8ewal6YG9MZOQWL2871J4ENi-PO5eS41GzVM0k-lxa6LK__pA7U4kX2g5EaS8aXtjiBZbADC-HF6dBE26EhdKltwUff632zpYZronqHWFdUJg3qlM2O-X4Wo6m3uHHjrmksLyj7y4VbDnhYPU8KYDgKqyylrygXqY7q-3jsBVU0m6oIyB-25F28hnYCLATQeWKx1jxJYGcPWpcKr-aG1Q_3e89O7U9c8Jo_1rnZjJePilKw6pdluRf-ha_BqCp0wEciUhBKZJyWTfU6HuXB8EV5HCEbj8PMpjoTeDeP59kS_EwMTX1anvu3GIXxIXVx0o9CrnRIC8HqOjXkpTqVUXr8I39aPWRMnrW0tBy7O99ED8Ta1zwUTJryOfbq2unFJ9tPL0XfbUUfwZiG_CAEAebLpkZeFL44E6_FcigF-GHYqGNuA-49bQrItA3462NPEk7ukmMvxeH9b232kBXESBIDVwqTwV5pRxl-bankGTQcLd_lejIURIi046VilLisPN_vkC64xcFq-KsI--qugNR40yynU5nCXRTnSMjbykYlwG48r_0JpsMV5FbPEi9F3VBye1S1wSTdEA08tzgLdpHrYDuNIbzfuGd5v-Kr-DdSCkMuWbSiieUIY0qUD53R0Q..'),
('', '1432609234', '4tkgago47l2564755dm3sgqjc7', 1, 0, '', 0, 0, 'EiWjJoty3yr2T2NTEQZ75qlAhXxSNFWOZq6gVLK2WGugk7MtEMA6tywtfI6kS02Rfht1v9XG68ypdqTFN9UJyQgpvkKeQUUFappOHVO8VL1mH8qp11-pWa8P37zBDPpEOM99gC-Si0RA5IBwCJYfHw6zVMIHHVwIHdY-m625wpExBwsd-KL0G6aQ_ByG0LLtZKWw64furbysWJmPBqcEJ2Tx7gbx69HbZ8kgHXL_VVFH7-r-X39IuqLu6wK6ToxfRj6Z9_JrCE0uPXKZ-L9HRuXXheXPaqxf1aekFpmhY7nBwkv7kXcmo_5lYZcqURBlOGrY_-iCS8ZixPA_v9QR1vT16E3Hk-hEDQKmg4LK4eiUNETygDt1xOby856Fcc5mQSRsY39iBOmPb32cWJQAy3oHs7wuBB3kPZgwcCD7SzF-H0Eq25t07R9lppVLX3bhZev0af3kAM6Q9JRv0w3nSzk2ZD0aNcp3UcqFrXHvZyCsK720Gl9q90sGvue_BKrLTlttmQuY11x8rsn43Z-qJx7Hg8Oa9qrt4zzVAEmoiarXoElSbLSUu8SbiC6MDFmLthzB6IZxn8T00BcP8f09VTsMgyNjzAP5TJuISEWbUZ0nvLo1fzgGaVbWmKl-fZhEhD4qR9LAjah1XzLUiRRx03YPnOZF61xbWMlRUZEbsFTNMK84QJnxGHU4YU47YHRZpaAC5-NNlJzK_erw8DxHKKlNjSVDd5KCr3r8ubih1DJ-t3DWP9IF9DopfF-YuMPT7G7est-u135APD8bFcoK6eWhkPyacwAEKIr9qHDoaNgeYyXq1xCj3ZcfcQ9Ue1UDeqb1ctA2FcMycUvQSOgxKNCPvyAc3ptFoEtr0uiIAjKR-3ik3h4kBn5kUG9mg26ALxO6hMsgBZ0AwIj-hnNOtcUchm7Zk2sAfcU2T96fMP7edYrSc1_vhlE13X1pdsaHQJQGoMNK4RiaabiS39_OAsi8Z14_UbMfi2bhVVx1kI-EbunMLXg5oWWktnJLJlFqtoUp8nsjrNNA8wudn6SRryKn6_6eIR0PG6lDUdViraUN7e7U6XihzKtakQ6V9mN6mVO-uP82G1kt_OTya1gCYX5LuEOVfgKH0Z1syBuc3KruRLSM25-vHi_c74ZEX7i-2sGFGbdqvvBWvEc_W2hfCXDAb3_XoQfPTWHlJnqecIvsRZ5bqmmVZvHNmU6KQJjGXf-uIyg0-H051bk8QzMb--qgFFpW6tPNv9SOlPJI3hlr_IZlk3app7cu_6fioHkvR6A4WmQB4lB53rd52Aov80yjswQRUTmtFeZ3N83M4N1JUEbtm_Brf0ifnxlmb7NNk2QdOBwmHA_iC2c5M9gEidoAhZcrNn8kX33SNeFh1rFtZurpv63oYukoWzT0TQ6wu5oKVWiFmhO34V16uSGHntEw6H-_6w-BEHbkJrSYSDGFpy6TATG71Hgxh89OIUGeojecaRIDAPtFZrAid2wKtw..'),
('', '1432609746', 'ne9ad5hdrc9p5lvpj5bm37nkn7', 1, 0, '', 0, 0, 'SrHNPbvtzjwqAjmG0f02aj31usIpQG0y7f_ia60CSy9GHP-Ox-_3k69fC-WpzYir3-HEBe0QAHFSjvr4iGjR-h725FzhVCCD1F7_y2kBX7ZnuCIeKRjKFqRtYAaC9rcb3O137qXUGc1D2Q_X6AsIJCAUWT6-7Za5ZU06DVDhooHceYTvm4E5Gh7olq_7Argj_n0eNmKmLqjmy0D-1CPipgDIH_5OBsH4DLlS_at63rY3spJ7cnrB6cA7KnRH5L2_Hc_WsE8_cCklYQfpS5B6SwnoFOUeFd5RMNhXOBGLdB1YfSTIrQw_2CIM2sAzwmdAXX0sPlvRtzA-yJgDatapAB6KN8ST4cV8YTy37vH0xQ4un07GaN1hXYHGmIAsa1sO6Z3kSBYkD4IOtoKijHpW4OMlP8E-uRd2Z2ia5mXU26ow_pbYz9wM1rJ-AxQPlq4xX3szvbvmVwRmVTiJDdmgV2fkqZOxJ4ljbN62PHJ57w8oHqxyvlT02tNzM13Yni_zXmMJ188IBbJcXhIr33TFqIvzwysq103qWQ1wpYvlQS7MhkkMnmbvXlQTpeGzVvlmGQPInX7lNTrjOpDzxt_wN2qKUd3o_EBaoHDkiN71QAQ963H-ujf-P27IYukYQylRrYI7I9SKxHyhF5Vi4m3F2pf6v4SbF07aqWg1He6oFdEAPMk8iWICF2-Csxz5Xor6EPt6wCXp7zhgE2sDPj4kIx8MZz0qXURkVQ83QpVv8Pdq_LgDSAon4W-gH5jM9u4kuyxLKB9VPIOt_UAYLjSUbT1rwMnxP9pdzH3_S_H_GvO5mTBgI5n0H8Sqt0ss-MY0rKlUHzTxc36XN1viIL77KBuyybdXIWGPsEuW6-OZnPnv1F6VE2SSXyqQQkryB02AyJIg6Ymh3MTik-6vx6KWI3x2uEmQhq_tEyyErls42zEzraQdLnsi9gOMZAkMrfYG__zv3zev-x3zmmHJeRzDdIcYGEiZzHi-gzGQr8ut5JWqBeKQ_yrxBp1zausKUs8dizs4W3Sxd-AIom0bLFKQb24el-sUp0bHSbE5x4-GsQUlHFHms6NPdCwYRHIh3vjPKedI18YU6hou_ZWRvrDRolEKUiBYl1xKIJj-RcOqiAdqGz8Zx8GCd5P7m_L31UBGT9Ja9t5CRuucX0SR8U0xh_nrWhgd3UugwCurtolS1FKZmQ0hDcOAt3ZB_v-ZorFc5Bzyacw57wRkl-y1IdyZ5uFyb4-JvCxkpMLGAK-ac-gzRKkfT7kpRsPKfPKQlLBCxYndzigAMJfEeRRSC1fy-g6boQ9-tGbmKiM0rRoLxZYx6k4SJRY65q_K2vQqGJ63y_Ng2iVbaKBfKZfLdFxXOML5gDjDMl9aZHyjdq5XT7fhKio7hpd5Ubt0z-fF-RQ60qEi4zf0Zk81bf2aJGyScnK5Z9ps-9qMaUiDXC77V_FR56pY8LqNUvtptBHPTZ9fXd9OYdCIDTkTwXzeLTtRFQ..'),
('', '1432611583', 'npvepidcq2llg4mr993711rel2', 1, 0, '', 0, 0, 'uMTkipF4JtdGgEF_dN1RKZA2Jc4Jzk83mfeyQhqziFceHC6cl9PrWqsdQKpKq814qTG-CDK73FSpfsS3nkSFpZkIm6zmDQF28zTA01iGELf68QWzPu82tESwG_7tIv6__rHxQStEhgujVhKSHL0GJlh3LCTD0NJcVuMo2LGVtKMCO3lPT3iSUCJ741F25hUhP2mczaqIRGn4cJ_tSQVqfvWvlOp7fu8onOPdFiaSUZnvV2tfaUnMaiP9Yz0TauTNXPmO5pyS2IHShwc4XqNnuihDc6Rl0ok-GtOoRjppb1PmjY-wTTzAbZ2UiXZq0dDcoFFEtLKDnxQPmR_zHNGEKpRaiHW1GNQYNSKpYhBGFnvmJIWt3flIXuAh2YTSJ0tUI1O0j2h-164yotd6pVsEqba4nlvl9w6zLzZbDU_CrUEATIGI6h8fX0AXkxzuDxSfVvgGmPB-y1ReSF3D8YeO42aGbEnGrRye81UVPnurG3vN2I_Mrl4ggJPFdsrsZjh2pgt7TRtr-jg8aHUyHMCCQchYObuDFonv-TCqkaBLTcPD5WkO1Zft3JBqaPZarYaqHIv7u1heTNd9JOn58-BTKzL9rdCHHf2m_903dZ-wc1XpD-RbLZFDcCW52HBDZRvt6RBRZxKx1-MeBXqrHeuRKvyMZ4OlClFoziecXXldkcX4ZCglDckBShnvqA8maZeeyoPHJPG0AD9OKfJPqIVstdHumLKvyv7tnZIfkzCIq7E7E6o0KQO3P37HVgfi5yayLER8mjHrL_gzuCSVSA2FPa829-tVURTHb47GWJZ9y3gTmpcX3bJDSXKX9Ijr9AevTGuJnvDNV-1pTwx0VXjgHfqQQ9rSEas6JRbFNxQ0z1MGDJzrCF9DFktnW6-bZZeKdoDSlLwDpCAZju7K7soW--dyrXqpPIT9dPXsgpoSPA-1q6qVuLEiSA0Z0SP3KrFYUj7La6ZT0XLfDhJcotoYTxobqKhyS0UGiLzzziEnCjFfyh4qqCFnHC2WimpcN6rZYsasutyBHRkZLck6kKgqQOZgqkkZkcydvPVLXPYcsaDLbPfUq9fm_afXo1a8wP5uP9qybF2nxmP5X3gONc3WcD4wJlaIYy_fJaQP0kuiO7krY32-SFdTzTWdHTpr_MHsnc_etz5fEMy-ez45c0at1B6SqE-FM0JfYHafiY1tHO6zqiLFfqCOpxx4r-on4jUjkotusXgnSRQqW_Q8rnv6fL9vrLIQRvmrBRkZuP-0HJhfpQhJt4cP1Y76ycbFS8mpAvTgjsKRanCR1c20H6OsIsSZh37z2HrOI7zl9vbptn43AlpfYVuLyd4La7yATunJlaK0KJdKsTcTfCz5URCB1v8AblPu2PAhAAMuPESl1zsXGV4aoqe_fotlgGaYlXlwdl9_KzOIdPjZbkwgJF6eq8k3clXo310iUoUHlLaVxpkiaF23Wc_MiXcXkefVb9C7Lk327CHjYbMsJB7Meb2YVA..'),
('', '1432610328', 'aaf1ihd3i83dkmim3eluhfkpp0', 1, 0, '', 0, 0, 'R8r4N0LN5uHsuOlf8cw5gLX27qNEYhHTlXtq0avON_14hyfTvSNEJfk9sE6t7vdirnNus3D04QiPCGGTxHoBJg-lx_8PxhWzpHhaz6Q_isVKy39ZQtnsDMpRyQuDmEZGpsNa-yH0mLElH9CHtDap7awcvigbX2Le7OTKaCIpQKzVxXuY1HwWkXwcEP0kGbHlV2CVybeHLtsc5_VcgoJ7pfUZChGJwNu7VmKYr1-On_fT_lDk6zNiSakFNBXfkL9hWLgt2B-S8nyJvewY4-mVH5lNEHNv2wFhu_BXXnyrerlk3peljZ5pDgXtV1JzUPngQLb-P6JaTsyXXxydk7JttW5EflzDHGcf0LEEvAepgQ-3tyUjdvACTtjBcewKfXpPoxqRS-GlIHYbhJjUYGTfMLsbvVISmz0xEIRjHTI405MkpzH7AVriaB7y8B8-yZQai6_VT-RDw_If-Sjv0LDi-Ab_mKdYdvDHln9DzfX4nAWT9Miz39tErouBPhy3KlQ6Jz97nL1RXMLZjeC89-9NIWKrZ4rf0GZhimM3Uwk-Molw5WLcbo6PfJRGB-boFQ-Owevtm5ENAuK0KQP5IEjfXekO3nHJ9ZVmfYdrpse1bd2usjIw4T73P8sWKMp77tCnrQx2wdEiA2RUODmn-y0kM0k2k5TV1RoLmoHCESj50-fcBEHxdyClYEf3o7guiJXGNZX4r-PN2ZWVvSGorNDR1LWplAotyUMc16HEcgkZGNL6KflB36vax8_BWxSzaqjnXsEJhqw1mKHGTF7XPXV4itTWEAv-ewnRZZLgSTeJyZXLuOmRLD3S7qNcfJFAo6k0g4FF98r6TLfq_a9iRMgd6YS4wi2-0vo8lVBCAdFJjMA43lmbkK0nkdRz28E1nEsme-BdB5E4Ck1vY_U3fnM-46Yuk5qcfxwIYgjEewvQwbgcPKGDpDUGUoKDTEu6odoRICD3bmcDndJrgZLdMrw2OSvvl2w3sjtdQLf0pCxwCfMcfkLIBVNJMJxF-4j-T9eEF49O9T-CcJ05Kasev5FgibEKWxCgYWdBvL_rn9lLsVzz0xSMEPgkmmf95dZtEHf4TiXIDuA2PgPKFUf485c3vlV_K1gpjJvVFeP_rYVa7SjwWTwMhRvfA4jzmr8mx-p1526HyQOwQUU8bKTs-A_AH2M_2f8cvKTFLGwMv1U5CYFeFpfKb07RCxaC3wrgDB7qSU_6iicKX4Ts7XixUXBi6-dqOKmRg5SZAz663wQdMmGPAgDajuDsXrL8uCsjhShjrdB3DGdva0orXUAn1t7NSnbXeMOK0moHh7oUB-AWfsktgqkyK_hstEqDmzc_rysoVU74lyOECEJy7uX5FPtfQkhqm61neDF9stHQlAfJcS8ftk5N_8rieFda7LcR1WKc2EKuZJscwTbBwlLvqrxRPTMJ_xGOLrppFcAYsHKGebsbi3xqyg_ejDulym5QziwyCxexBoy7xftBDIoWu_fRMA..'),
('', '1432610944', 'ng00q0vk04oe0hmupa893i3le3', 1, 0, '', 0, 0, 'Crbb2XlrFBXRf_KoWnXb7_kyn1xT6jjvEt-KEOELQWyl_Jh0Q2z23biS_WlH_mLbXO6US5zA9gJG7XGdkpjmndWGoI-XZfk4jWTXqPJLjF9Q6scdjkPOhh9gHnYIU1KB0IlpCiGdajO0RFYxTCP4UIGHzWFs1GVqd5IvQm9N8EOEwhycmkURs0kz4c0UUEBgbM1Sgp9cFJlVasntnGkQeEdO7JHJWumCM_pbuY4qp7uveKEX0GhV2VjXuwsZsJw_b77QuWVdaDYiNC2phcvNfgS5nvTqJC7ONojRaRGetYehe-_d54zIOMgnynVf0b_dKO-qQyTO6fhcQwIZvTpAVIgMwHlOammrgz97Wdef_NmTcbIWeKeusILg3RR8ISkF_NXPPA2vanDDTBjk14ZsbrHat8ToPiYDXo2A4g0urfS9oXY6-QWUb__-XOnXfgAUm1BGavN0uRzoXL3QrsIDpnnEv_kLNKgbu7dOoYX-CCsF6dakAmEyM-0Qs1cXQhmyyqxtbzMYUAgdwAHSazjmRLP9rIgqYf1wpWd-uQnuL-TKvQ13N-EZh8Edl9s8HFqjLEKhaKsNJd1R4_l55WcCrEh9oGfoxSK9fN3ESN-csTTBHn2QQwxKXlLImkm55cB6HUKeUXpncB0zbWSNn3QbeLeN6NYDqB4qbVD8FyNX3MZve8s2AD9H_SYlQn_tIyc0dam0fkbQfRYVucm-fQwnNwqTvubbWpJ_SEDzyED0GPCcdS5Y6Oj8nTYlzs4eDFiuFA5Bus6anXD6_8tGW8PkxNfqcuQ0ilqIGF4wkBmv0oaiIqXaGuuHObLxumHwi6y-Uw-1j0N9Yl1siocpos24HonTgowR3MgL47S4hGnEhDR2pSsqk4SWRfGSD788CWMLAE6D2GLVOdlzksx6CY0S9mf5pMW3kilKO6eKUHkcVzWapAGag5wFi6roNyfiqmrAlV5eGlsgdE8jhv6-_2dNOeC1ZUXuEXtsTB3abktUJDJRXyKlR0rFDu9teNfFwgvs5zCiq-3ltNECm0qwDdsL6KL-_BEZqG56hdz5iGT8MgtQnxKFztGSUzO7C5otOKE6OrGqpTkRLrjXCI36VApAZygb2-IDMdplmNNQa66EM85e-dM_WiMgaRDsZELgSbLpM_9vkuuKQcJhMsX5Vko3b3MA_RvFcAOmqzH4-WZKswDtBjbbrCZPJN9DO6jVpMVcGovHzp_w7Sh7M46dRBvAl7Zw2dZgJh1qU91HtyEKqX_NWSb4Vwjnmxt-zCbiy6qfA_dSHyi_CeGdsnZyR2EjLkZpuo6UGv3wY7oppT8Iq1MbRRYZzfT0_ArC04Jyi91POgiDx2CoX8OOJJ1fnkcM6eUbhbAnR6NVHIFXCu-GQS8L74JFDgqxcXHMjWTqEdZthf3fXPlyaQPRCwjYwAHcrbpaxTjrksrEjbjPZnn5ia1Sgq-QQ44dIU6qs1HzhDWPx0cnhj_MEsbq_-DsV-KoCQ..'),
('', '1432613568', 'so0ivja3o6mhafj35hges55al2', 1, 0, '', 0, 0, 'M9DVAYw2A25gDUpPK3_e3U00cp-_WElwuCoGkORnZmFmz05rgSPUL5U8pvfYLej_t9m-CkpenoNz3sYIDDPIl4NNiWF1erhH5HL-kL7dPqNu84U3V7_yxi7-LpPyPA7b3_AvhFGO-aRaql0l0gxG7FnF-9zNgGOZqB9rl5_FYI0yniD1v7GttubsJ6kGSHMmnx-YTaKQzZY1C9VbgXnE1zkhAO9CLQNFz6tRr6nldWDx3rQ6ibfVYnkCXF5KaxPQtko6W9hVaPXPP8PxD1M4OZdiJR88PbBJ3GXa486BRn5YaVCupbNJ2lkHVyU4S77g_8xx5I3DzYHb6Fd4oGAvoE8EKsvuEkPwocEQAW8DMwH3Fc7MoE0kErT7GG3uj75K0xkt5gWKriBgyps6wAELnHcRmWdYVLsUJVH-zJkMOJoprpFaHTbcrnh1iZBNzc9KrwWexcSPUR5-vDYGyxugt4K4vY7lA4Fz4V7--PSMj0ts9bTTD3Cl9XXZ28agxAkpVa7Mzfy_3wuoxifgFgAUnXUFSaTnW7e31A5MgT3oU4UCfv27ooxjcfYs2L4ZLJ6WCT09QryB83mHJWj7i8cI4YFfqq1WDVcgyjax6awA-awBHLhGCafW4NELDWiTv89zHYu2aHfRUNq0NutJH2BibVikiddxm_ZbG1gMDvspi0Vqhk-i0yY6MgUse7Gt2PRQeQ9lXXQOy005l86iK_ikgI6bg3jxDKxlmFhEYYNwqfQGGOV7TAd89DWop9e2qHvV_dF3rV2c7qgPARvSIClWlg3G_Diqt9gIl7lGcRPERMmmaQFAzprSnkJSHfdRZRb24cM4tD8cPoFk2VeyvQI-x4GL0rMwr-oe8VnB7yar7-ru4ON3GZd_Ct2HStn7lXrEeyrTlQ3Cwuh_7xOg7znJ-SXygIH0_HadVROnU_OWEWLUQUukH8pBi45xxUXBMc9v8QusyEAlokGZ73fHI42KGS09CuUcf0lPKyPfTibV1hISu6gINlGUq08gjrmD-5IT0y88pk2uzBjQKSzFpUAUxkznmw1_9iEYpUrG7m3MwmMBUaKZ_KaHTcg4QiMd9zeNobjbKsbXvgOwG_wJWTcs3IpBLM6t5VCZPzGpk_SNdQeuroHEk9sSiUJUlDGkxJG92IfD5t1ILQEK2ui_nxnVadeiu31W6s4h8t4yVQTbukHnl8l6z7wa4T5ZhYeb64NeeIsMwupNNUFjRwp3jL4YUscAB7yvtf5UDdZomtNRm_Ws2PEtQYjSExUps5dOjveHP0SojpNqtBbDtiKOkAaMGXCDX-IdZl8ocg86-AaNmj9mUWkKS_TLgvWORfx9bnRl39YyVJ5iQKrqXfVDasIp2Nh5FPoGAgeRIssO1IBDI0vH5TSkhMqED9ayEMxloPcu3uZNxlFRDsIxPUd43mCxfmYJx5MTp-UTBuZbiswKTU0i8PfWjDZLHKackN0kGIhtfICUvoQkDW8hAMsX6gAMeQ..'),
('', '1432616085', '12vq50bpjfjekje8g3qidfdn61', 1, 0, '', 0, 0, '6mRoLf8VP95r5rVUBIAbRzL4mPHl3-F8N7khFQFoHvNYJg_WImYuhfgLNJEQSaYh8wD8GFmuoDwSsdAw3FMPQsbmcREFkVdAdQ5cVZVYN9YIJJfT8lCvQQskSPkc5QGXAwEUb91RbMFVo6AAMpku7xlwqmWQ-_lJIQhCK0OQYTf2SWjX98VfkA7EvKKvGwjfjkEmt8WQDoHBxvoXmR_UTuTHqyyNK3cpk1NCuKiS8kG_OACkRI8951LASTnVO_3hN4v-7K0KaDD8wmSUAllnGeDnsKohbVfdASa4qMOVwL8nbINVvJ80x9X3Cl2IVM34WOwVH3gGKZCMA5GqUswu9zIEgvS8cRcqKED4H23BaHvOkAC9_sdmCa3bseuoeiiDM2_T0T86E1DOcA5OXwPXpS3EAbs592yCSfeBPwxlfvICoHmcRzuyojLEI_EO4lPnLYsluqHfqeO32YqtE0lII5gppXpU87BVQECK5e1uMCxA3fpIXPF4qzHoVmTwwNhLmnb1E-HFn_wBXyOkrABG84pgbIBgdKKIPWbjVb6kedij38_RD66Wl-L9KmiaicQ6XpX4bpmWpW_cu8dLIziNuK1SeOmLWpBgX06TOPzVlU1iZAR-HjCYCVjKVJdNq-OxG55yC_wlo25EaE9QsdMTJJ0xRGFhcjjbfyf3SN0ZpLjsyVk-7_xFAprfTXorxBXg2HXEWLV3ebC10NOAvh_ZEso8qlWiGEczAVr45g-P0iaq3dDbsBtdneTTXd5duKlm7j6wF3_XCPsZBi5BdDhCpcJ1KoQZQsb_AJpnctEA5xJVZGSPMlz-qYi3UJFnXUzmfSR30jkyM0rLJVpeE24gE39ljG8FmsN_xR_M1sX97Mqj923bGGlcFWcwRFQNqCSOnNLYHGvUrMH8BJq1pJSJj9imkmsVUO1sHOkE7716HqtgcAKdyQOrSzYI5HJ9OGk7pQfQamCTW1qyavb0mJuC7feZ2_R343XvkW8YftRy8yCb6v8clD7bnRPnGU-_G_tWrPmyX9f9lYNx-W3Ezip9shphGI8chU8Tqu0VtYqDJY2d-KeDI0Dr2jRJWGKIBPAvI39pNv4QQWNFMNJZWgiRhMBSqti3lDdqy1q8QlMrEA-PRayCQS29wmOHgAiFSRqQhrIbUYoDLbe-kBJ5YxxTHOzGERYdET3-epG-xny19prZJ-X90qGCM-uNVqv5d7kdPjSLlVK9Q8vBT5Dmu6T1WHSMAq0WZSwhNijPBE73lgIY3fPlQSkm4p9W_KKVGitKqFMES1F8JNW1_rbXCpI6hPCvLbdFkm3fDEsqVAyou1gCBBmsyxoKumTXoYmMjpJOiehRbm5ayEWnbPpcJTBnNDfkTczCwRUYRdw0qj1VXEM8vblLaRNmvI2EXzOl8GoXG390Jc5ALTprKNYMXCYohxUC2mGf_0nlbHHOdJXHZvAfz4db-34Xnlz-73ZALDgPAbYDIR4ng510FybHgFcLnw..'),
('', '1432616910', 'cmqnjq4qn1pt54rtkp6cpptej5', 1, 0, '', 0, 0, 'zf2hWf-HHrbq-h7yHAD90CMRQsWnciI9GW2k0BkTJ0wfC1zi925Ag3rnV-K6_PukHaa18T4Wq_anBMx1CroGxavW1BGM_VjVgqCTHJdkzGFDU4I2GtvSOVXPUhN4Ukuaa3MBCX0gj_MjF2M5Y6M71ghrm7LPqH15sEm7wEFSvkgmobMt4tAWd5yz9ipNRm3EMtb5SlKY76JzScBnx5f36tlqnAa0Z0Mv-dUf-2Si6NM9Lt2jMfD3whahtI1QQHQ6Ji7DjElMMCgUS6mW0Gp0QPxnw5_xcPssPeUv9bPZ-s0D5boRM-g9A75ZVMogm73EU0yV1fOAPJ1wp1PfDRtnbWYXWiJEhMatfjRQsMJFjCMkbM8cvW9VrgebVBX3OsdR1fAwvDf6a12usXtZDJMVpDPoW2g-ZBs3rbz5wE7UkG5oJg3Gn7gDcigYEWTwzUT8_4mrM0iRiL8XYpBENyVBqo1oct4cRnCZF_ExYH6lOqEbJheM8HdXpI6YVuuFZBXcgrAyIH_UeYFQCIc9RiZaTEsgkgZ3PAj1gOG2yYw6SKXkN7Mcl-vy-IhwlZ7rqDxqL7HMELG5_WWbsLHYbJgSjW3yqU6q9PUDQjTNu2sWopbc0ytqG7dc7lExmiQLgpUoXCw8auh7aq1Heq7QLqxtevfMPZngR0AcycoTY__YrMoU4vRml-vt4srIo23UU82XQKmywKVxYIyCsI-o2nF199-YgBWxXlPFraV3FT9KLvXcTLJW3AFzkhdH5jHgP_jSLqFrC4Z398tRQMgJ1ahfsl9xoSMqai6zjzZNGqIqByFVpIObOA9qO5R0-yCo_SBeyusFynv6gd6-gjki8D8LmoW8KDt4UnkDTEdoBUNIShBlWCtnfo1Tv3460G8cHkjdsZ6EIaKldcSN63bigcCjEr71r6e23PoPUrrklcAas18ZklmgQGho0glEBRHClNkgVWOcBrgmA3OYpwKQ1gQa0Nn5MO0ZkwiDJjzdOadmZ-AqvY0P1YskaYNFC-tCHiE9W1oNQFa82lWBq9nQXChcMuXaZ9377SS9tRP_57YwBIPBlzAxbDBMSRVgbRvnYGqghIxt_JaXKpTkOke-FpYLKOVbSVZkYs1mbuCm44Q0sB0q9lQiwIFUHoxpwEsjvFTXIEO7b0yQRqRiK5bujSvnY6sDXfwYDAy3JIZSe77g8WWuFQ8Efo6KOMH2WeITCxZrEiyW1EbBPM_Qge7_60fEfAZOxgtZabKBFCqbC0o3702AGDvC2o17rrww6CE13P8e-SZ3bozEPycFpoa9L6GjMypJtyzILGGOhlrmZxa8zOqn-iMwRiwIV1vzJseMQxtJCtXHQSwQGuG_p37ySd9QlRoDwVHWYPIGFkF26PgASXa8KY-PQNDzz_A4lepKCWPEuXNoeSwEq0ON9YxYEcuBXBjVTRSyLKAxvMhFzDV-WfXN20PdvkU0g3VndblRL3d5kXzh45kkurNrai2nU_WUoA..'),
('', '1432620501', 'iqkg3p7smblmc8lklgv3gn3836', 1, 0, '', 0, 0, 'PBENeex31magfH5uqOyqyCnqRP2yJjcgkZwBRnbxAFfd5R71dGWiZsob0sfQTfQgqsQw7s24gnNal6O1r5Urp0dq7pkFRn7lDzmZi1DxjaOm5P6sjmLpiTIc6zFhRJOog_uCwKTg_1R1qPMYoTn7nrdZoYpXxMjLz8FBTkB3DA_J2e5m4OWyL6rTGpXPuSRdqxOllIDuRbhklES4fBT9_kj2vbyXTIC7Q3HerZx8ECAAxIALAmOMjQtckbqxGqVihrNMj_CpnZV5UNn2UAV3pKVbBvvmpXul2ZqFRfcp4mqUeNsffxlEk_RUeF7GlC9AR8x2UGx2W6mz2WAXzj_X8Rmqvz0bLNbd4zsV1-AYNfaST3udxjA3Ae6wqXVTVkl4OZ5CqH9e-h9K-DVHmcGAAf6A5UZQxZY2luzC72bPJocng91zmi2gjc2On6z5P-y6q46LXPmUThS9qlFjBJAQr1G8fgQaJztl43ZUls7-xPRC04g1fQD5DzwNYi8tNIwVLwlUf-PH9Yd2LEpitbRdPV37M0npvyPazQZF1sTQsqLhmXtnu0YIlO5x_vWh_XCnFapEj_pgY-huwz90nqeq8M-r8y-aZMp9jbHA3HZ2FUu1jX06w2uT3mXyRO-ZVQMoTz928hXV4nahN5WLiRi_TEtznDWWKhoFLQ9ntvL8akoNgEdfAh7F9MB5gXE1YJCEfXsty_IimWgRrJnEFBc-CximL6PppdOw6t8hNqf_3R8rRToTRf5Ojhl8-Rua6Lu7EPXuO2juHzdVIRP1GxDvlVn61PSKk-KpDrIPzOuLvRInDU9_VW0wE1U2gcIqvYmZnRoezyV5Ksairr-94_HD7m8P_llkjPaOadscMkMq0geiIaPMYYFqu4GWv0tUQLz6binXkC56rW64Ec1WFGQdAqNaKzie27IioYbA4Pgxa8epfKYHAJWKOuqJkiRYsfqQAEC5cGNZp9ax6jXNnBctZWqFni2C306L84kEKcEHPyUdLe8SxpdsTw0iaqTudRAv9uDhF1jn_2g8HT_KtDW3J5he0y_WzTRzlWqAlD21xx6wo_-3SrtH-HeIj9XQd2-2zMHmTe62a1MH8u2niX1EeKLSzdGI15cdhdXSYM7fJWpUh-TH-5Lz7tmK6qdowy42rGXoAGU1ivxGDR3Phle1gZJl7sluRUKFewZZ3MWU41fcn2TH0tOsXzB2FmuHm0zp6RCGJg5V3draEciHLiIEG8ZGMyRScr-bGTHr31lXG8szgFgcy2s-5kP7G4hQVAALt8Rek7IUF1IHxcRlTWTn1nT7tq88lYsBxskX4m99sHqnkHcO4MyL7caTKrDvyHrf5piltA4trHGrdjP1qIuOXfRlLxEpaDIC_GHrOH_GY-MhF3aQt9gEorb4MP8eyxJsVANxB6VenzQq5dYUVzihjQVXYfjiNKchnGPk7-fU3ohEDbm7RNj-hlpQpoIvOBN7gGkrtJLAWx19Q8mfad1gqQ..'),
('', '1432621064', 'pktrut210j992k4h38a0iji0o4', 1, 0, '', 0, 0, 'DwEQ90H9HQPsguHXvA8echnvs44rfs53Wz1ryMiFq9dm2fGq-QPY0peU7RvtkI382oDB2THTzeWdtrBHsp5CjugXKUNBmbS53RbbXe71CuCVbKgNGpn8soC57lhYjUIbF8sSUznLqjisy-06RIquwj9R4j8flRNAdpccECUCrZ6Qy85UdZO74gt-5yOL4EmFQQl8G8VlyGFqsl3SHQJLR_zBIZhirmlUFkaXGijn25p9HtnSD7yAKixvWHCcPzhj3DaWdjJWoEETqLipB2XxzeDEioAz1iWA0Wwef3NWEO7HAmSnthnY_9iILwgO1wkc-aKuDm0O1N4yHoIHte0UH7_vg7_4QKytyrS0Z5lc2MS7YlojFbxJhb5y8BH-ZnDOVlUnAw9gZ8M007Bk7371sdfoWKAvJg58byFtJutoaJ5mO-_G5Y4fhPm0pmNdogLrQDC4QpFS3v-o-w8u_qXsGMFzwDKoD7MoJcYvD0A6xfD45HhtLy1hNtbNUN_Wlpoc3UhBrY7RKwg3-ffW7mJO9HFcAkuHT7z3tSlYGIRxVx5TrWzXvB2IJRCBCpeD3aI7b-20j40cGlR_HlzJUsAq4FSZ47p9JVBL-l6p5wNydotj8wAgiroUPz-x_7Rp78p0NYLl9igMw9JBObMioumC9DmcUcM0Y3E0xJ6r-hcVPsIYcVmgCm_h4f00y53tyPccpSxLOemcdOh0hRM9K02RrQ8oi_j-oRwKk0xbyVMGpG9jcIddg9GbGUUDNeKaPp01xiOYgdXC-AJsck6qE5E_Eq7nXK7HOaylGTCjKvkggcZnTMRGLa34_S5qxZRQocqbz_coOxwzX7MNUt25flEF48u6u1VqMPrN2mmRtLnO83ZX-LBAxG3awvTMGYo-75mveis0LX4lH_fW0ha4Z-txMXYL88HAeteAzv8FMxXKOCMjJTZ5mJUxuuMRm3BihXht-bzA82QGwv9MyHVOML1kbb37Q3riDTWRcchUVFbwUK08O6Q92vQ114NPo4yJSL7ilH0B-XLEmRlFZf4Jy03efc8dxBVZflxJg1cqo3ye-SMsD_ZBEszBjSot4d8C2baow6_PHZBmN1Du4FZSv3lF3JagHkRkN2dIUYDNdnwIc3NDYfIEcjtG3Musw_GhoitOvLbpxoek33xJoHXnX64Db3MTVmXVp8P2ST2RbgwJ8kEi_ieH5BnDWQ9o_8aPp-zynxkFOsWnnXYTxX4Lj6-wQrXvNhNTJ2kfUr7wh7G_9UJy_W5j_aZJIUt95dgA_vlUphqSGTl3HxsZOeKAq92-LZB2qVREDjQT3Ms1g_NZgfpyq-QSpFlbQI-yr0LnIkectuyLLB21FhuJGBe-sHA1WnyosRXGz2dPVrGM0eq8zZsVmAbEMytplcvWta1KcmA80jqRzc7kYbjLgBrkFzSMEQhxf6ifmq41IZzvUNZS0_RSn8_Jgi-3SXovc_A9oZahm_eVVAeAjbZ0ez-MgQqYvg..'),
('', '1432621555', 'v283bb4vuqdkaa64p4oq9h8gi3', 1, 0, '', 0, 0, 'K-qTf_kEFnkV_XzjEztMCF8DctSstSgqHcwKIl1rfOWpQPpPJu15nKyrlmJhU5sUs9r3CwpsvLiD5Pq-nixzF7IQ-dVXEflfODT7WtgxXpfvAcYQFaPNNTn2QM-ZuqUy_7YjROgBiy5CNtrDvURlo9zO7yEfPygEbpSG_FW7lJcJFb3r3OJZlVPyH3LwQt3ZUw2O5yiizj-RtW1yNDhkAQRsbHCHOxCG4fDnW1bWWw8vlnbw_mJjtMTId8rwv7DMvUvZv5lMjRS2UBpDGO9G6VKVhjkxHnDq5JCI8HbfYFMnuoR_AfZxUIBkZNu-Ed6sqG0tAuNMK_VzGSOS99C79MQUiJa33dYi0kpD7RH33ATkk0E99Ha14d4LhyUbckjfaxCt-itmtyX20asdOe33Sm766EvB11jMfGxIigjGZ_MuQYtEyjWgbHTJZkV9uliLjHmuheX-sBfj9JccZh1jLJlM4gTFfDFA0lJdGTMnX6gNKj9sPtpZno1aTUOWTO48wkXSFoXEnG4wjXNSiZgdK9nCyCjFYiQRkydAvw0aWJV2JhmoB3ifcpCxpUGjuLpuTUML4s0--jxpCHZU4egWyBeSUBF_RlcjlazShyxrLhZrcWTtEro9aAliIPmJ9dWPh1xRKBh7Ttoh_0bPcFV4bfImxlBCHFTQaOpqf_jSXQGAgzrjWBqrsAGRI9OzcfBgpcC4TLpjstgkCQR8RB59VP_y5yPxFcJiof2ZAXB6IVOl_RJhGV-E7hEA9VHTPcJETVn10_E-0vyJsOt2MOB50LSqZiuFr8pbQf6iT53_cetQ1Bv4Jtj6p9huqLrtK7tdK9vwlqLnvQoaPcTlZQZoVa9WTtyBbM2V3Z1qo-Dw9utIamtKWY-8mOrOe80G_u2QdEHYLEE0vl9MVhRSDGEKUI8IZGq6zdCvdZC3HAFWGlgh0Jk8ZgvIkk-tlRPc7H25lEUlBnrOZQ1r_0jKKpWnhzHjxI6OEdfPzAzZio3VsgAMHzeiHICw8EVzBxrmevF-woiYCFUdIF9xkRwLw37KSM3weAiT67XnXevGsN6ml3SHusSF8Q92AOWQ_dCyd5tlUlVsMoalWHrAhiVAJzu2qfmcKr21VaClIrf_8P5VC5Bm7nZTQIfTWwSMbwiGQ-OXwodT3RZsE8RfugIM_W6FhsiTfRVcAJhrXJHbaJ3nlyzIznVQ6YLo0dyhOpqdFeykEhTNZZ30lVLa-26WxyOTrAJPJBtegX8aVktYbh_IWBGmxYel2e-mh_-7pMAE9kOOSVThiZtX-_oYeTZW677eCI4azq6h2kFCbGreCiWOrsLIkJzBBGIWWADA8fFXi21lmoMsqk2PuN2iHahC77NbBVxRzViYNAphiHITVpk8lo8tXcnd_vT90VDfL0bkitF0NO2_UXMn2KcIAucHpjIJoS51NiayJxLvjxHvogoWeEGBRFpYs0Vt83-6KCRjza0Lgq2zC7_B2aRCGW9rtb5WwQ..'),
('', '1432624327', 'ifsa8sbtv640c3b7ftjcst5om1', 1, 0, '', 0, 0, '1H5As_BrQOAZ8Yv_mGVNQg8XjFRJbQf_dP_UGvN9eCslFWGvLnMD2KjoUcuXhMrh9SYT2Gx_wxSeanbImyMP1odL4g6Fr420M2fzB6iLvribVYP6MxxDC1zdj0W6__cne8smixG6f6t8ugtpigCnzTiY9F4Aw1yxDd91o9W0rIvBW8CRQnxSFqNcJUXFz6xwg2_FXLLfTaVSv4eaOMClywrE9L2AlC2vGKhF5IantuEbc-XekQQfIknEUOATF0C-8lJ7LdLfpfvfbP2ghFwyjhJATV9RCo7cIFUt-DRbaKRhh10xi5ckdwb5zMotne_iSMWEAsolSCgbp5-kgbooxR8h8r5N6JnbY5Tsfn9pTf7FZkQ2-GJyyqDg7e6a-iyjNzSBWav1h0XlaWAD15Ea0xDP6tWPiVSX6Pod6_7_oh2YDRKw7wkIFZNyJQcx0_duT69HwHPdrgs2cRUzFkrgaxd0cYYt4ypywr2Dhw32MGlKdznKZaE73JQ977E90DqYhgmH-vMWjge1aTVTySM2p7yZTKHy0FjXmwaWSw4PaoVlekG1-ukqG47X5QSqalvRLkjaZ9vfKoinDWZrHFuGa-BTGzmAdn8a-UwuvggK2KpsPJr689ojEHXiw3LL6vgjmttUKn5e7lw_67nmmC5aav2V0nTornpsSCNC9P6GqBCoF_MQeHeNPr4ak3ncbcwz6Ut7p-c1GXDVpn9L3UfEa2jshPh8B8CIP5lG_qqUG7KeTBXHwdwlns2eIQIoGCgqSmQDXk6lgkO8_VbXFIC3z8nze-sNN91snLpJo2qKGSxHQgDHIlBCZ1v4VRDe7Pmi6mnCa_FJeMtNd20CmavTZjHo-IW8RaVD569XVRInCKpgW3jteWSvcq7THk6I81UKocqKmMA7VGvcGicn9XUQNeikJWP7jE8OQVD81B-XyTfY1MGCn-M0u18eX10IGdqEKrMavuYvj3kJUegZzF061Q1EoUk9K-0IOZZF0wTwgooZAXOiC5j8geCb-f7jJjLFWWIo3961O8S0wm30_VIrpFk8lZewZNuudM_SzX18Vm0JZBev-u3CNnEuoENl-tlU13DL7tqLUwehjxpSK83Nt1tiyueHsHHZ073E7dcRU0sIp5WQCtavwycJi67_YoL9eKuWBAPbITcIJyQ4DjzXB3nPCMeR56cIMql6tZKSWMD96D2csW78Zj1BriNKOXVoVAGtNwe75h0JWQqJxLDTjNHGN2M8EROh1y2bHCCJXcFUWMPJ-47j2-CpE12kc5zDy8jGZ1w4AerWX5Cl5bYeF44_8oqxRX9cE-upOSpf-iqrnyx-MEnLzLCearELD0TPhU4RhErNuzNfaF38pjhuBB8bQoDsh8uRtNy0lUphrEzAF5IGngXhege99MXGSLlY_dUEV0murrInVPmUND041or7qcQkrD5IvanNY4MpxkvwtFjaYtwXWx0suoAXqJp7owBpkzn7SlKaTkRbl8v8RA..'),
('', '1432625580', 'mdnm4836p33fdjq6v6blrc7qe4', 1, 0, '', 0, 0, 'SBohlNRvCstCuv3iSnDrRFG8Xaf_0lvFgoaM-701BlG9iXelaZpxliX6_DwZF8MfumL7hEWSjqWom0Pn9I5M1-BrwPTe0chIWfjWCw7U7cU3dpNhnF4Xnzi8w2y4MrMXaTBw-4_nGj3L9PWPhr898mNp-3y9uxHnrqOikuqm9kkdgyahgF5WK-YFS8kr6A_vjsokholiGMAT72ne1TppmnkIFV3_6UW2gw0ZlUhZWxKb57lr-d8cbc0iVxtkli6F9nQFKiqVPxBC8IDXpmWVHCZ4yVbMxPTolhO2HKbM2h3YFyEk8QrHgetuRjuF5g55CxlT4vds-u7Eu_FbCDyZYp3uOWl4st3WWsSBEiMbGCe8XzlXkZGJys7IS_SMtolrNLKs3FgJX-EEg0yzCSYu4iSRz2InlgtwgCroyflLuI0mc1KAxfkbE-PZTrHgKMA8yTIsi3sa001LgcnzHdGqBpAUHI1s5hD3hMx5UWCgWRk0XL3nEi2PFfuurQdA21ckVEeWfn0PpLpa_jOjz7leYGjER8ws8zkkG19xMcbi1kfunVMSSQHZLLdfEdHjrJyaI8EAAko8C2qJIbB0BnyAz9qQ_OIXwZ4DoKGmtUsVZ1R6JlWey1ERi18GcffSL3DtSh_QprvV5Sx-nK2jqyeLK6YTRyJx4wno2OrY52by6MkyeLD1ZyMx0zq7FWz-7jgJn2dhKoDQ8FtLT4fNy4iIBVzkbMqlaZ_ECHxj2jm21tjJ2ANVlc1EKgA2PD64w8OGsdlPfDkjkScsTaQPOk0V2Et529CVeFr-013oLNFqTt5qHIaGugRvBb2fbNi5CZss4owAYsl729w5_lAWCT5ApPsMeq1nyGbOsPyAxRzRrJbYGwRURwiA8Us3UKoOIzG9UX3qD4hWeJlh8KoAmPTmhxYUbqIXHeiQ2tOAVXsKPqO8HlcsKMUiknrFr6qtdx30E2PZyeoYDll-4ahf9wnxDiijWdAeJqyPROIKLNClQGmKjYOEZPB35jiF_Gcteyp4PhGP5MRkYWFu8jwKZXP5O3HBGlMTBXs4dj2gGxbOvrzmTKDyMHDbxuuzXoFfmn-ytmR_EX1tpphug2hayHnWbZ5QENQ6E8YdV0POkf9HysbPTulMh8mm7CaL8POlVkbo7e1E9Y4yewOet7Cyn6Nojmio2l-Vwf9XSJPDSY6NRFJVmlIazqVS4tO22r0Hk89jR_LjyY1XVLEsZa-ildGcBLsJzcp8J7FkftG_xQpD9PTKxBuvsPfkmQreUKK8bFYv6MZDrs7FZ2mraaAdNAjPsPFbOI3HCJInDN1hj4D4Cg_mw1LtnTTcSmEsb4MywtyVhOJMx_OUlBCNaEvwiGQI0-HfmfEBnvMSkUTY03o5fcld5tOXg_qVaIsyM91NyM4txeoicOC7jIXkiz_J98CE3rG3QwI1nERILLJ_659XmUWAX2bIus89WOzZduvdDkjAWk9H1BXPftNJ1Af2E-45xg..'),
('', '1432627092', '0sgckbivabh3g9833qmlfjsnq1', 1, 0, '', 0, 0, 'xcY7cWYKUsuINJltEdgt5StGycuADK2UkALYqChBECouZE7t4DcWi4N2-HhkWiH9xMWmiS64w7Bj8zSmuWsGbYIgKal0nTMTjL26PpXrUOTqviehsVgQzYDn29XsuqVXknOyKf8yFajBhhlpqaFA3C09_jcny8OAdjqv88hxA-haVWTE6v47HZZlLnoTt1qIK4kwqsBeP0-ecxz4653gnUnydIrqQJtmuAHOHFSXuPst3kmgayvmrGxT5HY5pDRxb83wU2RynvHvGbvjJpQaIeYpySKwU4e-eQPB5cMaqvPAn85sjWzsArkp2Dw3EkYPXFusbxYAjpyytBqDTjPuBhLuQGAwnMOsfI9GfaDgoigF1JmsmvgCKQb3NZm9FmDJY0SrgVOaToteSGEQaGbSoMLrTeqZ621YEDa7gHu7hlSWOSFbjnyQhEEkSxKSFxQSbGCOjerTzgv2eP4_vzVc8jSkvDBekWDplrrd8v2jAJfOKrUBIqID3gP4dRsuP-rtFjiC9_NSfcAbbrmFXhsIIrAeOHjoJUjYPZaQ1l_3Ev_BCU-DI9gwIjJuz05y1F88GepjO8mUc4o8E3e-fZrLPtg7FsWUXdp42bPxdihBfpGZcahdDdE5k2I-fo83P_YojDt-LIPr4yzVLQcuxUZqwZOGlY48dVNXzivJpI30i4r9cCgvBon1EgnzTvqxPodDG2hn08tkYYF9sQLlV0v6gLPO8SjfZ2wZfnHhDRaQMot5gQP38n4kFvyP8KMH-L0jXyQAWwNzW_EyKppujwimkMBDK3X62LAUGlSNUwB4et3uFtPuq6aFmYVTik57ggD7zfMfYbsvUMO-o3pjQoGtbS0u35Bi4DOsVyPo-LkH8c6AfEE4ZaOEVPV4OqEv0cltC_WRwaX8C1GQMCOkwZMPn5yS0FBK_P0yXf3yrgw0QaAfjPd-CGY5pmSpmGkYnf24EGED_b0reZTqPXUriSEiWFCZWIvSO4RuyEphbzulirkW55od8MA5KIZA9YquDnp0n2tMt-2rzzkeukncghKR9CsL1mONvagpNEFop5xYv99kdIAdjJ2pqCHC9Ddz35K4pgLvQ9JLfB1IBOoMi2iBGJadikKDumxm5THK8J9y2QJAHu4pl1xbhCjhoDmWCpAfUO8aAlqzgT1pNP_P_rjzrBQFrFrLWcdDcu--FYgocHuOgHgszHS9CJKr-dbvCinbiPUaRUh7FVawcjErhYyCEAahKeuQcT1wvxVIOjG29IjmDTD3i6--e4r0iKuwB0fpqsJrzr_0B3JcHgZy-DsDro7JwFnggzeO_DHdgy02YcmFEj-312MEY08KQH3Usqpya5jPuvhkaCIJGxjv25cgoXH_o9thnrZwQDzQnH3VdDsdLcS5lcVWxwdk6OEd9cTSchhcv9tr3PoF1v2YoEvevhYolxNDt9Mz6bkO0tjj3edJ3Do5nlwxCrn3-7Ywux4chr5J62Deylrup0jKSm6khA..');

-- --------------------------------------------------------

--
-- Table structure for table `jos_stats_agents`
--

CREATE TABLE IF NOT EXISTS `jos_stats_agents` (
  `agent` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_stats_agents`
--

TRUNCATE TABLE `jos_stats_agents`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_templates_menu`
--

CREATE TABLE IF NOT EXISTS `jos_templates_menu` (
  `template` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menuid`,`client_id`,`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `jos_templates_menu`
--

TRUNCATE TABLE `jos_templates_menu`;
--
-- Dumping data for table `jos_templates_menu`
--

INSERT INTO `jos_templates_menu` (`template`, `menuid`, `client_id`) VALUES
('daecenter', 0, 0),
('khepri', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_users`
--

CREATE TABLE IF NOT EXISTS `jos_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usertype` varchar(25) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `gid` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`),
  KEY `gid_block` (`gid`,`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=78 ;

--
-- Truncate table before insert `jos_users`
--

TRUNCATE TABLE `jos_users`;
--
-- Dumping data for table `jos_users`
--

INSERT INTO `jos_users` (`id`, `name`, `username`, `email`, `password`, `usertype`, `block`, `sendEmail`, `gid`, `registerDate`, `lastvisitDate`, `activation`, `params`) VALUES
(62, 'Administrator', 'admin', 'martin@ccnf.dk', 'd0a818623d3d8364d2b169c4b985de8d:geBG4nyTeCHhgTYjvZpyna3avU0yGQJF', 'Super Administrator', 0, 1, 25, '2009-12-30 10:32:28', '2015-05-25 11:07:02', '', 'admin_language=\nlanguage=\neditor=\nhelpsite=\ntimezone=1\n\n');

-- --------------------------------------------------------

--
-- Table structure for table `jos_vm_country`
--

CREATE TABLE IF NOT EXISTS `jos_vm_country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_id` int(11) NOT NULL DEFAULT '1',
  `country_name` varchar(64) DEFAULT NULL,
  `country_3_code` char(3) DEFAULT NULL,
  `country_2_code` char(2) DEFAULT NULL,
  PRIMARY KEY (`country_id`),
  KEY `idx_country_name` (`country_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Country records' AUTO_INCREMENT=246 ;

--
-- Truncate table before insert `jos_vm_country`
--

TRUNCATE TABLE `jos_vm_country`;
--
-- Dumping data for table `jos_vm_country`
--

INSERT INTO `jos_vm_country` (`country_id`, `zone_id`, `country_name`, `country_3_code`, `country_2_code`) VALUES
(1, 1, 'Afghanistan', 'AFG', 'AF'),
(2, 1, 'Albania', 'ALB', 'AL'),
(3, 1, 'Algeria', 'DZA', 'DZ'),
(4, 1, 'American Samoa', 'ASM', 'AS'),
(5, 1, 'Andorra', 'AND', 'AD'),
(6, 1, 'Angola', 'AGO', 'AO'),
(7, 1, 'Anguilla', 'AIA', 'AI'),
(8, 1, 'Antarctica', 'ATA', 'AQ'),
(9, 1, 'Antigua and Barbuda', 'ATG', 'AG'),
(10, 1, 'Argentina', 'ARG', 'AR'),
(11, 1, 'Armenia', 'ARM', 'AM'),
(12, 1, 'Aruba', 'ABW', 'AW'),
(13, 1, 'Australia', 'AUS', 'AU'),
(14, 1, 'Austria', 'AUT', 'AT'),
(15, 1, 'Azerbaijan', 'AZE', 'AZ'),
(16, 1, 'Bahamas', 'BHS', 'BS'),
(17, 1, 'Bahrain', 'BHR', 'BH'),
(18, 1, 'Bangladesh', 'BGD', 'BD'),
(19, 1, 'Barbados', 'BRB', 'BB'),
(20, 1, 'Belarus', 'BLR', 'BY'),
(21, 1, 'Belgium', 'BEL', 'BE'),
(22, 1, 'Belize', 'BLZ', 'BZ'),
(23, 1, 'Benin', 'BEN', 'BJ'),
(24, 1, 'Bermuda', 'BMU', 'BM'),
(25, 1, 'Bhutan', 'BTN', 'BT'),
(26, 1, 'Bolivia', 'BOL', 'BO'),
(27, 1, 'Bosnia and Herzegowina', 'BIH', 'BA'),
(28, 1, 'Botswana', 'BWA', 'BW'),
(29, 1, 'Bouvet Island', 'BVT', 'BV'),
(30, 1, 'Brazil', 'BRA', 'BR'),
(31, 1, 'British Indian Ocean Territory', 'IOT', 'IO'),
(32, 1, 'Brunei Darussalam', 'BRN', 'BN'),
(33, 1, 'Bulgaria', 'BGR', 'BG'),
(34, 1, 'Burkina Faso', 'BFA', 'BF'),
(35, 1, 'Burundi', 'BDI', 'BI'),
(36, 1, 'Cambodia', 'KHM', 'KH'),
(37, 1, 'Cameroon', 'CMR', 'CM'),
(38, 1, 'Canada', 'CAN', 'CA'),
(39, 1, 'Cape Verde', 'CPV', 'CV'),
(40, 1, 'Cayman Islands', 'CYM', 'KY'),
(41, 1, 'Central African Republic', 'CAF', 'CF'),
(42, 1, 'Chad', 'TCD', 'TD'),
(43, 1, 'Chile', 'CHL', 'CL'),
(44, 1, 'China', 'CHN', 'CN'),
(45, 1, 'Christmas Island', 'CXR', 'CX'),
(46, 1, 'Cocos (Keeling) Islands', 'CCK', 'CC'),
(47, 1, 'Colombia', 'COL', 'CO'),
(48, 1, 'Comoros', 'COM', 'KM'),
(49, 1, 'Congo', 'COG', 'CG'),
(50, 1, 'Cook Islands', 'COK', 'CK'),
(51, 1, 'Costa Rica', 'CRI', 'CR'),
(52, 1, 'Cote D''Ivoire', 'CIV', 'CI'),
(53, 1, 'Croatia', 'HRV', 'HR'),
(54, 1, 'Cuba', 'CUB', 'CU'),
(55, 1, 'Cyprus', 'CYP', 'CY'),
(56, 1, 'Czech Republic', 'CZE', 'CZ'),
(57, 1, 'Denmark', 'DNK', 'DK'),
(58, 1, 'Djibouti', 'DJI', 'DJ'),
(59, 1, 'Dominica', 'DMA', 'DM'),
(60, 1, 'Dominican Republic', 'DOM', 'DO'),
(61, 1, 'East Timor', 'TMP', 'TP'),
(62, 1, 'Ecuador', 'ECU', 'EC'),
(63, 1, 'Egypt', 'EGY', 'EG'),
(64, 1, 'El Salvador', 'SLV', 'SV'),
(65, 1, 'Equatorial Guinea', 'GNQ', 'GQ'),
(66, 1, 'Eritrea', 'ERI', 'ER'),
(67, 1, 'Estonia', 'EST', 'EE'),
(68, 1, 'Ethiopia', 'ETH', 'ET'),
(69, 1, 'Falkland Islands (Malvinas)', 'FLK', 'FK'),
(70, 1, 'Faroe Islands', 'FRO', 'FO'),
(71, 1, 'Fiji', 'FJI', 'FJ'),
(72, 1, 'Finland', 'FIN', 'FI'),
(73, 1, 'France', 'FRA', 'FR'),
(74, 1, 'France, Metropolitan', 'FXX', 'FX'),
(75, 1, 'French Guiana', 'GUF', 'GF'),
(76, 1, 'French Polynesia', 'PYF', 'PF'),
(77, 1, 'French Southern Territories', 'ATF', 'TF'),
(78, 1, 'Gabon', 'GAB', 'GA'),
(79, 1, 'Gambia', 'GMB', 'GM'),
(80, 1, 'Georgia', 'GEO', 'GE'),
(81, 1, 'Germany', 'DEU', 'DE'),
(82, 1, 'Ghana', 'GHA', 'GH'),
(83, 1, 'Gibraltar', 'GIB', 'GI'),
(84, 1, 'Greece', 'GRC', 'GR'),
(85, 1, 'Greenland', 'GRL', 'GL'),
(86, 1, 'Grenada', 'GRD', 'GD'),
(87, 1, 'Guadeloupe', 'GLP', 'GP'),
(88, 1, 'Guam', 'GUM', 'GU'),
(89, 1, 'Guatemala', 'GTM', 'GT'),
(90, 1, 'Guinea', 'GIN', 'GN'),
(91, 1, 'Guinea-bissau', 'GNB', 'GW'),
(92, 1, 'Guyana', 'GUY', 'GY'),
(93, 1, 'Haiti', 'HTI', 'HT'),
(94, 1, 'Heard and Mc Donald Islands', 'HMD', 'HM'),
(95, 1, 'Honduras', 'HND', 'HN'),
(96, 1, 'Hong Kong', 'HKG', 'HK'),
(97, 1, 'Hungary', 'HUN', 'HU'),
(98, 1, 'Iceland', 'ISL', 'IS'),
(99, 1, 'India', 'IND', 'IN'),
(100, 1, 'Indonesia', 'IDN', 'ID'),
(101, 1, 'Iran (Islamic Republic of)', 'IRN', 'IR'),
(102, 1, 'Iraq', 'IRQ', 'IQ'),
(103, 1, 'Ireland', 'IRL', 'IE'),
(104, 1, 'Israel', 'ISR', 'IL'),
(105, 1, 'Italy', 'ITA', 'IT'),
(106, 1, 'Jamaica', 'JAM', 'JM'),
(107, 1, 'Japan', 'JPN', 'JP'),
(108, 1, 'Jordan', 'JOR', 'JO'),
(109, 1, 'Kazakhstan', 'KAZ', 'KZ'),
(110, 1, 'Kenya', 'KEN', 'KE'),
(111, 1, 'Kiribati', 'KIR', 'KI'),
(112, 1, 'Korea, Democratic People''s Republic of', 'PRK', 'KP'),
(113, 1, 'Korea, Republic of', 'KOR', 'KR'),
(114, 1, 'Kuwait', 'KWT', 'KW'),
(115, 1, 'Kyrgyzstan', 'KGZ', 'KG'),
(116, 1, 'Lao People''s Democratic Republic', 'LAO', 'LA'),
(117, 1, 'Latvia', 'LVA', 'LV'),
(118, 1, 'Lebanon', 'LBN', 'LB'),
(119, 1, 'Lesotho', 'LSO', 'LS'),
(120, 1, 'Liberia', 'LBR', 'LR'),
(121, 1, 'Libyan Arab Jamahiriya', 'LBY', 'LY'),
(122, 1, 'Liechtenstein', 'LIE', 'LI'),
(123, 1, 'Lithuania', 'LTU', 'LT'),
(124, 1, 'Luxembourg', 'LUX', 'LU'),
(125, 1, 'Macau', 'MAC', 'MO'),
(126, 1, 'Macedonia, The Former Yugoslav Republic of', 'MKD', 'MK'),
(127, 1, 'Madagascar', 'MDG', 'MG'),
(128, 1, 'Malawi', 'MWI', 'MW'),
(129, 1, 'Malaysia', 'MYS', 'MY'),
(130, 1, 'Maldives', 'MDV', 'MV'),
(131, 1, 'Mali', 'MLI', 'ML'),
(132, 1, 'Malta', 'MLT', 'MT'),
(133, 1, 'Marshall Islands', 'MHL', 'MH'),
(134, 1, 'Martinique', 'MTQ', 'MQ'),
(135, 1, 'Mauritania', 'MRT', 'MR'),
(136, 1, 'Mauritius', 'MUS', 'MU'),
(137, 1, 'Mayotte', 'MYT', 'YT'),
(138, 1, 'Mexico', 'MEX', 'MX'),
(139, 1, 'Micronesia, Federated States of', 'FSM', 'FM'),
(140, 1, 'Moldova, Republic of', 'MDA', 'MD'),
(141, 1, 'Monaco', 'MCO', 'MC'),
(142, 1, 'Mongolia', 'MNG', 'MN'),
(143, 1, 'Montserrat', 'MSR', 'MS'),
(144, 1, 'Morocco', 'MAR', 'MA'),
(145, 1, 'Mozambique', 'MOZ', 'MZ'),
(146, 1, 'Myanmar', 'MMR', 'MM'),
(147, 1, 'Namibia', 'NAM', 'NA'),
(148, 1, 'Nauru', 'NRU', 'NR'),
(149, 1, 'Nepal', 'NPL', 'NP'),
(150, 1, 'Netherlands', 'NLD', 'NL'),
(151, 1, 'Netherlands Antilles', 'ANT', 'AN'),
(152, 1, 'New Caledonia', 'NCL', 'NC'),
(153, 1, 'New Zealand', 'NZL', 'NZ'),
(154, 1, 'Nicaragua', 'NIC', 'NI'),
(155, 1, 'Niger', 'NER', 'NE'),
(156, 1, 'Nigeria', 'NGA', 'NG'),
(157, 1, 'Niue', 'NIU', 'NU'),
(158, 1, 'Norfolk Island', 'NFK', 'NF'),
(159, 1, 'Northern Mariana Islands', 'MNP', 'MP'),
(160, 1, 'Norway', 'NOR', 'NO'),
(161, 1, 'Oman', 'OMN', 'OM'),
(162, 1, 'Pakistan', 'PAK', 'PK'),
(163, 1, 'Palau', 'PLW', 'PW'),
(164, 1, 'Panama', 'PAN', 'PA'),
(165, 1, 'Papua New Guinea', 'PNG', 'PG'),
(166, 1, 'Paraguay', 'PRY', 'PY'),
(167, 1, 'Peru', 'PER', 'PE'),
(168, 1, 'Philippines', 'PHL', 'PH'),
(169, 1, 'Pitcairn', 'PCN', 'PN'),
(170, 1, 'Poland', 'POL', 'PL'),
(171, 1, 'Portugal', 'PRT', 'PT'),
(172, 1, 'Puerto Rico', 'PRI', 'PR'),
(173, 1, 'Qatar', 'QAT', 'QA'),
(174, 1, 'Reunion', 'REU', 'RE'),
(175, 1, 'Romania', 'ROM', 'RO'),
(176, 1, 'Russian Federation', 'RUS', 'RU'),
(177, 1, 'Rwanda', 'RWA', 'RW'),
(178, 1, 'Saint Kitts and Nevis', 'KNA', 'KN'),
(179, 1, 'Saint Lucia', 'LCA', 'LC'),
(180, 1, 'Saint Vincent and the Grenadines', 'VCT', 'VC'),
(181, 1, 'Samoa', 'WSM', 'WS'),
(182, 1, 'San Marino', 'SMR', 'SM'),
(183, 1, 'Sao Tome and Principe', 'STP', 'ST'),
(184, 1, 'Saudi Arabia', 'SAU', 'SA'),
(185, 1, 'Senegal', 'SEN', 'SN'),
(186, 1, 'Seychelles', 'SYC', 'SC'),
(187, 1, 'Sierra Leone', 'SLE', 'SL'),
(188, 1, 'Singapore', 'SGP', 'SG'),
(189, 1, 'Slovakia (Slovak Republic)', 'SVK', 'SK'),
(190, 1, 'Slovenia', 'SVN', 'SI'),
(191, 1, 'Solomon Islands', 'SLB', 'SB'),
(192, 1, 'Somalia', 'SOM', 'SO'),
(193, 1, 'South Africa', 'ZAF', 'ZA'),
(194, 1, 'South Georgia and the South Sandwich Islands', 'SGS', 'GS'),
(195, 1, 'Spain', 'ESP', 'ES'),
(196, 1, 'Sri Lanka', 'LKA', 'LK'),
(197, 1, 'St. Helena', 'SHN', 'SH'),
(198, 1, 'St. Pierre and Miquelon', 'SPM', 'PM'),
(199, 1, 'Sudan', 'SDN', 'SD'),
(200, 1, 'Suriname', 'SUR', 'SR'),
(201, 1, 'Svalbard and Jan Mayen Islands', 'SJM', 'SJ'),
(202, 1, 'Swaziland', 'SWZ', 'SZ'),
(203, 1, 'Sweden', 'SWE', 'SE'),
(204, 1, 'Switzerland', 'CHE', 'CH'),
(205, 1, 'Syrian Arab Republic', 'SYR', 'SY'),
(206, 1, 'Taiwan', 'TWN', 'TW'),
(207, 1, 'Tajikistan', 'TJK', 'TJ'),
(208, 1, 'Tanzania, United Republic of', 'TZA', 'TZ'),
(209, 1, 'Thailand', 'THA', 'TH'),
(210, 1, 'Togo', 'TGO', 'TG'),
(211, 1, 'Tokelau', 'TKL', 'TK'),
(212, 1, 'Tonga', 'TON', 'TO'),
(213, 1, 'Trinidad and Tobago', 'TTO', 'TT'),
(214, 1, 'Tunisia', 'TUN', 'TN'),
(215, 1, 'Turkey', 'TUR', 'TR'),
(216, 1, 'Turkmenistan', 'TKM', 'TM'),
(217, 1, 'Turks and Caicos Islands', 'TCA', 'TC'),
(218, 1, 'Tuvalu', 'TUV', 'TV'),
(219, 1, 'Uganda', 'UGA', 'UG'),
(220, 1, 'Ukraine', 'UKR', 'UA'),
(221, 1, 'United Arab Emirates', 'ARE', 'AE'),
(222, 1, 'United Kingdom', 'GBR', 'GB'),
(223, 1, 'United States', 'USA', 'US'),
(224, 1, 'United States Minor Outlying Islands', 'UMI', 'UM'),
(225, 1, 'Uruguay', 'URY', 'UY'),
(226, 1, 'Uzbekistan', 'UZB', 'UZ'),
(227, 1, 'Vanuatu', 'VUT', 'VU'),
(228, 1, 'Vatican City State (Holy See)', 'VAT', 'VA'),
(229, 1, 'Venezuela', 'VEN', 'VE'),
(230, 1, 'Viet Nam', 'VNM', 'VN'),
(231, 1, 'Virgin Islands (British)', 'VGB', 'VG'),
(232, 1, 'Virgin Islands (U.S.)', 'VIR', 'VI'),
(233, 1, 'Wallis and Futuna Islands', 'WLF', 'WF'),
(234, 1, 'Western Sahara', 'ESH', 'EH'),
(235, 1, 'Yemen', 'YEM', 'YE'),
(236, 1, 'Serbia', 'SRB', 'RS'),
(237, 1, 'The Democratic Republic of Congo', 'DRC', 'DC'),
(238, 1, 'Zambia', 'ZMB', 'ZM'),
(239, 1, 'Zimbabwe', 'ZWE', 'ZW'),
(240, 1, 'East Timor', 'XET', 'XE'),
(241, 1, 'Jersey', 'XJE', 'XJ'),
(242, 1, 'St. Barthelemy', 'XSB', 'XB'),
(243, 1, 'St. Eustatius', 'XSE', 'XU'),
(244, 1, 'Canary Islands', 'XCA', 'XC'),
(245, 1, 'Montenegro', 'MNE', 'ME');

-- --------------------------------------------------------

--
-- Table structure for table `jos_weblinks`
--

CREATE TABLE IF NOT EXISTS `jos_weblinks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`,`published`,`archived`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Truncate table before insert `jos_weblinks`
--

TRUNCATE TABLE `jos_weblinks`;
-- --------------------------------------------------------

--
-- Table structure for table `jos_wf_profiles`
--

CREATE TABLE IF NOT EXISTS `jos_wf_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `users` text NOT NULL,
  `types` varchar(255) NOT NULL,
  `components` text NOT NULL,
  `area` tinyint(3) NOT NULL,
  `rows` text NOT NULL,
  `plugins` text NOT NULL,
  `published` tinyint(3) NOT NULL,
  `ordering` int(11) NOT NULL,
  `checked_out` tinyint(3) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Truncate table before insert `jos_wf_profiles`
--

TRUNCATE TABLE `jos_wf_profiles`;
--
-- Dumping data for table `jos_wf_profiles`
--

INSERT INTO `jos_wf_profiles` (`id`, `name`, `description`, `users`, `types`, `components`, `area`, `rows`, `plugins`, `published`, `ordering`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'Default', 'Default Profile for all users', '', '19,20,21,23,24,25', '', 0, 'help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,blockquote,formatselect,styleselect,removeformat,cleanup;fontselect,fontsizeselect,forecolor,backcolor,spacer,paste,indent,outdent,numlist,bullist,sub,sup,textcase,charmap,hr;directionality,fullscreen,preview,source,print,searchreplace,spacer,table;visualaid,visualchars,visualblocks,nonbreaking,style,xhtmlxtras,anchor,unlink,link,imgmanager,spellchecker,article', 'contextmenu,browser,inlinepopups,media,help,paste,searchreplace,directionality,fullscreen,preview,source,table,textcase,print,style,nonbreaking,visualchars,visualblocks,xhtmlxtras,imgmanager,anchor,link,spellchecker,article', 1, 1, 0, '0000-00-00 00:00:00', ''),
(2, 'Front End', 'Sample Front-end Profile', '', '19,20,21', '', 1, 'help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,formatselect,styleselect;paste,searchreplace,indent,outdent,numlist,bullist,cleanup,charmap,removeformat,hr,sub,sup,textcase,nonbreaking,visualchars,visualblocks;fullscreen,preview,print,visualaid,style,xhtmlxtras,anchor,unlink,link,imgmanager,spellchecker,article', 'contextmenu,inlinepopups,help,paste,searchreplace,fullscreen,preview,print,style,textcase,nonbreaking,visualchars,visualblocks,xhtmlxtras,imgmanager,anchor,link,spellchecker,article', 0, 2, 0, '0000-00-00 00:00:00', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
